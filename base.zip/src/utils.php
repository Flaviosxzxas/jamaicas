<?php

require('src/term.php');

/**
 * Escreve mensagem com quebra de linha
 */
function writeLn($message, $color = null) {
    if ($color && defined($color)) {
        echo "\033[" . constant($color) . "m" . $message . "\033[0m" . PHP_EOL;
    } else {
        echo $message . PHP_EOL;
    }
}

/**
 * Debug sem quebra de linha
 */
function debug(string $msg, $color = null) {
    if (!defined('DEBUG')) return;
    write(' > ', 'CYAN', null, 'BOLD');
    if ($color) {
        write($msg, $color);
    } else {
        write($msg);
    }
}

/**
 * Debug com quebra de linha
 */
function debugLn(string $msg, $color = null) {
    if (!defined('DEBUG')) return;
    debug($msg, $color);
    echo "\n";
}

/**
 * Debug OK em verde
 */
function debugOk() {
    if (!defined('DEBUG')) return;
    writeLn(' ✓ OK', 'GREEN');
}

/**
 * Debug FAIL em vermelho
 */
function debugFail($reason = '') {
    if (!defined('DEBUG')) return;
    $msg = ' ✗ FALHOU';
    if ($reason) $msg .= ': ' . $reason;
    writeLn($msg, 'RED');
}

/**
 * Parser de argumentos melhorado
 * Suporta: --key value, --key=value, --flag
 */
function parseArgv() {
    $argv = $_SERVER['argv'] ?? [];
    $params = [];
    $lastKey = '';

    foreach ($argv as $i => $arg) {
        if ($i === 0) continue; // Pula nome do script

        // Suporte para --key=value
        if (preg_match('/^--([^=]+)=(.*)/', $arg, $matches)) {
            $params[$matches[1]] = $matches[2];
            $lastKey = '';
        }
        // Suporte para --key
        elseif (preg_match('/^--(.+)/', $arg, $matches)) {
            $lastKey = $matches[1];
            $params[$lastKey] = '';
        }
        // Valor para a última key
        elseif ($lastKey) {
            $params[$lastKey] = trim($params[$lastKey] . ' ' . $arg);
        }
    }

    // Limpar valores
    foreach ($params as &$value) {
        $value = trim($value);
    }

    return $params;
}

/**
 * Obtém e valida parâmetros
 */
function getParams(): object {
    $params = parseArgv();
    $obj = new stdClass;

    // Modo debug
    $obj->debug = isset($params['debug']);
    if ($obj->debug) {
        define('DEBUG', true);
        debugLn('');
        debugLn('╔══════════════════════════════════════════╗', 'CYAN');
        debugLn('║         MODO DE DEPURAÇÃO ATIVO          ║', 'CYAN');
        debugLn('╚══════════════════════════════════════════╝', 'CYAN');
        debugLn('');
        debugLn('Parâmetros recebidos:', 'YELLOW');
        foreach ($params as $key => $value) {
            $displayValue = $value ?: '(flag)';
            debugLn("  --$key = $displayValue", 'WHITE');
        }
        debugLn('');
    }

    // CORREÇÃO: Tratamento melhorado do delay
    // Suporta: --delay 2000, --delay=2000, --delay2000
    if (isset($params['delay']) && is_numeric($params['delay'])) {
        $obj->delay = intval($params['delay']) * 1000; // Converte ms para μs
    } else {
        // Procura por delay com número junto (--delay2000)
        $delayFound = false;
        foreach ($params as $key => $value) {
            if (preg_match('/^delay(\d+)$/', $key, $matches)) {
                $obj->delay = intval($matches[1]) * 1000; // Converte ms para μs
                $delayFound = true;
                break;
            }
        }
        if (!$delayFound) {
            $obj->delay = 180000; // 180ms padrão em microsegundos
        }
    }
    debugLn("Delay de envio: " . ($obj->delay / 1000) . " ms", 'GREEN');

    // Informações do remetente
    $obj->senderName = $params['nome'] ?? null;
    debugLn("Nome remetente: " . ($obj->senderName ?: 'NÃO DEFINIDO'), $obj->senderName ? 'GREEN' : 'YELLOW');

    $obj->senderEmail = $params['de'] ?? null;
    debugLn("Email remetente: " . ($obj->senderEmail ?: 'NÃO DEFINIDO'), $obj->senderEmail ? 'GREEN' : 'YELLOW');

    // Validar email do remetente
    if ($obj->senderEmail && !filter_var($obj->senderEmail, FILTER_VALIDATE_EMAIL)) {
        writeLn("⚠️ Email remetente inválido: {$obj->senderEmail}", 'YELLOW');
    }

    // Assunto
    $obj->subject = $params['assunto'] ?? null;
    debugLn("Assunto: " . ($obj->subject ?: 'NÃO DEFINIDO'), $obj->subject ? 'GREEN' : 'YELLOW');

    // Inicializar destinatários
    $obj->targets = [];

    // Carregar conteúdo e anexo
    try {
        // Conteúdo HTML
        if (isset($params['conteudo'])) {
            debug("Carregando conteúdo de '{$params['conteudo']}'...");
            
            if (!file_exists($params['conteudo'])) {
                throw new Exception("Arquivo de conteúdo não encontrado: {$params['conteudo']}");
            }
            
            $obj->content = file_get_contents($params['conteudo']);
            if ($obj->content === false) {
                throw new Exception("Não foi possível ler o arquivo: {$params['conteudo']}");
            }
            
            debugOk();
            debugLn("  → " . strlen($obj->content) . " bytes carregados", 'CYAN');
        } else {
            $obj->content = null;
        }

        // Anexo (opcional)
        if (isset($params['anexo']) && !empty($params['anexo'])) {
            debug("Carregando anexo '{$params['anexo']}'...");
            
            if (!file_exists($params['anexo'])) {
                debugFail("Arquivo não encontrado");
                $obj->attachment = null;
                $obj->attachmentName = null;
            } else {
                $obj->attachment = file_get_contents($params['anexo']);
                if ($obj->attachment === false) {
                    debugFail("Não foi possível ler");
                    $obj->attachment = null;
                    $obj->attachmentName = null;
                } else {
                    $obj->attachmentName = basename($params['anexo']);
                    debugOk();
                    debugLn("  → Nome: {$obj->attachmentName}", 'CYAN');
                    debugLn("  → Tamanho: " . number_format(strlen($obj->attachment)) . " bytes", 'CYAN');
                }
            }
        } else {
            $obj->attachment = null;
            $obj->attachmentName = null;
            debugLn("Nenhum anexo fornecido", 'WHITE');
        }

    } catch(Exception $e) {
        writeLn("❌ " . $e->getMessage(), 'RED');
        exit(1);
    }

    // Destinatário único
    if (isset($params['para']) && !empty($params['para'])) {
        $email = trim($params['para']);
        if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $obj->targets[] = $email;
            debugLn("Destinatário único: $email", 'GREEN');
        } else {
            debugLn("Email inválido ignorado: $email", 'YELLOW');
        }
    }

    // Lista de destinatários
    if (isset($params['lista'])) {
        $listFile = $params['lista'];
        
        if (!file_exists($listFile)) {
            writeLn("❌ Arquivo de lista não encontrado: $listFile", 'RED');
            exit(1);
        }
        
        if (!is_readable($listFile)) {
            writeLn("❌ Sem permissão para ler: $listFile", 'RED');
            exit(1);
        }
        
        debugLn("Carregando lista de '{$listFile}'...", 'YELLOW');
        
        $fhandle = fopen($listFile, 'r');
        if ($fhandle === false) {
            writeLn("❌ Não foi possível abrir: $listFile", 'RED');
            exit(1);
        }
        
        $lineNum = 0;
        $validCount = 0;
        $invalidCount = 0;
        $duplicateCount = 0;
        
        while (!feof($fhandle)) {
            $lineNum++;
            $line = trim(fgets($fhandle));
            
            // Ignorar linhas vazias e comentários
            if (empty($line) || strpos($line, '#') === 0) {
                continue;
            }
            
            // Validar email
            if (filter_var($line, FILTER_VALIDATE_EMAIL)) {
                if (!in_array($line, $obj->targets)) {
                    $obj->targets[] = $line;
                    $validCount++;
                    if (defined('DEBUG') && $validCount <= 10) {
                        debugLn("  ✓ Linha $lineNum: $line", 'GREEN');
                    }
                } else {
                    $duplicateCount++;
                    if (defined('DEBUG') && $duplicateCount <= 5) {
                        debugLn("  ⚠ Linha $lineNum: $line (duplicado)", 'YELLOW');
                    }
                }
            } else {
                $invalidCount++;
                if (defined('DEBUG') && $invalidCount <= 5) {
                    debugLn("  ✗ Linha $lineNum: '$line' (inválido)", 'RED');
                }
            }
        }
        
        fclose($fhandle);
        
        // Resumo da lista
        debugLn('', null);
        debugLn("📊 Resumo da lista:", 'CYAN');
        debugLn("  ✓ Válidos: $validCount", 'GREEN');
        if ($duplicateCount > 0) {
            debugLn("  ⚠ Duplicados: $duplicateCount", 'YELLOW');
        }
        if ($invalidCount > 0) {
            debugLn("  ✗ Inválidos: $invalidCount", 'RED');
        }
        debugLn("  → Total único: " . count($obj->targets), 'WHITE');
    }

    // Remover duplicatas e reindexar
    $obj->targets = array_values(array_unique($obj->targets));

    // Validar parâmetros obrigatórios
    try {
        validateParams($obj);
    } catch(Exception $e) {
        writeLn("❌ " . $e->getMessage(), 'RED');
        exit(1);
    }

    return $obj;
}

/**
 * Valida parâmetros obrigatórios
 */
function validateParams(object $params) {
    debugLn('');
    debugLn('Validando parâmetros...', 'YELLOW');
    
    $errors = [];
    
    // Nome do remetente
    debug('Nome do remetente...');
    if (!$params->senderName) {
        $errors[] = "Nome do remetente não fornecido (use --nome)";
        debugFail();
    } else {
        debugOk();
    }
    
    // Email do remetente
    debug('Email do remetente...');
    if (!$params->senderEmail) {
        $errors[] = "Email do remetente não fornecido (use --de)";
        debugFail();
    } elseif (!filter_var($params->senderEmail, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Email do remetente inválido: {$params->senderEmail}";
        debugFail();
    } else {
        debugOk();
    }
    
    // Assunto
    debug('Assunto...');
    if (!$params->subject) {
        $errors[] = "Assunto não fornecido (use --assunto)";
        debugFail();
    } else {
        debugOk();
    }
    
    // Destinatários
    debug('Destinatários...');
    if (count($params->targets) === 0) {
        $errors[] = "Nenhum destinatário válido (use --para ou --lista)";
        debugFail();
    } else {
        debugOk();
        debugLn("  → " . count($params->targets) . " destinatários", 'CYAN');
    }
    
    // Conteúdo
    debug('Conteúdo...');
    if (!$params->content) {
        $errors[] = "Conteúdo não fornecido ou vazio (use --conteudo)";
        debugFail();
    } else {
        debugOk();
    }
    
    // Se houver erros, exibir todos
    if (!empty($errors)) {
        writeLn('');
        writeLn('═══════════════════════════════════════', 'RED');
        writeLn('         ERROS ENCONTRADOS             ', 'RED');
        writeLn('═══════════════════════════════════════', 'RED');
        foreach ($errors as $error) {
            writeLn("  ✗ $error", 'YELLOW');
        }
        writeLn('═══════════════════════════════════════', 'RED');
        writeLn('');
        writeLn('Use --debug para mais detalhes', 'WHITE');
        throw new Exception("Validação falhou");
    }
    
    debugLn('');
    debugLn('✅ Todos os parâmetros validados!', 'GREEN');
}

/**
 * Verifica instalação do sendmail
 */
function verifySendMail() {
    $paths = [
        '/usr/sbin/sendmail',
        '/usr/bin/sendmail',
        '/usr/lib/sendmail'
    ];
    
    $found = false;
    foreach ($paths as $path) {
        if (is_file($path) && is_executable($path)) {
            $found = true;
            debugLn("Sendmail encontrado: $path", 'GREEN');
            break;
        }
    }
    
    if (!$found) {
        writeLn('');
        writeLn('═══════════════════════════════════════', 'RED');
        writeLn('      SENDMAIL NÃO ENCONTRADO!         ', 'RED');
        writeLn('═══════════════════════════════════════', 'RED');
        writeLn('');
        writeLn('Para instalar, execute:', 'YELLOW');
        writeLn('');
        writeLn('  Opção 1 - Postfix (recomendado):', 'WHITE');
        writeLn('  sudo apt-get install postfix', 'CYAN');
        writeLn('');
        writeLn('  Opção 2 - Sendmail tradicional:', 'WHITE');
        writeLn('  sudo apt-get install sendmail', 'CYAN');
        writeLn('');
        writeLn('Após instalar, execute novamente.', 'YELLOW');
        writeLn('');
        exit(1);
    }
}

/**
 * Exibe ajuda de uso
 */
function showHelp() {
    writeLn('');
    writeLn('╔══════════════════════════════════════════════╗', 'CYAN');
    writeLn('║       SISTEMA DE ENVIO DE EMAIL v2.0        ║', 'CYAN');
    writeLn('╚══════════════════════════════════════════════╝', 'CYAN');
    writeLn('');
    writeLn('USO:', 'YELLOW');
    writeLn('  php send.php [opções]', 'WHITE');
    writeLn('');
    writeLn('OPÇÕES OBRIGATÓRIAS:', 'YELLOW');
    writeLn('  --nome <nome>        Nome do remetente', 'WHITE');
    writeLn('  --de <email>         Email do remetente', 'WHITE');
    writeLn('  --assunto <texto>    Assunto do email', 'WHITE');
    writeLn('  --conteudo <arquivo> Arquivo HTML com conteúdo', 'WHITE');
    writeLn('');
    writeLn('DESTINATÁRIOS (usar ao menos um):', 'YELLOW');
    writeLn('  --para <email>       Email único', 'WHITE');
    writeLn('  --lista <arquivo>    Arquivo com lista de emails', 'WHITE');
    writeLn('');
    writeLn('OPCIONAIS:', 'YELLOW');
    writeLn('  --anexo <arquivo>    Arquivo para anexar', 'WHITE');
    writeLn('  --delay <ms>         Delay entre envios (padrão: 180)', 'WHITE');
    writeLn('  --debug              Modo debug detalhado', 'WHITE');
    writeLn('  --help               Esta ajuda', 'WHITE');
    writeLn('');
    writeLn('EXEMPLOS:', 'YELLOW');
    writeLn('');
    writeLn('  Envio simples:', 'WHITE');
    writeLn('  php send.php --nome "João" --de joao@empresa.com \\', 'CYAN');
    writeLn('               --assunto "Teste" --para cliente@email.com \\', 'CYAN');
    writeLn('               --conteudo msg.html', 'CYAN');
    writeLn('');
    writeLn('  Envio em massa com anexo:', 'WHITE');
    writeLn('  php send.php --nome "Empresa" --de noreply@empresa.com \\', 'CYAN');
    writeLn('               --assunto "Newsletter" --lista emails.txt \\', 'CYAN');
    writeLn('               --conteudo news.html --anexo catalogo.pdf \\', 'CYAN');
    writeLn('               --delay 2000 --debug', 'CYAN');
    writeLn('');
    writeLn('FORMATOS DE DELAY ACEITOS:', 'YELLOW');
    writeLn('  --delay 2000         (espaço)', 'WHITE');
    writeLn('  --delay=2000         (igual)', 'WHITE');
    writeLn('  --delay2000          (junto) *compatibilidade', 'WHITE');
    writeLn('');
}

// Verificar se foi solicitada ajuda
$argv = $_SERVER['argv'] ?? [];
if (isset($argv[1]) && in_array($argv[1], ['--help', '-h', 'help', '?'])) {
    showHelp();
    exit(0);
}

?>