<?php
/**
 * term.php - Versão Otimizada
 * Funções utilitárias para geração de strings, números e IDs
 */

// ================== GERAÇÃO DE STRINGS ALEATÓRIAS ==================

/**
 * Gera string aleatória hexadecimal
 */
if (!function_exists('generateRandomString')) {
    function generateRandomString($length = 16) {
        // Versão otimizada - usa random_bytes diretamente
        $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-';
        $maxIndex = strlen($chars) - 1;
        $str = '';
        
        for($i = 0; $i < $length; $i++) {
            $str .= $chars[mt_rand(0, $maxIndex)];
        }
        
        return $str;
    }
}

/**
 * Gera Message-ID único para email
 */
function generateMessageID($domain) {
    $timestamp = microtime(true) * 10000; // Mais único
    $uniqueString = bin2hex(random_bytes(8));
    return "<{$timestamp}.{$uniqueString}@{$domain}>";
}

/**
 * Extrai domínio do email
 */
function getMainDomain($email) {
    // Validação adicional
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return '';
    }
    return substr(strrchr($email, "@"), 1);
}

/**
 * Gera GUID para eventos
 */
function generateRandomEventGuid() {
    // Formato UUID v4 apropriado
    $data = random_bytes(16);
    $data[6] = chr(ord($data[6]) & 0x0f | 0x40);
    $data[8] = chr(ord($data[8]) & 0x3f | 0x80);
    return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
}

// ================== GERADORES DE NÚMEROS ==================

/**
 * Gera número de referência (6 dígitos)
 */
function generateRefNumber() {
    return mt_rand(100000, 999999); // Mais eficiente
}

/**
 * Função unificada para gerar números aleatórios
 * Substitui generateRandomNumber1 e generateRandomNumber2
 */
function generateRandomNumber($min, $max) {
    $length = mt_rand($min, $max);
    $result = '';
    
    // Otimização: gera todos os dígitos de uma vez
    for ($i = 0; $i < $length; $i++) {
        $result .= mt_rand(0, 9);
    }
    
    return $result;
}

// Aliases para compatibilidade
function generateRandomNumber1($min, $max) {
    return generateRandomNumber($min, $max);
}

function generateRandomNumber2($min, $max) {
    return generateRandomNumber($min, $max);
}

// ================== GERADORES DE LETRAS ==================

/**
 * Função unificada otimizada para gerar letras
 */
function generateRandomLetters($min, $max, $case = 'mixed') {
    static $charsets = [
        'upper' => 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
        'lower' => 'abcdefghijklmnopqrstuvwxyz',
        'mixed' => 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
    ];
    
    $chars = $charsets[$case] ?? $charsets['mixed'];
    $length = mt_rand($min, $max);
    $maxIndex = strlen($chars) - 1;
    $result = '';
    
    for ($i = 0; $i < $length; $i++) {
        $result .= $chars[mt_rand(0, $maxIndex)];
    }
    
    return $result;
}

// Funções específicas para compatibilidade
function generateRandomLetras1($min, $max) {
    return generateRandomLetters($min, $max, 'upper');
}

function generateRandomLetras2($min, $max) {
    return generateRandomLetters($min, $max, 'lower');
}

function generateRandomLetras3($min, $max) {
    return generateRandomLetters($min, $max, 'mixed');
}

// ================== GERADORES MISTOS ==================

/**
 * Gera string alfanumérica
 */
function generateMix1($min, $max) {
    $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    $length = mt_rand($min, $max);
    $maxIndex = strlen($chars) - 1;
    $result = '';
    
    for ($i = 0; $i < $length; $i++) {
        $result .= $chars[mt_rand(0, $maxIndex)];
    }
    
    return $result;
}

/**
 * Gera string com underscores
 */
function generateMix2($min, $max) {
    $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_';
    $length = mt_rand($min, $max);
    $maxIndex = strlen($chars) - 1;
    $result = '';
    
    for ($i = 0; $i < $length; $i++) {
        $result .= $chars[mt_rand(0, $maxIndex)];
    }
    
    return $result;
}

// ================== FUNÇÕES ESPECIAIS ==================

/**
 * Retorna link aleatório sem repetir o último
 */
function randomxxlinkxx() {
    static $lastLink = null;
    static $links = [
        'https://odintec.blob.core.windows.net/home/meac7.html',
        'https://odintec.blob.core.windows.net/home/lwccb.html',
        'https://odintec.blob.core.windows.net/home/lf7bl.html',
        'https://odintec.blob.core.windows.net/home/klylj.html',
        'https://odintec.blob.core.windows.net/home/3n1so.html',
    ];
    
    $count = count($links);
    if ($count === 1) {
        return $links[0];
    }
    
    // Seleção mais eficiente
    $available = array_diff($links, [$lastLink]);
    $randomLink = $available[array_rand($available)];
    $lastLink = $randomLink;
    
    return $randomLink;
}

/**
 * Gera RFC mexicano para pessoa física
 */
function gerarRFCPessoaFisica() {
    // Formato: AAAA######XXX (4 letras + 6 números de data + 3 alfanuméricos)
    $letras = '';
    for ($i = 0; $i < 4; $i++) {
        $letras .= chr(mt_rand(65, 90)); // A-Z
    }
    
    // Data: AAMMDD
    $ano = mt_rand(50, 99);
    $mes = str_pad(mt_rand(1, 12), 2, '0', STR_PAD_LEFT);
    $dia = str_pad(mt_rand(1, 28), 2, '0', STR_PAD_LEFT);
    
    // Homoclave: 3 caracteres alfanuméricos
    $homoclave = '';
    $chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    for ($i = 0; $i < 3; $i++) {
        $homoclave .= $chars[mt_rand(0, 35)];
    }
    
    return $letras . $ano . $mes . $dia . $homoclave;
}

/**
 * Gera RFC mexicano para pessoa jurídica
 */
function gerarRFCPessoaJuridica() {
    // Formato: AAA######XXX (3 letras + 6 números de data + 3 alfanuméricos)
    $letras = '';
    for ($i = 0; $i < 3; $i++) {
        $letras .= chr(mt_rand(65, 90)); // A-Z
    }
    
    // Data: AAMMDD
    $ano = mt_rand(80, 99);
    $mes = str_pad(mt_rand(1, 12), 2, '0', STR_PAD_LEFT);
    $dia = str_pad(mt_rand(1, 28), 2, '0', STR_PAD_LEFT);
    
    // Homoclave: 3 caracteres alfanuméricos
    $homoclave = '';
    $chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    for ($i = 0; $i < 3; $i++) {
        $homoclave .= $chars[mt_rand(0, 35)];
    }
    
    return $letras . $ano . $mes . $dia . $homoclave;
}

/**
 * Gera string com caracteres monospace Unicode
 */
function generatemonospace2($min, $max) {
    // Mapa de conversão mais eficiente
    static $monospace = ['𝟶','𝟷','𝟸','𝟹','𝟺','𝟻','𝟼','𝟽','𝟾','𝟿'];
    
    $length = mt_rand($min, $max);
    $result = '';
    
    for ($i = 0; $i < $length; $i++) {
        $result .= $monospace[mt_rand(0, 9)];
    }
    
    return $result;
}

/**
 * Gera GUID/UUID compatível
 */
function getGUID() {
    // Versão otimizada - UUID v4
    return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        mt_rand(0, 0xffff), mt_rand(0, 0xffff),
        mt_rand(0, 0xffff),
        mt_rand(0, 0x0fff) | 0x4000,
        mt_rand(0, 0x3fff) | 0x8000,
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
    );
}

/**
 * Gera nome aleatório (exemplo simplificado)
 */
function randomName() {
    static $names = [
        'Amanda Beatriz', 'Amanda Luisa', 'Alana Cecilia', 'Ana Alice', 
        'Ana Amelia', 'Ana Beatriz', 'Ana Bela', 'Ana Carolina', 
        'Ana Cecilia', 'Ana Clara', 'Ana Elisa', 'Ana Flavia', 
        'Ana Helena', 'Ana Julia', 'Ana Lara', 'Ana Laura', 
        'Ana Leticia', 'Ana Lis', 'Ana Livia', 'Ana Lucia', 
        'Ana Luisa', 'Ana Mara', 'Ana Maria', 'Ana Paula', 'Ana Patricia'
    ];
    
    return $names[array_rand($names)];
}

// ================== FUNÇÕES AUXILIARES (Legado) ==================

/**
 * Gera string aleatória (compatibilidade)
 */
function randString($size) {
    $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    $maxIndex = strlen($chars) - 1;
    $result = '';
    
    for($i = 0; $i < $size; $i++) {
        $result .= $chars[mt_rand(0, $maxIndex)];
    }
    
    return $result;
}

/**
 * Funções auxiliares removidas/não usadas
 */
function gerarDataAleatoria() {
    $ano = mt_rand(1950, 2000);
    $mes = str_pad(mt_rand(1, 12), 2, '0', STR_PAD_LEFT);
    $dia = str_pad(mt_rand(1, 28), 2, '0', STR_PAD_LEFT);
    return "$ano/$mes/$dia";
}

function gerarLetrasAleatorias($tamanho) {
    $result = '';
    for ($i = 0; $i < $tamanho; $i++) {
        $result .= chr(mt_rand(65, 90)); // A-Z
    }
    return $result;
}

function gerarDigitosAleatorios($tamanho) {
    $chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $maxIndex = 35;
    $result = '';
    for ($i = 0; $i < $tamanho; $i++) {
        $result .= $chars[mt_rand(0, $maxIndex)];
    }
    return $result;
}