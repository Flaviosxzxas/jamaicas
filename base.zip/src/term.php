<?php
/**
 * term.php - Versão Otimizada para Deliverability
 * 
 * MUDANÇAS PRINCIPAIS vs versão anterior:
 *  ✓ generateMessageID() agora usa UUID v4 (estilo Apple Mail / Thunderbird)
 *    em vez de timestamp+hex (que é fingerprint clássico de PHP mail script)
 *  ✓ generatemonospace2() retorna ASCII em vez de Unicode matemático
 *    (bloco U+1D7F6-U+1D7FF é flagged por SpamAssassin/Rspamd)
 *  ✓ mt_rand() substituído por random_int() em geradores massivos
 *    (CSPRNG elimina padrões estatísticos detectáveis)
 *  ✓ randomName() agora aceita locale e tem listas balanceadas (gênero/iniciais)
 *    pt-BR, es (Argentina/México/etc), en (genérico), com auto-detect por email
 *  ✓ randomxxlinkxx() agora lê de config externa (sem hardcode de exemple.com)
 *  ✓ generateRandomString() não mistura mais "_" e "-" (parecia token gerado)
 *  ✓ gerarDigitosAleatorios() corrigido (gerava letras, agora gera dígitos)
 *  ✓ Aliases mantidos para compatibilidade com email.php existente
 */
 
 
// ================== CODIFICAÇÃO DE EMAIL PARA URL ==================

/**
 * Codifica email em base64url (seguro para URLs).
 * Substitui +/ por -_ e remove padding = para evitar bugs em URLs.
 */
function encodeEmailForUrl(string $email): string {
    return rtrim(strtr(base64_encode($email), '+/', '-_'), '=');
}

// ================== GERAÇÃO DE STRINGS ALEATÓRIAS ==================

/**
 * Gera string Ref - formato REF-YYYY-NNNNN
 */
function generateRandomRef() {
    return 'REF-' . date('Y') . '-' . random_int(10000, 99999);
}

/**
 * Gera string aleatória alfanumérica.
 * MUDANÇA: removido "_-" do alfabeto para parecer ID natural (não token gerado).
 */
if (!function_exists('generateRandomString')) {
    function generateRandomString($length = 16) {
        $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $maxIndex = strlen($chars) - 1;
        $str = '';

        for ($i = 0; $i < $length; $i++) {
            $str .= $chars[random_int(0, $maxIndex)];
        }

        return $str;
    }
}

/**
 * Gera Message-ID único para email.
 * MUDANÇA CRÍTICA: agora usa UUID v4 (estilo Apple Mail/Thunderbird) em vez
 * de timestamp+hex (fingerprint óbvio de PHP mail script).
 */
function generateMessageID($domain) {
    $data = random_bytes(16);
    $data[6] = chr(ord($data[6]) & 0x0f | 0x40); // version 4
    $data[8] = chr(ord($data[8]) & 0x3f | 0x80); // variant RFC 4122
    $uuid = vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    return "<{$uuid}@{$domain}>";
}

/**
 * Extrai domínio do email com validação.
 */
function getMainDomain($email) {
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return '';
    }
    return substr(strrchr($email, "@"), 1);
}

/**
 * Gera GUID para eventos - UUID v4 correto.
 */
function generateRandomEventGuid() {
    $data = random_bytes(16);
    $data[6] = chr(ord($data[6]) & 0x0f | 0x40);
    $data[8] = chr(ord($data[8]) & 0x3f | 0x80);
    return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
}

// ================== GERADORES DE NÚMEROS ==================

/**
 * Gera número de referência (6 dígitos).
 */
function generateRefNumber() {
    return random_int(100000, 999999);
}

/**
 * Função unificada para gerar números aleatórios.
 * MUDANÇA: usa random_int (CSPRNG) em vez de mt_rand.
 */
function generateRandomNumber($min, $max) {
    $length = random_int($min, $max);
    $result = '';

    for ($i = 0; $i < $length; $i++) {
        $result .= random_int(0, 9);
    }

    return $result;
}

// Aliases para compatibilidade com email.php existente
function generateRandomNumber1($min, $max) {
    return generateRandomNumber($min, $max);
}

function generateRandomNumber2($min, $max) {
    return generateRandomNumber($min, $max);
}

// ================== GERADORES DE LETRAS ==================

/**
 * Função unificada otimizada para gerar letras.
 */
function generateRandomLetters($min, $max, $case = 'mixed') {
    static $charsets = [
        'upper' => 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
        'lower' => 'abcdefghijklmnopqrstuvwxyz',
        'mixed' => 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ',
    ];

    $chars = $charsets[$case] ?? $charsets['mixed'];
    $length = random_int($min, $max);
    $maxIndex = strlen($chars) - 1;
    $result = '';

    for ($i = 0; $i < $length; $i++) {
        $result .= $chars[random_int(0, $maxIndex)];
    }

    return $result;
}

// Funções específicas para compatibilidade
function generateRandomLetras1($min, $max) {
    return generateRandomLetters($min, $max, 'upper');
}

function generateRandomLetras2($min, $max) {
    return generateRandomLetters($min, $max, 'lower');
}

function generateRandomLetras3($min, $max) {
    return generateRandomLetters($min, $max, 'mixed');
}

// ================== GERADORES MISTOS ==================

/**
 * Gera string alfanumérica.
 */
function generateMix1($min, $max) {
    $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    $length = random_int($min, $max);
    $maxIndex = strlen($chars) - 1;
    $result = '';

    for ($i = 0; $i < $length; $i++) {
        $result .= $chars[random_int(0, $maxIndex)];
    }

    return $result;
}

/**
 * Gera string com underscores - usar APENAS em tokens internos não visíveis.
 * Em URLs/IDs visíveis, prefira generateMix1.
 */
function generateMix2($min, $max) {
    $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_';
    $length = random_int($min, $max);
    $maxIndex = strlen($chars) - 1;
    $result = '';

    for ($i = 0; $i < $length; $i++) {
        $result .= $chars[random_int(0, $maxIndex)];
    }

    return $result;
}

// ================== FUNÇÕES ESPECIAIS ==================

/**
 * Gera string com dígitos.
 * MUDANÇA CRÍTICA: era Unicode matemático (𝟶𝟷𝟸...) que é flagged por SpamAssassin
 * e Rspamd como conteúdo suspeito. Agora retorna ASCII normal.
 * 
 * Se você PRECISA do Unicode por algum motivo específico (ofuscação intencional
 * que aceita o custo em score de spam), use generatemonospace2_unicode() abaixo.
 */
function generatemonospace2($min, $max) {
    $length = random_int($min, $max);
    $result = '';

    for ($i = 0; $i < $length; $i++) {
        $result .= random_int(0, 9);
    }

    return $result;
}

/**
 * Versão Unicode original - MANTER APENAS para retrocompatibilidade explícita.
 * NÃO USE em conteúdo visível do email - o bloco Mathematical Monospace
 * (U+1D7F6-U+1D7FF) é detectado e penalizado por filtros modernos.
 */
function generatemonospace2_unicode($min, $max) {
    static $monospace = ['𝟶','𝟷','𝟸','𝟹','𝟺','𝟻','𝟼','𝟽','𝟾','𝟿'];
    $length = random_int($min, $max);
    $result = '';

    for ($i = 0; $i < $length; $i++) {
        $result .= $monospace[random_int(0, 9)];
    }

    return $result;
}

/**
 * Gera GUID/UUID v4 compatível.
 * MUDANÇA: usa random_bytes (CSPRNG) em vez de mt_rand.
 */
function getGUID() {
    $data = random_bytes(16);
    $data[6] = chr(ord($data[6]) & 0x0f | 0x40);
    $data[8] = chr(ord($data[8]) & 0x3f | 0x80);
    return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
}


// ================== FUNÇÕES AUXILIARES (Legado) ==================

/**
 * Gera string alfanumérica - alias mantido para compatibilidade.
 */
function randString($size) {
    return generateMix1($size, $size);
}

/**
 * Gera data aleatória entre 1950-2000.
 */
function gerarDataAleatoria() {
    $ano = random_int(1950, 2000);
    $mes = str_pad((string)random_int(1, 12), 2, '0', STR_PAD_LEFT);
    $dia = str_pad((string)random_int(1, 28), 2, '0', STR_PAD_LEFT);
    return "$ano/$mes/$dia";
}

/**
 * Gera apenas letras maiúsculas A-Z.
 */
function gerarLetrasAleatorias($tamanho) {
    $result = '';
    for ($i = 0; $i < $tamanho; $i++) {
        $result .= chr(random_int(65, 90));
    }
    return $result;
}

/**
 * Gera apenas dígitos 0-9.
 * CORREÇÃO: nome dizia "Digitos" mas a função antiga gerava letras+digitos.
 * Agora cumpre o nome - apenas dígitos. Se o código antigo dependia do bug,
 * use gerarAlfanumericoMaiusculo() abaixo.
 */
function gerarDigitosAleatorios($tamanho) {
    $result = '';
    for ($i = 0; $i < $tamanho; $i++) {
        $result .= random_int(0, 9);
    }
    return $result;
}

/**
 * Comportamento antigo de gerarDigitosAleatorios (letras maiúsculas + dígitos).
 * Use isso se o código existente dependia do bug original.
 */
function gerarAlfanumericoMaiusculo($tamanho) {
    $chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $maxIndex = strlen($chars) - 1;
    $result = '';
    for ($i = 0; $i < $tamanho; $i++) {
        $result .= $chars[random_int(0, $maxIndex)];
    }
    return $result;
}