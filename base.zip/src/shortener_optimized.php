<?php
/**
 * src/shortener_optimized.php
 * Sistema otimizado de encurtamento com multi-serviço
 * Compatível com o sistema existente
 */

// Reutilizar handles cURL globais para performance
static $__CURL_HANDLES = [];

/**
 * Obtém ou cria handle cURL reutilizável
 */
function getCurlHandle($key = 'default') {
    global $__CURL_HANDLES;
    
    if (!isset($__CURL_HANDLES[$key])) {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_USERAGENT => 'Mozilla/5.0 (Short-Bot/3.0)',
            CURLOPT_CONNECTTIMEOUT => 2,
            CURLOPT_TIMEOUT => 3,
            CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_ENCODING => '', // Aceita gzip
            CURLOPT_HTTPHEADER => [
                'Connection: keep-alive',
                'Accept: application/json, text/plain',
                'Accept-Language: en-US,en;q=0.9',
                'Cache-Control: no-cache'
            ],
        ]);
        $__CURL_HANDLES[$key] = $ch;
    }
    
    return $__CURL_HANDLES[$key];
}

/**
 * Função principal de encurtamento (compatível com código antigo)
 * Mantém assinatura original para retrocompatibilidade
 */
function shortenUrl($longUrl) {
    static $simpleShortener = null;
    
    if ($simpleShortener === null) {
        $simpleShortener = new SimpleShortener();
    }
    
    $result = $simpleShortener->shorten($longUrl);
    return $result['ok'] ? $result['short'] : false;
}

/**
 * Versão com validação (compatível com shortener_batch_new.php)
 */
function shortenUrlChecked($longUrl) {
    static $shortener = null;
    
    if ($shortener === null) {
        $shortener = new SimpleShortener();
    }
    
    return $shortener->shorten($longUrl);
}

/**
 * Validação rápida de shortlink
 */
function validateShortUrl($shortUrl, $expectedLong = null) {
    // Para serviços confiáveis, pula validação
    $trustedHosts = ['is.gd', 'v.gd', 'tinyurl.com', 'bit.ly', 'goo.gl'];
    $host = parse_url($shortUrl, PHP_URL_HOST);
    
    foreach ($trustedHosts as $trusted) {
        if (stripos($host, $trusted) !== false) {
            return true;
        }
    }
    
    // Validação HEAD apenas para não-confiáveis
    if (!$expectedLong) {
        return true; // Assume válido se não temos o esperado
    }
    
    $ch = getCurlHandle('head');
    curl_setopt($ch, CURLOPT_URL, $shortUrl);
    curl_setopt($ch, CURLOPT_NOBODY, true);
    curl_setopt($ch, CURLOPT_HEADER, true);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    
    curl_setopt($ch, CURLOPT_NOBODY, false);
    curl_setopt($ch, CURLOPT_HEADER, false);
    
    return ($httpCode >= 300 && $httpCode < 400);
}

/**
 * Classe simplificada de encurtamento (retrocompatível)
 */
class SimpleShortener {
    private $services;
    private $lastError;
    private $attempts;
    
    public function __construct() {
        $this->services = [
            'is.gd' => [
                'url' => 'https://is.gd/create.php?format=json&url=',
                'method' => 'json',
                'field' => 'shorturl'
            ],
            'v.gd' => [
                'url' => 'https://v.gd/create.php?format=json&url=',
                'method' => 'json',
                'field' => 'shorturl'
            ],
            'tinyurl' => [
                'url' => 'https://tinyurl.com/api-create.php?url=',
                'method' => 'text',
                'field' => null
            ]
        ];
        
        $this->attempts = [];
        $this->lastError = '';
    }
    
    public function shorten($longUrl) {
        // Tenta cada serviço em ordem
        foreach ($this->services as $name => $config) {
            // Limita tentativas por serviço
            if (!isset($this->attempts[$name])) {
                $this->attempts[$name] = ['count' => 0, 'last' => 0];
            }
            
            // Skip se muitas falhas recentes
            if ($this->attempts[$name]['count'] > 3) {
                if (time() - $this->attempts[$name]['last'] < 300) {
                    continue;
                }
                // Reset após 5 minutos
                $this->attempts[$name]['count'] = 0;
            }
            
            $result = $this->tryService($name, $config, $longUrl);
            
            if ($result['ok']) {
                return $result;
            }
            
            $this->attempts[$name]['count']++;
            $this->attempts[$name]['last'] = time();
        }
        
        return [
            'ok' => false,
            'reason' => 'all_services_failed',
            'error' => $this->lastError
        ];
    }
    
    private function tryService($name, $config, $longUrl) {
        $apiUrl = $config['url'] . urlencode($longUrl);
        
        $ch = getCurlHandle($name);
        curl_setopt($ch, CURLOPT_URL, $apiUrl);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        if ($response === false || $httpCode !== 200) {
            $this->lastError = "HTTP $httpCode from $name";
            return ['ok' => false, 'reason' => 'http_error'];
        }
        
        // Parse resposta baseado no tipo
        if ($config['method'] === 'json') {
            $data = json_decode($response, true);
            
            // Verifica erros específicos do serviço
            if (isset($data['errorcode'])) {
                $this->lastError = "Service error {$data['errorcode']} from $name";
                return ['ok' => false, 'reason' => 'service_error_' . $data['errorcode']];
            }
            
            if (!empty($data[$config['field']])) {
                return [
                    'ok' => true,
                    'short' => $data[$config['field']],
                    'service' => $name,
                    'long' => $longUrl
                ];
            }
        } else {
            // Resposta texto simples (tinyurl)
            $shortUrl = trim($response);
            if (filter_var($shortUrl, FILTER_VALIDATE_URL)) {
                return [
                    'ok' => true,
                    'short' => $shortUrl,
                    'service' => $name,
                    'long' => $longUrl
                ];
            }
        }
        
        $this->lastError = "Invalid response from $name";
        return ['ok' => false, 'reason' => 'parse_error'];
    }
    
    public function getLastError() {
        return $this->lastError;
    }
}

/**
 * Processa HTML substituindo links longos por curtos
 * Mantém compatibilidade com código existente
 */
function shortener_batch_process_html($html) {
    // Esta função era esperada pelo emailb.php
    // Mantemos para compatibilidade mas não é usada no novo sistema
    return $html;
}

/**
 * Função auxiliar: gera string aleatória para URLs
 */
if (!function_exists('generateRandomString')) {
    function generateRandomString($length = 8) {
        $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $string = '';
        $max = strlen($chars) - 1;
        for ($i = 0; $i < $length; $i++) {
            $string .= $chars[mt_rand(0, $max)];
        }
        return $string;
    }
}

/**
 * Limpa handles cURL ao final (opcional)
 */
function cleanupCurlHandles() {
    global $__CURL_HANDLES;
    
    foreach ($__CURL_HANDLES as $ch) {
        if (is_resource($ch) || (is_object($ch) && get_class($ch) === 'CurlHandle')) {
            curl_close($ch);
        }
    }
    
    $__CURL_HANDLES = [];
}

// Registra limpeza automática
register_shutdown_function('cleanupCurlHandles');

?>