<?php
/**
 * src/shortener_optimized.php
 * Sistema ÚNICO de encurtamento - v5.1
 * 
 * ORDEM (testada 2026-02-09):
 *   cache → is.gd (65ms) → v.gd (165ms) → da.gd (177ms) → tinyurl (227ms)
 * 
 * USADO POR: send.php (via require_once)
 * NÃO USADO POR: sendx.php, sendy.php (links diretos)
 */

// Reutilizar handles cURL globais para performance
static $__CURL_HANDLES = [];

/**
 * Obtém ou cria handle cURL reutilizável
 */
function getCurlHandle($key = 'default') {
    global $__CURL_HANDLES;
    
    if (!isset($__CURL_HANDLES[$key])) {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_USERAGENT => 'Mozilla/5.0 (Short-Bot/3.0)',
            CURLOPT_CONNECTTIMEOUT => 2,
            CURLOPT_TIMEOUT => 5,
            CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_ENCODING => '',
            CURLOPT_HTTPHEADER => [
                'Connection: keep-alive',
                'Accept: application/json, text/plain',
                'Accept-Language: en-US,en;q=0.9',
                'Cache-Control: no-cache'
            ],
        ]);
        $__CURL_HANDLES[$key] = $ch;
    }
    
    return $__CURL_HANDLES[$key];
}

/**
 * Função principal de encurtamento (compatível com código antigo)
 * Mantém assinatura original para retrocompatibilidade
 */
function shortenUrl($longUrl) {
    static $simpleShortener = null;
    
    if ($simpleShortener === null) {
        $simpleShortener = new SimpleShortener();
    }
    
    $result = $simpleShortener->shorten($longUrl);
    return $result['ok'] ? $result['short'] : false;
}

/**
 * Versão com validação (compatível com shortener_batch_new.php)
 */
function shortenUrlChecked($longUrl) {
    static $shortener = null;
    
    if ($shortener === null) {
        $shortener = new SimpleShortener();
    }
    
    return $shortener->shorten($longUrl);
}

/**
 * Validação rápida de shortlink
 */
function validateShortUrl($shortUrl, $expectedLong = null) {
    $trustedHosts = ['is.gd', 'v.gd', 'da.gd', 'tinyurl.com'];
    $host = parse_url($shortUrl, PHP_URL_HOST);
    
    foreach ($trustedHosts as $trusted) {
        if (stripos($host, $trusted) !== false) {
            return true;
        }
    }
    
    if (!$expectedLong) {
        return true;
    }
    
    $ch = getCurlHandle('head');
    curl_setopt($ch, CURLOPT_URL, $shortUrl);
    curl_setopt($ch, CURLOPT_NOBODY, true);
    curl_setopt($ch, CURLOPT_HEADER, true);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    
    curl_setopt($ch, CURLOPT_NOBODY, false);
    curl_setopt($ch, CURLOPT_HEADER, false);
    
    return ($httpCode >= 300 && $httpCode < 400);
}

/**
 * Classe ÚNICA de encurtamento v5.1
 * 
 * CORREÇÕES v5.1:
 * ✅ Ordem corrigida por velocidade (is.gd primeiro, não da.gd)
 * ✅ Removido cooldown de 5 minutos (muito conservador)
 * ✅ Adicionado da.gd na lista de confiáveis
 * ✅ is.gd e v.gd usam format=simple (mais rápido que JSON)
 * ✅ Estatísticas por serviço acessíveis
 */
class SimpleShortener {
    private $services;
    private $lastError;
    private $lastService;
    private $stats;
    
    public function __construct() {
        // Ordem por velocidade (testada 2026-02-09)
        $this->services = [
            'is.gd' => [
                'url' => 'https://is.gd/create.php?format=simple&url=',
                'method' => 'text',
            ],
            'v.gd' => [
                'url' => 'https://v.gd/create.php?format=simple&url=',
                'method' => 'text',
            ],
            'da.gd' => [
                'url' => 'https://da.gd/s?url=',
                'method' => 'text',
            ],
            'tinyurl' => [
                'url' => 'https://tinyurl.com/api-create.php?url=',
                'method' => 'text',
            ],
        ];
        
        $this->stats = [];
        foreach (array_keys($this->services) as $name) {
            $this->stats[$name] = ['success' => 0, 'fail' => 0];
        }
        
        $this->lastError = '';
        $this->lastService = '';
    }
    
    /**
     * Tenta encurtar com TODOS os serviços em sequência
     * 
     * Retorna:
     *   ['ok' => true,  'short' => 'https://...', 'service' => 'is.gd', 'long' => '...']
     *   ['ok' => false, 'reason' => 'all_services_failed', 'error' => '...']
     */
    public function shorten($longUrl) {
        $serviceNames = array_keys($this->services);
        
        foreach ($this->services as $name => $config) {
            $result = $this->tryService($name, $config, $longUrl);
            
            if ($result['ok']) {
                $this->stats[$name]['success']++;
                $this->lastService = $name;
                return $result;
            }
            
            $this->stats[$name]['fail']++;
            
            // Mostra qual falhou e qual será o próximo
            $currentIndex = array_search($name, $serviceNames);
            $nextService = $serviceNames[$currentIndex + 1] ?? null;
            
            if ($nextService) {
                if (function_exists('writeLn')) {
                    writeLn("    $name falhou, tentando $nextService...");
                }
            } else {
                if (function_exists('writeLn')) {
                    writeLn("    $name falhou - TODOS os servicos falharam!");
                }
            }
        }
        
        return [
            'ok' => false,
            'reason' => 'all_services_failed',
            'error' => $this->lastError
        ];
    }
    
    private function tryService($name, $config, $longUrl) {
        $apiUrl = $config['url'] . urlencode($longUrl);
        
        $ch = getCurlHandle($name);
        curl_setopt($ch, CURLOPT_URL, $apiUrl);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        if ($response === false || $httpCode !== 200) {
            $this->lastError = "HTTP $httpCode from $name";
            return ['ok' => false, 'reason' => 'http_error'];
        }
        
        $shortUrl = trim($response);
        
        if (filter_var($shortUrl, FILTER_VALIDATE_URL)) {
            return [
                'ok' => true,
                'short' => $shortUrl,
                'service' => $name,
                'long' => $longUrl
            ];
        }
        
        $this->lastError = "Invalid response from $name: " . substr($response, 0, 100);
        return ['ok' => false, 'reason' => 'parse_error'];
    }
    
    public function getLastError() {
        return $this->lastError;
    }
    
    public function getLastService() {
        return $this->lastService;
    }
    
    public function getStats() {
        return $this->stats;
    }
}

/**
 * Processa HTML substituindo links longos por curtos
 * Mantém compatibilidade com código existente
 */
function shortener_batch_process_html($html) {
    return $html;
}

/**
 * Função auxiliar: gera string aleatória para URLs
 */
if (!function_exists('generateRandomString')) {
    function generateRandomString($length = 8) {
        $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $string = '';
        $max = strlen($chars) - 1;
        for ($i = 0; $i < $length; $i++) {
            $string .= $chars[mt_rand(0, $max)];
        }
        return $string;
    }
}

/**
 * Limpa handles cURL ao final
 */
function cleanupCurlHandles() {
    global $__CURL_HANDLES;
    
    foreach ($__CURL_HANDLES as $ch) {
        if (is_resource($ch) || (is_object($ch) && get_class($ch) === 'CurlHandle')) {
            curl_close($ch);
        }
    }
    
    $__CURL_HANDLES = [];
}

register_shutdown_function('cleanupCurlHandles');

?>