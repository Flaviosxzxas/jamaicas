<?php
declare(strict_types=1);

/**
 * emailb_fixed.php
 * Versão CORRIGIDA do emailb.php com os 3 bugs resolvidos
 * + Sincronização de título HTML com assunto (APENAS ISSO FOI ADICIONADO)
 * Envio de e-mail robusto (QP + CRLF, VERP, unsubscribe seguro)
 * Requer helpers de term.php (getMainDomain, generateMessageID, random helpers, etc.)
 */

require_once __DIR__ . '/term.php';

/* ------------------------- Defaults/guards de config ------------------------- */
if (!defined('USE_VERP'))           define('USE_VERP', true);
if (!defined('VERP_PREFIX'))        define('VERP_PREFIX', 'bounce');
if (!defined('VERP_SEP'))           define('VERP_SEP', '+');
if (!defined('UNSUB_SECRET'))       define('UNSUB_SECRET', 'Gx9pT3aQ1mRxW7bY5kW2nH8cV4sL0');
if (!defined('UNSUB_VALID_SECS'))   define('UNSUB_VALID_SECS', 60 * 60 * 24 * 30); // 30 dias
if (!defined('ADD_AUTO_SUBMITTED')) define('ADD_AUTO_SUBMITTED', false);

/* --------------------------- Fallback de logging ----------------------------- */
if (!function_exists('debugLn')) {
    function debugLn(string $s): void {
        if (PHP_SAPI === 'cli') {
            fwrite(STDOUT, $s . "\n"); // evite PHP_EOL pra não poluir CRLF do corpo
        }
    }
}

/* ---------------------- Utils específicos deste arquivo ---------------------- */

/**
 * NOVA FUNÇÃO: Sincroniza o título HTML com o assunto do email para evitar HTML_TITLE_SUBJ_DIFF
 */
function syncHtmlTitle(string $html, string $subject): string {
    // Remove número de referência do assunto se houver (#123456)
    $cleanSubject = preg_replace('/\s*[\(\#]\d+[\)]*\s*$/', '', $subject);
    $cleanSubject = htmlspecialchars($cleanSubject, ENT_QUOTES, 'UTF-8');
    
    // Se já tem <title>, substitui
    if (preg_match('/<title[^>]*>.*?<\/title>/i', $html)) {
        $html = preg_replace(
            '/<title[^>]*>.*?<\/title>/i',
            '<title>' . $cleanSubject . '</title>',
            $html
        );
    } 
    // Se não tem <title> mas tem <head>, adiciona
    elseif (preg_match('/<head[^>]*>/i', $html)) {
        $html = preg_replace(
            '/(<head[^>]*>)/i',
            '$1<title>' . $cleanSubject . '</title>',
            $html
        );
    }
    // Se não tem <head> mas tem <html>, adiciona head com title
    elseif (preg_match('/<html[^>]*>/i', $html)) {
        $html = preg_replace(
            '/(<html[^>]*>)/i',
            '$1<head><title>' . $cleanSubject . '</title></head>',
            $html
        );
    }
    // Se não tem estrutura HTML, adiciona completa
    elseif (!preg_match('/<html/i', $html)) {
        $html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>' . 
                $cleanSubject . 
                '</title></head><body>' . $html . '</body></html>';
    }
    
    return $html;
}

/** Converte HTML em texto simples preservando links [texto (url)] e removendo excesso de espaços/linhas */
function htmlToText(string $html): string {
    // 1) remove CSS/JS/comentários
    $html = preg_replace('~<(script|style)[^>]*>.*?</\1>~is', '', $html);
    $html = preg_replace('~<!--.*?-->~s', '', $html);

    // 2) links -> "Texto [URL]"
    $html = preg_replace_callback(
        '~<a\s+[^>]*href=["\']?([^"\']+)["\']?[^>]*>(.*?)</a>~is',
        function($m){
            $text = trim(strip_tags($m[2]));
            return $text !== '' ? $text.' ['.$m[1].']' : $m[1];
        },
        $html
    );

    // 3) blocos e listas viram quebras de linha/bullets
    $html = preg_replace('~<\s*br\s*/?>~i', "\n", $html);
    $html = preg_replace('~</\s*(p|div|section|article|header|footer|h[1-6]|tr)\s*>~i', "\n\n", $html);
    $html = preg_replace('~<\s*(ul|ol)\b[^>]*>~i', "\n", $html);
    $html = preg_replace('~<\s*li\b[^>]*>~i', "- ", $html);
    $html = preg_replace('~</\s*li\s*>~i', "\n", $html);

    // 4) decodifica entidades e remove tags
    $text = html_entity_decode($html, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $text = strip_tags($text);

    // 5) normaliza espaços/indentação e linhas vazias
    $text = preg_replace("/[ \t]+/u", ' ', $text);           // espaços repetidos -> 1
    $text = preg_replace("/^\h+/mu", '', $text);             // tira indentação no início da linha
    $text = preg_replace("/\h+$/mu", '', $text);             // tira espaços no fim da linha
    $text = preg_replace("/(\r\n|\r|\n){3,}/", "\n\n", $text); // máximo 1 linha vazia
    $text = trim($text);

    // 6) quebra amigável (não quebra URLs muito longas)
    $out = [];
    foreach (preg_split("/\r?\n/", $text) as $line) {
        if (preg_match('~https?://\S{40,}~', $line)) {
            $out[] = $line; // mantém URL longa intacta
        } else {
            $out[] = wordwrap($line, 78, "\r\n", true);
        }
    }
    return implode("\r\n", $out);
}

/** Codifica cabeçalho com UTF-8 (RFC 2047, B-encoding) */
function encodeHeaderRFC2047(string $s): string {
    return preg_match('/[^\x20-\x7E]/', $s)
        ? '=?UTF-8?B?' . base64_encode($s) . '?='
        : $s;
}

/** Gera token HMAC para unsubscribe seguro (e=, ts=, sig=) */
function buildUnsubToken(string $email): array {
    $ts  = time();
    $msg = $email . '|' . $ts;
    $sig = base64_encode(hash_hmac('sha256', $msg, (string)UNSUB_SECRET, true));
    return [$ts, rtrim(strtr($sig, '+/', '-_'), '=')];
}

/** Validação do token (para o seu unsubscribe.php) */
function verifyUnsubToken(string $email, int $ts, string $sig): bool {
    if ((time() - $ts) > (int)UNSUB_VALID_SECS) return false;
    $msg = $email . '|' . $ts;
    $chk = rtrim(strtr(base64_encode(hash_hmac('sha256', $msg, (string)UNSUB_SECRET, true)), '+/', '-_'), '=');
    return hash_equals($chk, $sig);
}

/** Wrapper seguro pro encurtador: nunca quebra o envio */
if (!function_exists('shortener_html_safe')) {
    function shortener_html_safe(string $html): string {
        if (!function_exists('shortener_batch_process_html')) return $html; // shortener ausente -> mantém
        try {
            $res = shortener_batch_process_html($html);
            // Caso 1: retorna string com HTML final
            if (is_string($res) && $res !== '') return $res;
            // Caso 2: retorna array com 'html'/'content'
            if (is_array($res)) {
                if (!empty($res['html']) && is_string($res['html']))   return $res['html'];
                if (!empty($res['content']) && is_string($res['content'])) return $res['content'];
            }
        } catch (Throwable $e) {
            debugLn('[shortener] erro: '.$e->getMessage());
        }
        debugLn('[shortener] falhou; mantendo HTML original');
        return $html; // sempre fallback pro original
    }
}

/* --------------------------------- Envio ------------------------------------ */

/**
 * Envia e-mail multipart/alternative (e opcional anexo PDF) com:
 * - Conteúdos em quoted-printable e CRLF (robusto para DKIM)
 * - VERP para Return-Path por destinatário
 * - List-Unsubscribe (mailto + one-click)
 */
function sendEmail(
    string $sender,
    string $senderEmail,
    string $to,
    string $subject,
    string $content,
    $attachment = '',
    string $attachmentName = ''
) {
    /* ------- Normalização de remetente (aceita domínio sem @ por engano) ------ */
    if (strpos($senderEmail, '@') === false) {
        // Garante um remetente válido caso tenha vindo só o domínio
        $senderEmail = 'contacto@' . ltrim($senderEmail, '@');
    }

    /* -------------------- IDs e variáveis auxiliares -------------------- */
    $attachmentName   = $attachmentName ?: (generateRandomNumber1(3, 16) . '.pdf');
    $currentDateTime  = date('Y-m-d H:i:s');
    $eventGuid        = generateRandomEventGuid();
    $refNumber1       = generateRandomNumber1(5, 10);

    $domain    = getMainDomain($senderEmail);
    $messageID = generateMessageID($domain);

    /* ---------------------- VERP (Return-Path) -------------------------- */
    $verpTag    = bin2hex(hash('crc32b', $to, true)); // tag curta por destinatário
    $useVerp    = defined('USE_VERP') ? (bool)USE_VERP : true;
    $verpPrefix = defined('VERP_PREFIX') ? (string)VERP_PREFIX : 'bounce';
    $verpSep    = defined('VERP_SEP') ? (string)VERP_SEP : '+';

    $bounceAddress = $useVerp
        ? ($verpPrefix . $verpSep . $verpTag . '@' . $domain)
        : ($verpPrefix . '@' . $domain);

    // Parâmetro extra do mail() para envelope sender
    $additionalParams = "-f{$bounceAddress}";

    /* ---------------------- Unsubscribe seguro -------------------------- */
    [$ts, $sig] = buildUnsubToken($to);
    $unsubUrl   = "https://{$domain}/unsubscribe.php?e=" . rawurlencode($to) . "&ts={$ts}&sig={$sig}";

    /* ------------- Substituições no HTML (duas passadas) ---------------- */
    // 0) Normaliza terminadores "%%" acidentais
    $content = preg_replace('/%(random_[A-Za-z0-9_]+)%%/', '%$1%', $content) ?? $content;
    $content = str_replace('%ref_number%', generateRandomRef(), $content);
    // 1) Placeholders fixos
    $map1 = [
        '%subject%'                 => $subject,  // MUDANÇA 2: ADICIONADO placeholder do assunto
        '%current_date_time%'       => $currentDateTime,
        '%recipient_email%'         => $to,
        '%domain%'                  => $domain,
        '[-xxlinkxx-]'              => randomxxlinkxx(),
        '[-mylink-]'                => "?d=%random_New6%&r=%random_New3%",
        '[-mylinkx1-]'              => "?id=%random_New3%",
        '%unsubscribe_link_mailto%' => "mailto:unsubscribe@{$domain}?subject=Remove",
        '%unsubscribe_secure_link%' => $unsubUrl
    ];
    $content = strtr($content, $map1);

    // 2) Placeholders randômicos
    $map2 = [
        '%random_NewString%'        => generateRandomString(12),
        '%random_New0%'             => base64_encode(generatemonospace2(3, 12)),
        '%random_New1%'             => generateRefNumber(),
        '%gerarRFCPessoaFisica%'    => gerarRFCPessoaFisica(),
        '%gerarRFCPessoaJuridica%'  => gerarRFCPessoaJuridica(),
        '%random_New2%'             => generateRandomNumber2(2, 2),
        '%random_New3%'             => generateRandomNumber2(3, 3),
        '%random_New4%'             => generateRandomNumber2(4, 4),
        '%random_New5%'             => generateRandomNumber2(5, 5),
        '%random_New6%'             => generateRandomNumber2(3, 12),
        '%random_New7%'             => generateRandomLetras2(4, 15),
        '%random_New8%'             => generateRandomLetras3(1, 1),
        '%random_New9%'             => generateRandomLetras3(4, 4),
        '%random_New10%'            => generateRandomLetras3(4, 23),
        '%random_New11%'            => generateRandomLetras3(10, 23),
        '%random_New12%'            => generateRandomLetras3(10, 23),
        '%random_New13%'            => generateRandomLetras3(10, 23),
        '%random_New14%'            => generateRandomLetras3(10, 23),
        '%random_New15%'            => generateRandomLetras3(10, 23),
        '%random_New16%'            => generateRandomLetras3(4, 23),
        '%random_New17%'            => generatemonospace2(3, 3),
        '%random_New18%'            => generatemonospace2(4, 5),
        '%random_New19%'            => generatemonospace2(20, 25),
    ];
    $content = strtr($content, $map2);

    // 3) Encurtador com fallback seguro (nunca quebra o envio)
    $content = shortener_html_safe($content);
    
    // MUDANÇA 3: Sincronizar título HTML com o assunto
    $content = syncHtmlTitle($content, $subject);

    // Versão texto
    $textContent = htmlToText($content);

    // Normaliza quebras para CRLF (DKIM-safe)
    $content     = preg_replace("/\r?\n/", "\r\n", $content)     ?? $content;
    $textContent = preg_replace("/\r?\n/", "\r\n", $textContent) ?? $textContent;

    // Codifica leaf parts em QUOTED-PRINTABLE (evita reencode no trânsito)
    $qpHtml = quoted_printable_encode($content);
    $qpText = quoted_printable_encode($textContent);

    // Aviso se sobrar placeholder sem substituir
    if (preg_match_all('/%[A-Za-z0-9_]+%/', $content, $m) && !empty($m[0])) {
        debugLn('[WARN] Placeholders não substituídos: ' . implode(', ', array_unique($m[0])));
    }

    /* --------------------------- Cabeçalhos ----------------------------- */
    $fromHeader = sprintf('%s <%s>', encodeHeaderRFC2047($sender), $senderEmail);
    $subjectEnc = encodeHeaderRFC2047($subject);

    $baseHeaders = [
        "From: {$fromHeader}",
        "Date: " . date(DATE_RFC2822),
        "Message-ID: {$messageID}",
        "MIME-Version: 1.0",
        "Content-Language: es",
        "Accept-Language: es-419, es, en",
		"X-Priority: 3",
        "X-Campaign-ID: " . date('Ym') . "-{$refNumber1}",
        "X-EventGuid: {$eventGuid}",
        "List-Unsubscribe: <{$unsubUrl}>, <mailto:unsubscribe@{$domain}?subject=Remove>",
        "List-Unsubscribe-Post: List-Unsubscribe=One-Click",
		"Precedence: bulk",
    ];
    if (ADD_AUTO_SUBMITTED) {
        $baseHeaders[] = "Auto-Submitted: auto-generated";
    }

    /* --------------------------- Corpo / MIME --------------------------- */
    
    // CORREÇÃO 3: Melhor detecção de anexo (suporta path E conteúdo binário)
    $hasAttachment = false;
    $attachmentContent = '';
    
    if (!empty($attachment)) {
        if (is_string($attachment)) {
            // Verifica se é um caminho de arquivo
            if (@is_file($attachment)) {
                $attachmentContent = file_get_contents($attachment);
                $hasAttachment = true;
            } else {
                // Assume que é conteúdo binário direto
                $attachmentContent = $attachment;
                $hasAttachment = true;
            }
        }
    }

    if (!$hasAttachment) {
        // multipart/alternative (plain + html)
        $altBoundary = hash('sha256', microtime() . random_bytes(8));
        $headers = array_merge($baseHeaders, [
            "Content-Type: multipart/alternative; boundary=\"{$altBoundary}\""
        ]);

        $parts = [
            "--{$altBoundary}",
            "Content-Type: text/plain; charset=\"UTF-8\"",
            "Content-Transfer-Encoding: quoted-printable",
            "Content-Disposition: inline",
            '',
            $qpText,
            '',
            "--{$altBoundary}",
            "Content-Type: text/html; charset=\"UTF-8\"",
            "Content-Transfer-Encoding: quoted-printable",
            "Content-Disposition: inline",
            '',
            $qpHtml,
            '',
            "--{$altBoundary}--"
        ];
        $msg = implode("\r\n", $parts);

    } else {
        // multipart/mixed (corpo alternative + anexo)
        $mixedBoundary = hash('sha256', microtime() . random_bytes(8));
        $altBoundary   = hash('sha256', microtime() . random_bytes(8));

        $headers = array_merge($baseHeaders, [
            "Content-Type: multipart/mixed; boundary=\"{$mixedBoundary}\""
        ]);

        // Parte 1: alternative
        $parts = [];
        $parts[] = "--{$mixedBoundary}";
        $parts[] = "Content-Type: multipart/alternative; boundary=\"{$altBoundary}\"";
        $parts[] = '';
        // plain
        $parts[] = "--{$altBoundary}";
        $parts[] = "Content-Type: text/plain; charset=\"UTF-8\"";
        $parts[] = "Content-Transfer-Encoding: quoted-printable";
        $parts[] = "Content-Disposition: inline";
        $parts[] = '';
        $parts[] = $qpText;
        $parts[] = '';
        // html
        $parts[] = "--{$altBoundary}";
        $parts[] = "Content-Type: text/html; charset=\"UTF-8\"";
        $parts[] = "Content-Transfer-Encoding: quoted-printable";
        $parts[] = "Content-Disposition: inline";
        $parts[] = '';
        $parts[] = $qpHtml;
        $parts[] = '';
        $parts[] = "--{$altBoundary}--";
        $parts[] = '';

        // Parte 2: anexo (PDF)
        $attachmentEncoded = chunk_split(base64_encode($attachmentContent));
        $safeFilename      = basename($attachmentName);

        $parts[] = "--{$mixedBoundary}";
        $parts[] = "Content-Type: application/pdf; name=\"{$safeFilename}\"";
        $parts[] = "Content-Transfer-Encoding: base64";
        $parts[] = "Content-Disposition: attachment; filename=\"{$safeFilename}\"";
        $parts[] = '';
        $parts[] = $attachmentEncoded;
        $parts[] = '';

        // Fecha mixed
        $parts[] = "--{$mixedBoundary}--";

        $msg = implode("\r\n", $parts);
    }

    // Une headers
    $headersStr = implode("\r\n", $headers);
    
    // CORREÇÃO 1: REMOVIDA a linha problemática que deletava o header To:
    // NÃO fazer: $headersStr = preg_replace('/^\s*To:.*\r?\n/mi', '', $headersStr);

    // Debug condicional - só executa se EMAIL_DEBUG for true
    if (EMAIL_DEBUG) {
        debugLn('');
        debugLn('Assunto (poss. codificado):');
        debugLn($subjectEnc);
        debugLn('');
        debugLn('Cabeçalho:');
        debugLn($headersStr);
        debugLn('');
        debugLn('Mensagem (primeiros 500 chars):');
        debugLn(substr($msg, 0, 500) . '...');
    }
    
    // Envia com envelope sender correto
    return mail($to, $subjectEnc, $msg, $headersStr, $additionalParams);
}

/**
 * Função de teste para verificar se o sistema está funcionando
 */
function testEmailSending(string $testTo = 'test@example.com'): bool {
    debugLn("\n=== TESTE DE ENVIO ===");
    
    $html = <<<HTML
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Email de Teste</title>
</head>
<body>
    <h1>Teste do Sistema</h1>
    <p>Este email foi enviado em %current_date_time%</p>
    <p>Para: %recipient_email%</p>
    <p>Número aleatório: %random_New5%</p>
    <p>RFC Pessoa Física: %gerarRFCPessoaFisica%</p>
    <hr>
    <p><a href="%unsubscribe_secure_link%">Descadastrar</a></p>
</body>
</html>
HTML;
    
    $result = sendEmail(
        'Sistema Teste',
        'noreply@example.com',
        $testTo,
        'Teste EmailB Fixed',
        $html
    );
    
    debugLn($result ? "✅ Teste passou!" : "❌ Teste falhou!");
    return $result;
}