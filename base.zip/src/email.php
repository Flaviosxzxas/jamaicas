<?php
declare(strict_types=1);

/**
 * email_fixed.php
 * Versão CORRIGIDA com validação robusta de domínio para evitar MX_INVALID
 * - Força uso do domínio correto do servidor
 * - Valida e sanitiza sender email
 * - Previne uso de domínios órfãos no Return-Path/VERP
 */

require_once __DIR__ . '/term.php';

/* ------------------------- Defaults/guards de config ------------------------- */
if (!defined('USE_VERP'))           define('USE_VERP', true);
if (!defined('VERP_PREFIX'))        define('VERP_PREFIX', 'bounce');
if (!defined('VERP_SEP'))           define('VERP_SEP', '+');
if (!defined('UNSUB_SECRET'))       define('UNSUB_SECRET', 'Gx9pT3aQ1mRxW7bY5kW2nH8cV4sL0');
if (!defined('UNSUB_VALID_SECS'))   define('UNSUB_VALID_SECS', 60 * 60 * 24 * 30);
if (!defined('ADD_AUTO_SUBMITTED')) define('ADD_AUTO_SUBMITTED', false);

// NOVO: Define o domínio do servidor (usar variável de ambiente ou hostname)
if (!defined('SERVER_DOMAIN')) {
    $serverDomain = getenv('SERVER_DOMAIN') ?: gethostname();
    if ($serverDomain && strpos($serverDomain, '.') !== false) {
        define('SERVER_DOMAIN', $serverDomain);
    } else {
        // Fallback: tentar ler do Postfix
        $myhostname = trim(shell_exec('postconf -h myhostname 2>/dev/null') ?: '');
        define('SERVER_DOMAIN', $myhostname ?: 'localhost.localdomain');
    }
}

/* --------------------------- Fallback de logging ----------------------------- */
if (!function_exists('debugLn')) {
    function debugLn(string $s): void {
        if (PHP_SAPI === 'cli') {
            fwrite(STDOUT, $s . "\n");
        }
    }
}

/* ---------------------- Utils específicos deste arquivo ---------------------- */

/**
 * NOVA FUNÇÃO: Valida e corrige domínio do remetente
 */
function validateAndFixDomain(string $email): array {
    // Lista de domínios inválidos/órfãos conhecidos
    $invalidDomains = [
        'miyasced.com',
        'inspireongz',
        'localhost',
        'example.com',
        'test.com',
        'invalid.com'
    ];
    
    // Extrair domínio do email
    $parts = explode('@', $email);
    if (count($parts) !== 2) {
        return ['valid' => false, 'domain' => SERVER_DOMAIN, 'email' => 'noreply@' . SERVER_DOMAIN];
    }
    
    list($localPart, $domain) = $parts;
    $domain = strtolower(trim($domain));
    
    // Verificar se é domínio inválido
    foreach ($invalidDomains as $invalid) {
        if (stripos($domain, $invalid) !== false) {
            debugLn('[WARN] Domínio inválido detectado: ' . $domain . ' -> usando ' . SERVER_DOMAIN);
            return [
                'valid' => false,
                'domain' => SERVER_DOMAIN,
                'email' => $localPart . '@' . SERVER_DOMAIN,
                'original_domain' => $domain
            ];
        }
    }
    
    // Domínio válido
    return ['valid' => true, 'domain' => $domain, 'email' => $email];
}

/**
 * Sincroniza o título HTML com o assunto do email
 */
function syncHtmlTitle(string $html, string $subject): string {
    $cleanSubject = preg_replace('/\s*[\(\#]\d+[\)]*\s*$/', '', $subject);
    $cleanSubject = htmlspecialchars($cleanSubject, ENT_QUOTES, 'UTF-8');
    
    if (preg_match('/<title[^>]*>.*?<\/title>/i', $html)) {
        $html = preg_replace(
            '/<title[^>]*>.*?<\/title>/i',
            '<title>' . $cleanSubject . '</title>',
            $html
        );
    } 
    elseif (preg_match('/<head[^>]*>/i', $html)) {
        $html = preg_replace(
            '/(<head[^>]*>)/i',
            '$1<title>' . $cleanSubject . '</title>',
            $html
        );
    }
    elseif (preg_match('/<html[^>]*>/i', $html)) {
        $html = preg_replace(
            '/(<html[^>]*>)/i',
            '$1<head><title>' . $cleanSubject . '</title></head>',
            $html
        );
    }
    elseif (!preg_match('/<html/i', $html)) {
        $html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>' . 
                $cleanSubject . 
                '</title></head><body>' . $html . '</body></html>';
    }
    
    return $html;
}

/** Converte HTML em texto simples */
function htmlToText(string $html): string {
    $html = preg_replace('~<(script|style)[^>]*>.*?</\1>~is', '', $html);
    $html = preg_replace('~<!--.*?-->~s', '', $html);

    $html = preg_replace_callback(
        '~<a\s+[^>]*href=["\']?([^"\']+)["\']?[^>]*>(.*?)</a>~is',
        function($m){
            $text = trim(strip_tags($m[2]));
            return $text !== '' ? $text.' ['.$m[1].']' : $m[1];
        },
        $html
    );

    $html = preg_replace('~<\s*br\s*/?>~i', "\n", $html);
    $html = preg_replace('~</\s*(p|div|section|article|header|footer|h[1-6]|tr)\s*>~i', "\n\n", $html);
    $html = preg_replace('~<\s*(ul|ol)\b[^>]*>~i', "\n", $html);
    $html = preg_replace('~<\s*li\b[^>]*>~i', "- ", $html);
    $html = preg_replace('~</\s*li\s*>~i', "\n", $html);

    $text = html_entity_decode($html, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $text = strip_tags($text);

    $text = preg_replace("/[ \t]+/u", ' ', $text);
    $text = preg_replace("/^\h+/mu", '', $text);
    $text = preg_replace("/\h+$/mu", '', $text);
    $text = preg_replace("/(\r\n|\r|\n){3,}/", "\n\n", $text);
    $text = trim($text);

    $out = [];
    foreach (preg_split("/\r?\n/", $text) as $line) {
        if (preg_match('~https?://\S{40,}~', $line)) {
            $out[] = $line;
        } else {
            $out[] = wordwrap($line, 78, "\r\n", true);
        }
    }
    return implode("\r\n", $out);
}

/** Codifica cabeçalho com UTF-8 (RFC 2047, B-encoding) */
function encodeHeaderRFC2047(string $s): string {
    return preg_match('/[^\x20-\x7E]/', $s)
        ? '=?UTF-8?B?' . base64_encode($s) . '?='
        : $s;
}

/** Gera token HMAC para unsubscribe seguro */
function buildUnsubToken(string $email): array {
    $ts  = time();
    $msg = $email . '|' . $ts;
    $sig = base64_encode(hash_hmac('sha256', $msg, (string)UNSUB_SECRET, true));
    return [$ts, rtrim(strtr($sig, '+/', '-_'), '=')];
}

/** Validação do token */
function verifyUnsubToken(string $email, int $ts, string $sig): bool {
    if ((time() - $ts) > (int)UNSUB_VALID_SECS) return false;
    $msg = $email . '|' . $ts;
    $chk = rtrim(strtr(base64_encode(hash_hmac('sha256', $msg, (string)UNSUB_SECRET, true)), '+/', '-_'), '=');
    return hash_equals($chk, $sig);
}

/** Wrapper seguro pro encurtador */
if (!function_exists('shortener_html_safe')) {
    function shortener_html_safe(string $html): string {
        if (!function_exists('shortener_batch_process_html')) return $html;
        try {
            $res = shortener_batch_process_html($html);
            if (is_string($res) && $res !== '') return $res;
            if (is_array($res)) {
                if (!empty($res['html']) && is_string($res['html']))   return $res['html'];
                if (!empty($res['content']) && is_string($res['content'])) return $res['content'];
            }
        } catch (Throwable $e) {
            debugLn('[shortener] erro: '.$e->getMessage());
        }
        return $html;
    }
}

/* --------------------------------- Envio ------------------------------------ */

/**
 * FUNÇÃO PRINCIPAL CORRIGIDA
 */
function sendEmail(
    string $sender,
    string $senderEmail,
    string $to,
    string $subject,
    string $content,
    $attachment = '',
    string $attachmentName = ''
) {
    /* ============= CORREÇÃO CRÍTICA: VALIDAÇÃO DE DOMÍNIO ============= */
    
    // 1. Normalizar se vier sem @
    if (strpos($senderEmail, '@') === false) {
        $senderEmail = 'noreply@' . ltrim($senderEmail, '@');
        debugLn('[INFO] Sender normalizado: ' . $senderEmail);
    }
    
    // 2. Validar formato básico
    if (!filter_var($senderEmail, FILTER_VALIDATE_EMAIL)) {
        debugLn('[ERROR] Email remetente inválido: ' . $senderEmail);
        $senderEmail = 'noreply@' . SERVER_DOMAIN;
        debugLn('[INFO] Usando fallback: ' . $senderEmail);
    }
    
    // 3. CRÍTICO: Validar e corrigir domínio
    $domainCheck = validateAndFixDomain($senderEmail);
    if (!$domainCheck['valid']) {
        debugLn('[WARN] Domínio corrigido automaticamente');
        debugLn('[WARN] Original: ' . ($domainCheck['original_domain'] ?? 'N/A'));
        debugLn('[WARN] Novo: ' . $domainCheck['domain']);
        $senderEmail = $domainCheck['email'];
    }
    
    $domain = $domainCheck['domain'];
    
    // 4. Garantir que o domínio final é válido
    if (empty($domain) || strpos($domain, '.') === false) {
        debugLn('[ERROR] Domínio final inválido, abortando');
        return false;
    }
    
    debugLn('[OK] Usando domínio validado: ' . $domain);
    debugLn('[OK] Sender final: ' . $senderEmail);

    /* ==================== Resto do código original ==================== */
    
    $attachmentName   = $attachmentName ?: (generateRandomNumber1(3, 16) . '.pdf');
    $currentDateTime  = date('Y-m-d H:i:s');
    $eventGuid        = generateRandomEventGuid();
    $refNumber1       = generateRandomNumber1(5, 10);

    $messageID = generateMessageID($domain);

    /* ---------------------- VERP (Return-Path) -------------------------- */
    $verpTag    = bin2hex(hash('crc32b', $to, true));
    $useVerp    = defined('USE_VERP') ? (bool)USE_VERP : true;
    $verpPrefix = defined('VERP_PREFIX') ? (string)VERP_PREFIX : 'bounce';
    $verpSep    = defined('VERP_SEP') ? (string)VERP_SEP : '+';

    $bounceAddress = $useVerp
        ? ($verpPrefix . $verpSep . $verpTag . '@' . $domain)
        : ($verpPrefix . '@' . $domain);

    $additionalParams = "-f{$bounceAddress}";
    
    debugLn('[OK] Bounce address: ' . $bounceAddress);

    /* ---------------------- Unsubscribe seguro -------------------------- */
    [$ts, $sig] = buildUnsubToken($to);
    $unsubUrl   = "https://{$domain}/unsubscribe.php?e=" . rawurlencode($to) . "&ts={$ts}&sig={$sig}";

    /* ------------- Substituições no HTML ------------------------- */
    $content = preg_replace('/%(random_[A-Za-z0-9_]+)%%/', '%$1%', $content) ?? $content;
    $content = str_replace('%ref_number%', generateRandomRef(), $content);
    
    $map1 = [
        '%subject%'                 => $subject,
        '%current_date_time%'       => $currentDateTime,
        '%recipient_email%'         => $to,
        '%domain%'                  => $domain,
        '[-xxlinkxx-]'              => randomxxlinkxx(),
        '[-mylink-]'                => "?d=%random_New6%&r=%random_New3%",
        '[-mylinkx1-]'              => "?id=%random_New3%",
        '%unsubscribe_link_mailto%' => "mailto:unsubscribe@{$domain}?subject=Remove",
        '%unsubscribe_secure_link%' => $unsubUrl
    ];
    $content = strtr($content, $map1);

    $map2 = [
        '%random_NewString%'        => generateRandomString(12),
        '%random_New0%'             => base64_encode(generatemonospace2(3, 12)),
        '%random_New1%'             => generateRefNumber(),
        '%gerarRFCPessoaFisica%'    => gerarRFCPessoaFisica(),
        '%gerarRFCPessoaJuridica%'  => gerarRFCPessoaJuridica(),
        '%random_New2%'             => generateRandomNumber2(2, 2),
        '%random_New3%'             => generateRandomNumber2(3, 3),
        '%random_New4%'             => generateRandomNumber2(4, 4),
        '%random_New5%'             => generateRandomNumber2(5, 5),
        '%random_New6%'             => generateRandomNumber2(3, 12),
        '%random_New7%'             => generateRandomLetras2(4, 15),
        '%random_New8%'             => generateRandomLetras3(1, 1),
        '%random_New9%'             => generateRandomLetras3(4, 4),
        '%random_New10%'            => generateRandomLetras3(4, 23),
        '%random_New11%'            => generateRandomLetras3(10, 23),
        '%random_New12%'            => generateRandomLetras3(10, 23),
        '%random_New13%'            => generateRandomLetras3(10, 23),
        '%random_New14%'            => generateRandomLetras3(10, 23),
        '%random_New15%'            => generateRandomLetras3(10, 23),
        '%random_New16%'            => generateRandomLetras3(4, 23),
        '%random_New17%'            => generatemonospace2(3, 3),
        '%random_New18%'            => generatemonospace2(4, 5),
        '%random_New19%'            => generatemonospace2(20, 25),
    ];
    $content = strtr($content, $map2);

    $content = shortener_html_safe($content);
    $content = syncHtmlTitle($content, $subject);

    $textContent = htmlToText($content);

    $content     = preg_replace("/\r?\n/", "\r\n", $content)     ?? $content;
    $textContent = preg_replace("/\r?\n/", "\r\n", $textContent) ?? $textContent;

    $qpHtml = quoted_printable_encode($content);
    $qpText = quoted_printable_encode($textContent);

    if (preg_match_all('/%[A-Za-z0-9_]+%/', $content, $m) && !empty($m[0])) {
        debugLn('[WARN] Placeholders não substituídos: ' . implode(', ', array_unique($m[0])));
    }

    /* --------------------------- Cabeçalhos ----------------------------- */
    $fromHeader = sprintf('%s <%s>', encodeHeaderRFC2047($sender), $senderEmail);
    $subjectEnc = encodeHeaderRFC2047($subject);

    $baseHeaders = [
        "From: {$fromHeader}",
        "Date: " . date(DATE_RFC2822),
        "Message-ID: {$messageID}",
        "MIME-Version: 1.0",
        "Content-Language: es",
        "Accept-Language: es-419, es, en",
        "X-Priority: 3",
        "X-Campaign-ID: " . date('Ym') . "-{$refNumber1}",
        "X-EventGuid: {$eventGuid}",
        "List-Unsubscribe: <{$unsubUrl}>, <mailto:unsubscribe@{$domain}?subject=Remove>",
        "List-Unsubscribe-Post: List-Unsubscribe=One-Click",
        "Precedence: bulk",
    ];
    if (ADD_AUTO_SUBMITTED) {
        $baseHeaders[] = "Auto-Submitted: auto-generated";
    }

    /* --------------------------- Corpo / MIME --------------------------- */
    
    $hasAttachment = false;
    $attachmentContent = '';
    
    if (!empty($attachment)) {
        if (is_string($attachment)) {
            if (@is_file($attachment)) {
                $attachmentContent = file_get_contents($attachment);
                $hasAttachment = true;
            } else {
                $attachmentContent = $attachment;
                $hasAttachment = true;
            }
        }
    }

    if (!$hasAttachment) {
        $altBoundary = hash('sha256', microtime() . random_bytes(8));
        $headers = array_merge($baseHeaders, [
            "Content-Type: multipart/alternative; boundary=\"{$altBoundary}\""
        ]);

        $parts = [
            "--{$altBoundary}",
            "Content-Type: text/plain; charset=\"UTF-8\"",
            "Content-Transfer-Encoding: quoted-printable",
            "Content-Disposition: inline",
            '',
            $qpText,
            '',
            "--{$altBoundary}",
            "Content-Type: text/html; charset=\"UTF-8\"",
            "Content-Transfer-Encoding: quoted-printable",
            "Content-Disposition: inline",
            '',
            $qpHtml,
            '',
            "--{$altBoundary}--"
        ];
        $msg = implode("\r\n", $parts);

    } else {
        $mixedBoundary = hash('sha256', microtime() . random_bytes(8));
        $altBoundary   = hash('sha256', microtime() . random_bytes(8));

        $headers = array_merge($baseHeaders, [
            "Content-Type: multipart/mixed; boundary=\"{$mixedBoundary}\""
        ]);

        $parts = [];
        $parts[] = "--{$mixedBoundary}";
        $parts[] = "Content-Type: multipart/alternative; boundary=\"{$altBoundary}\"";
        $parts[] = '';
        $parts[] = "--{$altBoundary}";
        $parts[] = "Content-Type: text/plain; charset=\"UTF-8\"";
        $parts[] = "Content-Transfer-Encoding: quoted-printable";
        $parts[] = "Content-Disposition: inline";
        $parts[] = '';
        $parts[] = $qpText;
        $parts[] = '';
        $parts[] = "--{$altBoundary}";
        $parts[] = "Content-Type: text/html; charset=\"UTF-8\"";
        $parts[] = "Content-Transfer-Encoding: quoted-printable";
        $parts[] = "Content-Disposition: inline";
        $parts[] = '';
        $parts[] = $qpHtml;
        $parts[] = '';
        $parts[] = "--{$altBoundary}--";
        $parts[] = '';

        $attachmentEncoded = chunk_split(base64_encode($attachmentContent));
        $safeFilename      = basename($attachmentName);

        $parts[] = "--{$mixedBoundary}";
        $parts[] = "Content-Type: application/pdf; name=\"{$safeFilename}\"";
        $parts[] = "Content-Transfer-Encoding: base64";
        $parts[] = "Content-Disposition: attachment; filename=\"{$safeFilename}\"";
        $parts[] = '';
        $parts[] = $attachmentEncoded;
        $parts[] = '';
        $parts[] = "--{$mixedBoundary}--";

        $msg = implode("\r\n", $parts);
    }

    $headersStr = implode("\r\n", $headers);
    
    if (defined('EMAIL_DEBUG') && EMAIL_DEBUG) {
        debugLn('');
        debugLn('=== DEBUG ===');
        debugLn('From: ' . $senderEmail);
        debugLn('Bounce: ' . $bounceAddress);
        debugLn('Domain: ' . $domain);
        debugLn('To: ' . $to);
        debugLn('Subject: ' . $subjectEnc);
    }
    
    return mail($to, $subjectEnc, $msg, $headersStr, $additionalParams);
}

/**
 * Função de teste
 */
function testEmailSending(string $testTo = 'test@example.com'): bool {
    debugLn("\n=== TESTE DE ENVIO ===");
    debugLn("Domínio do servidor: " . SERVER_DOMAIN);
    
    $html = <<<HTML
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Email de Teste</title>
</head>
<body>
    <h1>Teste do Sistema</h1>
    <p>Este email foi enviado em %current_date_time%</p>
    <p>Para: %recipient_email%</p>
    <p>Domínio: %domain%</p>
    <hr>
    <p><a href="%unsubscribe_secure_link%">Descadastrar</a></p>
</body>
</html>
HTML;
    
    $result = sendEmail(
        'Sistema Teste',
        'noreply@' . SERVER_DOMAIN,
        $testTo,
        'Teste Email Fixed',
        $html
    );
    
    debugLn($result ? "✓ Teste passou!" : "✗ Teste falhou!");
    return $result;
}