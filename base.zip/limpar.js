const { exec } = require('child_process');

// Função para executar um comando shell e retornar uma promessa
function shellExec(command) {
    return new Promise((resolve, reject) => {
        exec(command, (error, stdout, stderr) => {
            if (error) {
                reject(new Error(`Erro ao executar o comando: ${command}\n${stderr}`));
                return;
            }
            resolve(stdout.trim());
        });
    });
}

async function cleanQueueAndRestartServices() {
    try {
        // Limpar a fila de e-mails do Postfix
        console.log("Limpando a fila de e-mails do Postfix...");
        await shellExec('sudo postsuper -d ALL');
        console.log("Fila de e-mails limpa com sucesso!");

        // Reiniciar Postfix
        console.log("Reiniciando o Postfix...");
        await shellExec('sudo systemctl restart postfix');
        console.log("Postfix reiniciado com sucesso!");

        // Verificar status do Postfix
        console.log("Verificando o status do Postfix...");
        const postfixStatus = await shellExec('sudo systemctl status postfix --no-pager');
        console.log("Status do Postfix:\n", postfixStatus);

    } catch (error) {
        console.error("Erro ao executar a ação:", error.message);
    }
}

// Executar a função
cleanQueueAndRestartServices();
