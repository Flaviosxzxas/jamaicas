const { exec } = require('child_process');

// Função para executar comando - não rejeita em erros
function shellExec(command) {
    return new Promise((resolve) => {
        exec(command, { timeout: 15000 }, (error, stdout, stderr) => {
            if (error) {
                resolve({ success: false, output: stderr || error.message });
                return;
            }
            resolve({ success: true, output: stdout.trim() });
        });
    });
}

async function cleanQueueAndRestartServices() {
    const myPid = process.pid;
    let result;

    // 1. Matar processos de envio (PHP, Node, Classify-Bounces)
    console.log("🔴 Matando processos de envio...");

    result = await shellExec("sudo pkill -9 -f 'send.php'");
    console.log(result.success ? "  ✔ send.php encerrado!" : "  - Nenhum send.php rodando.");

    result = await shellExec("sudo pkill -9 -f 'Classify-Bounces'");
    console.log(result.success ? "  ✔ Classify-Bounces encerrado!" : "  - Nenhum Classify-Bounces rodando.");

    result = await shellExec("sudo pgrep -f 'node' | grep -v " + myPid + " | xargs -r sudo kill -9");
    console.log(result.success ? "  ✔ Processos Node encerrados!" : "  - Nenhum outro processo Node rodando.");

    // 2. Parar o Postfix
    console.log("\n🔴 Parando o Postfix...");
    result = await shellExec('sudo postfix stop');
    console.log(result.success ? "  ✔ Postfix parado!" : "  - Postfix já estava parado.");

    // 3. Limpar todas as filas de e-mails
    console.log("\n🧹 Limpando filas de email...");
    result = await shellExec('sudo postsuper -d ALL deferred');
    console.log(result.success ? "  ✔ Deferred limpo!" : "  - Nenhum em deferred.");
    result = await shellExec('sudo postsuper -d ALL active');
    console.log(result.success ? "  ✔ Active limpo!" : "  - Nenhum em active.");
    result = await shellExec('sudo postsuper -d ALL hold');
    console.log(result.success ? "  ✔ Hold limpo!" : "  - Nenhum em hold.");
    result = await shellExec('sudo postsuper -d ALL');
    console.log(result.success ? "  ✔ Fila geral limpa!" : "  - Fila já vazia.");

    // 4. Limpar o mail.log em /var/log/
    console.log("\n🧹 Limpando /var/log/mail.log...");
    result = await shellExec('sudo truncate -s 0 /var/log/mail.log');
    console.log(result.success ? "  ✔ mail.log limpo!" : "  ✖ Erro: " + result.output);

    // Verificar tamanho
    result = await shellExec('ls -la /var/log/mail.log');
    console.log("  Tamanho atual:", result.output);

    // 5. Limpar arquivos de relatório em /var/www/html/
    console.log("\n🧹 Limpando arquivos em /var/www/html/...");
    const reportFiles = [
        'sent_success.txt',
        'policy_blocks.txt',
        'invalid_retest.txt',
        'invalid_confirmed.txt',
        'domain_invalid.txt',
        'deferred.txt',
        'bounce_report.txt',
        'ambiguous_bounces.txt'
    ];

    for (const file of reportFiles) {
        result = await shellExec('sudo truncate -s 0 /var/www/html/' + file);
        if (result.success) {
            console.log('  ✔ ' + file + ' limpo!');
        } else {
            console.log('  - ' + file + ' não encontrado ou erro.');
        }
    }

    // Verificar tamanhos
    console.log("\n  Verificando tamanhos:");
    result = await shellExec('ls -la /var/www/html/*.txt');
    console.log(result.output);

    // 6. Verificar se ainda tem processos de envio
    console.log("\n🔍 Verificando processos restantes...");
    result = await shellExec("ps aux | grep -E 'send.php|Classify-Bounces' | grep -v grep");
    if (result.success && result.output) {
        console.log("  ⚠️  ATENÇÃO: Ainda existem processos rodando:");
        console.log(result.output);
    } else {
        console.log("  ✔ Nenhum processo de envio ativo.");
    }

    // 7. Iniciar o Postfix
    console.log("\n🟢 Iniciando o Postfix...");
    result = await shellExec('sudo postfix start');
    console.log(result.success ? "  ✔ Postfix iniciado!" : "  ✖ Erro: " + result.output);

    // 8. Verificar fila
    console.log("\n📊 Verificando fila...");
    result = await shellExec('mailq');
    console.log("Fila:", result.output || "Vazia");

    console.log("\n✅ Tudo limpo! Pronto para começar um novo envio.");
}

// Executar
cleanQueueAndRestartServices();