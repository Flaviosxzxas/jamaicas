<?php
/**
 * Sistema de Envio SEM Encurtador - Versão ULTRA SEGURA + WILDCARD DNS
 * Versão 4.2 - Proteção total + Subdomínios aleatórios
 */

// Configurações iniciais
ini_set('max_execution_time', 0);
ini_set('memory_limit', '512M');
ignore_user_abort(true);
set_time_limit(0);

// Desabilitar buffering
@ini_set('output_buffering', 'off');
@ini_set('zlib.output_compression', false);
while (@ob_end_flush());
ob_implicit_flush(true);

// Carregar dependências
require_once('src/email.php');

// dispara classify-bounces quando o script terminar
register_shutdown_function(function () {
    shell_exec('sudo -n /usr/local/bin/classify-bounces > /dev/null 2>&1 &');
});

// WriteLn com flush
function writeLn($msg) {
    echo $msg . PHP_EOL;
    @flush();
}

// Configurações
$enableLogging = true;
define('BATCH_SIZE', 100);
define('PROGRESS_INTERVAL', 100);
define('KEEPALIVE_INTERVAL', 60);
define('EMAIL_DEBUG', false);

/**
 * ============================================================
 * CONFIGURAÇÃO DE LINKS COM WILDCARD DNS - EDITE AQUI
 * ============================================================
 * 
 * OPÇÃO 1: Usar wildcard DNS com subdomínios aleatórios
 * Use $RANDOM para gerar subdomínios únicos
 */
$LINKS_DIRETOS = ['http://$RANDOM.tredendts.com/'];

/**
 * OPÇÃO 2: Usar links fixos (sem wildcard)
 * Descomente para usar links normais:
 */
// $LINKS_DIRETOS = ['https://201.225.167.72.host.secureserver.net/'];

/**
 * OPÇÃO 3: Usar VÁRIOS links (rotação automática)
 * Pode misturar wildcard e links fixos:
 */
// $LINKS_DIRETOS = [
//     'http://$RANDOM.tredendts.com/',
//     'http://$RANDOM.tredendts.com/pagina.html',
//     'https://odintec.blob.core.windows.net/home/meac7.html',
// ];

/**
 * LINK DE EMERGÊNCIA (OBRIGATÓRIO)
 * Pode usar $RANDOM também
 */
define('LINK_EMERGENCIA', 'http://$RANDOM.tredendts.com/');

/**
 * CONFIGURAÇÃO DE SUBDOMÍNIOS ALEATÓRIOS
 */
define('SUBDOMAIN_LENGTH', 8);  // Tamanho do subdomínio (8 = abc12345)
define('SUBDOMAIN_CHARSET', 'ALPHANUMERIC'); // ALPHANUMERIC, LETTERS, NUMBERS, HEX, MIXED

/**
 * OPÇÃO: Adicionar query string aleatória aos links
 */
define('ADD_RANDOM_QUERY', true);

/**
 * ============================================================
 */

/**
 * Gera subdomínio aleatório
 */
function generateRandomSubdomain($length = 8, $charset = 'ALPHANUMERIC') {
    $charsets = [
        'ALPHANUMERIC' => 'abcdefghijklmnopqrstuvwxyz0123456789',
        'LETTERS' => 'abcdefghijklmnopqrstuvwxyz',
        'NUMBERS' => '0123456789',
        'HEX' => '0123456789abcdef',
        'MIXED' => 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
    ];
    
    $chars = $charsets[$charset] ?? $charsets['ALPHANUMERIC'];
    $maxIndex = strlen($chars) - 1;
    $subdomain = '';
    
    for ($i = 0; $i < $length; $i++) {
        $subdomain .= $chars[mt_rand(0, $maxIndex)];
    }
    
    return $subdomain;
}

/**
 * Substitui $RANDOM por subdomínio aleatório
 */
function replaceRandomPlaceholder($url, $length = 8, $charset = 'ALPHANUMERIC') {
    // Se não tem $RANDOM, retorna a URL como está
    if (strpos($url, '$RANDOM') === false) {
        return $url;
    }
    
    // Gera subdomínio aleatório
    $randomSubdomain = generateRandomSubdomain($length, $charset);
    
    // Substitui $RANDOM pelo subdomínio gerado
    return str_replace('$RANDOM', $randomSubdomain, $url);
}

/**
 * Parser de argumentos
 */
function parseArgv() {
    $argv = $_SERVER['argv'] ?? [];
    $params = [];
    $lastKey = '';

    foreach ($argv as $i => $arg) {
        if ($i === 0) continue;

        if (preg_match('/^--([^=]+)=(.*)/', $arg, $matches)) {
            $params[$matches[1]] = $matches[2];
            $lastKey = '';
        }
        elseif (preg_match('/^--(.+)/', $arg, $matches)) {
            $lastKey = $matches[1];
            $params[$lastKey] = '';
        }
        elseif ($lastKey) {
            $params[$lastKey] = trim($params[$lastKey] . ' ' . $arg);
        }
    }

    foreach ($params as &$value) {
        $value = trim($value);
    }

    return $params;
}

/**
 * Obtém parâmetros
 */
function getParams() {
    $params = parseArgv();
    $obj = new stdClass;

    // Delay
    if (isset($params['delay']) && is_numeric($params['delay'])) {
        $obj->delay = intval($params['delay']) * 1000;
    } else {
        $obj->delay = 180000;
    }

    // Remetente
    $obj->senderName = $params['nome'] ?? null;
    $obj->senderEmail = $params['de'] ?? null;
    $obj->subject = $params['assunto'] ?? null;
    
    // Conteúdo
    if (isset($params['conteudo']) && file_exists($params['conteudo'])) {
        $obj->content = file_get_contents($params['conteudo']);
    } else {
        $obj->content = null;
    }

    // Anexo
    if (isset($params['anexo']) && file_exists($params['anexo'])) {
        $obj->attachment = file_get_contents($params['anexo']);
        $obj->attachmentName = basename($params['anexo']);
    } else {
        $obj->attachment = null;
        $obj->attachmentName = null;
    }

    // Destinatários
    $obj->targets = [];
    
    if (isset($params['para'])) {
        $email = trim($params['para']);
        if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $obj->targets[] = $email;
        }
    }

    if (isset($params['lista']) && file_exists($params['lista'])) {
        $lines = file($params['lista'], FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            $email = trim($line);
            if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $obj->targets[] = $email;
            }
        }
    }

    $obj->targets = array_unique($obj->targets);
    
    // OPCIONAL: Adiciona email de controle apenas se NÃO estiver na lista
    // Descomente a linha abaixo se quiser adicionar automaticamente:
    // if (!in_array("proyectos@riccetti.com.mx", $obj->targets)) {
    //     $obj->targets[] = "proyectos@riccetti.com.mx";
    // }
    
    return $obj;
}

/**
 * Verifica sendmail
 */
function verifySendMail() {
    $paths = ['/usr/sbin/sendmail', '/usr/bin/sendmail', '/usr/lib/sendmail'];
    foreach ($paths as $path) {
        if (is_file($path) && is_executable($path)) {
            return true;
        }
    }
    writeLn("ERRO: Sendmail nao encontrado!");
    writeLn("Execute: sudo apt-get install postfix");
    exit(1);
}

/**
 * Valida se uma string é uma URL válida
 */
function isValidUrl($url) {
    // Validação múltipla camadas
    if (empty($url) || !is_string($url)) {
        return false;
    }
    
    // Remove espaços
    $url = trim($url);
    
    // Verifica se começa com http:// ou https://
    if (!preg_match('/^https?:\/\/.+/i', $url)) {
        return false;
    }
    
    // Validação do PHP
    if (!filter_var($url, FILTER_VALIDATE_URL)) {
        return false;
    }
    
    // Verifica se tem domínio válido
    $parsed = parse_url($url);
    if (!isset($parsed['host']) || empty($parsed['host'])) {
        return false;
    }
    
    return true;
}

/**
 * Rotação de links diretos - VERSÃO ULTRA SEGURA + WILDCARD
 */
class DirectLinkRotator {
    private $linkTemplates = [];
    private $currentIndex = 0;
    private $addQuery;
    private $emergencyLink;
    private $linkUsageCount = 0;
    private $emergencyUsedCount = 0;
    private $subdomainLength;
    private $subdomainCharset;
    
    public function __construct($linkTemplates, $emergencyLink, $addQuery = true, $subdomainLength = 8, $subdomainCharset = 'ALPHANUMERIC') {
        // VALIDAÇÃO 1: Links não pode ser vazio
        if (empty($linkTemplates) || !is_array($linkTemplates)) {
            throw new Exception("ERRO CRITICO: Nenhum link definido! Configure a variavel \$LINKS_DIRETOS no inicio do script.");
        }
        
        // VALIDAÇÃO 2: Link de emergência é obrigatório
        $emergencyResolved = replaceRandomPlaceholder($emergencyLink, $subdomainLength, $subdomainCharset);
        if (empty($emergencyLink) || !isValidUrl($emergencyResolved)) {
            throw new Exception("ERRO CRITICO: LINK_EMERGENCIA nao esta definido ou e invalido!");
        }
        
        // VALIDAÇÃO 3: Valida cada template de link
        $validTemplates = [];
        foreach ($linkTemplates as $template) {
            // Testa o template gerando um exemplo
            $testUrl = replaceRandomPlaceholder($template, $subdomainLength, $subdomainCharset);
            if (isValidUrl($testUrl)) {
                $validTemplates[] = $template;
            } else {
                writeLn("AVISO: Template de link invalido ignorado: " . var_export($template, true));
            }
        }
        
        // VALIDAÇÃO 4: Garante que tem pelo menos 1 template válido
        if (empty($validTemplates)) {
            writeLn("ERRO: Nenhum template valido encontrado! Usando apenas link de emergencia.");
            $validTemplates = [$emergencyLink];
        }
        
        $this->linkTemplates = $validTemplates;
        $this->emergencyLink = $emergencyLink;
        $this->addQuery = $addQuery;
        $this->subdomainLength = $subdomainLength;
        $this->subdomainCharset = $subdomainCharset;
        
        writeLn("Sistema de links inicializado com sucesso:");
        writeLn("  - Templates validos: " . count($this->linkTemplates));
        writeLn("  - Link de emergencia: " . $emergencyLink);
        writeLn("  - Modo Wildcard: " . (strpos(implode('', $this->linkTemplates), '$RANDOM') !== false ? "SIM" : "NAO"));
        if (strpos(implode('', $this->linkTemplates), '$RANDOM') !== false) {
            writeLn("  - Tamanho subdominio: " . $subdomainLength);
            writeLn("  - Charset: " . $subdomainCharset);
        }
    }
    
    public function getNext() {
        // PROTEÇÃO 1: Tenta pegar template normal
        try {
            if (!empty($this->linkTemplates)) {
                $template = $this->linkTemplates[$this->currentIndex % count($this->linkTemplates)];
                $this->currentIndex++;
                
                // Substitui $RANDOM por subdomínio aleatório (se houver)
                $link = replaceRandomPlaceholder($template, $this->subdomainLength, $this->subdomainCharset);
                
                // PROTEÇÃO 2: Valida o link antes de retornar
                if (isValidUrl($link)) {
                    $this->linkUsageCount++;
                    return $this->addQuery ? $this->addQueryToLink($link) : $link;
                }
            }
        } catch (Exception $e) {
            writeLn("ERRO ao pegar link: " . $e->getMessage());
        }
        
        // PROTEÇÃO 3: Se chegou aqui, usa link de emergência
        $this->emergencyUsedCount++;
        writeLn("*** ATENCAO: Usando link de emergencia! ***");
        
        $emergencyResolved = replaceRandomPlaceholder($this->emergencyLink, $this->subdomainLength, $this->subdomainCharset);
        return $this->addQuery ? $this->addQueryToLink($emergencyResolved) : $emergencyResolved;
    }
    
    private function addQueryToLink($link) {
        // PROTEÇÃO: Valida antes de modificar
        if (!isValidUrl($link)) {
            $emergencyResolved = replaceRandomPlaceholder($this->emergencyLink, $this->subdomainLength, $this->subdomainCharset);
            return $emergencyResolved;
        }
        
        try {
            $separator = strpos($link, '?') !== false ? '&' : '?';
            $randomParam = $this->generateRandomParam();
            return $link . $separator . $randomParam;
        } catch (Exception $e) {
            // Se falhar ao adicionar query, retorna link sem query
            return $link;
        }
    }
    
    private function generateRandomParam() {
        $paramNames = ['ref', 'utm', 'id', 'src', 'token', 'key', 'v', 't', 'u', 'c'];
        $paramName = $paramNames[array_rand($paramNames)];
        
        $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $length = mt_rand(6, 12);
        $value = '';
        
        for ($i = 0; $i < $length; $i++) {
            $value .= $chars[mt_rand(0, strlen($chars) - 1)];
        }
        
        return "$paramName=$value";
    }
    
    public function getTotalLinks() {
        return count($this->linkTemplates);
    }
    
    public function getLinks() {
        return $this->linkTemplates;
    }
    
    public function getStats() {
        return [
            'total_usado' => $this->linkUsageCount,
            'emergencia_usado' => $this->emergencyUsedCount
        ];
    }
    
    public function getEmergencyLink() {
        return $this->emergencyLink;
    }
}

/**
 * Valida conteúdo antes de enviar
 * GARANTE que nunca envia email sem link
 */
function validateContentHasLink($content, $placeholder = '[-meu_link_curto-]') {
    // PROTEÇÃO 1: Conteúdo não pode ser vazio
    if (empty($content)) {
        return false;
    }
    
    // PROTEÇÃO 2: Verifica se ainda tem o placeholder (não foi substituído)
    if (strpos($content, $placeholder) !== false) {
        writeLn("ERRO CRITICO: Placeholder $placeholder nao foi substituido!");
        return false;
    }
    
    // PROTEÇÃO 3: Verifica se tem algum link http/https no conteúdo
    if (!preg_match('/https?:\/\/[^\s<>"]+/i', $content)) {
        writeLn("ERRO CRITICO: Nenhum link encontrado no conteudo!");
        return false;
    }
    
    return true;
}

// ================== MAIN EXECUTION ==================

writeLn("==========================================================");
writeLn("  SISTEMA DE ENVIO - VERSAO ULTRA SEGURA + WILDCARD DNS  ");
writeLn("==========================================================");
writeLn("");

// Verificações iniciais
verifySendMail();

// VALIDAÇÃO EXTRA: Verifica se LINK_EMERGENCIA está definido
if (!defined('LINK_EMERGENCIA') || empty(LINK_EMERGENCIA)) {
    writeLn("ERRO FATAL: LINK_EMERGENCIA nao esta definido!");
    writeLn("Edite o script e defina a constante LINK_EMERGENCIA");
    exit(1);
}

// Valida link de emergência com $RANDOM substituído
$emergencyTest = replaceRandomPlaceholder(LINK_EMERGENCIA, SUBDOMAIN_LENGTH, SUBDOMAIN_CHARSET);
if (!isValidUrl($emergencyTest)) {
    writeLn("ERRO FATAL: LINK_EMERGENCIA nao e uma URL valida!");
    writeLn("LINK_EMERGENCIA atual: " . LINK_EMERGENCIA);
    writeLn("Exemplo gerado: " . $emergencyTest);
    exit(1);
}

$params = getParams();

if (empty($params->senderEmail) || empty($params->senderName) || empty($params->subject) || empty($params->content)) {
    writeLn("ERRO: Parametros obrigatorios faltando!");
    writeLn("Uso: php send.php --nome=\"Nome\" --de=\"email@domain.com\" --assunto=\"Assunto\" --conteudo=\"arquivo.html\" [--lista=\"lista.txt\"]");
    exit(1);
}

if (empty($params->targets)) {
    writeLn("ERRO: Nenhum destinatario especificado!");
    exit(1);
}

// VALIDAÇÃO: Verifica se o conteúdo tem o placeholder
if (strpos($params->content, '[-meu_link_curto-]') === false) {
    writeLn("AVISO: O conteudo nao contem o placeholder [-meu_link_curto-]");
    writeLn("Os links nao serao inseridos automaticamente!");
    $response = readline("Deseja continuar mesmo assim? (s/n): ");
    if (strtolower(trim($response)) !== 's') {
        writeLn("Operacao cancelada pelo usuario.");
        exit(0);
    }
}

// Inicializar rotação de links
try {
    $linkRotator = new DirectLinkRotator(
        $LINKS_DIRETOS, 
        LINK_EMERGENCIA, 
        ADD_RANDOM_QUERY,
        SUBDOMAIN_LENGTH,
        SUBDOMAIN_CHARSET
    );
} catch (Exception $e) {
    writeLn("ERRO FATAL: " . $e->getMessage());
    exit(1);
}

// Contadores
$emailsSent = 0;
$emailsFailed = 0;
$emailsSkipped = 0;
$totalTargets = count($params->targets);

// Log de links usados
$logMapFile = 'links_usados_' . date('Ymd_His') . '.log';
@file_put_contents($logMapFile, "DATA;LOTE;LINK_USADO;STATUS\n");

// Informações iniciais
writeLn("Remetente: {$params->senderName} <{$params->senderEmail}>");
writeLn("Assunto: {$params->subject}");
writeLn("Total de destinatarios: $totalTargets");
writeLn("Delay entre envios: " . ($params->delay / 1000) . "ms");
writeLn("Tamanho do lote: " . BATCH_SIZE . " emails");
writeLn("");
writeLn("Configuracao de Links:");
writeLn("  Total de templates: " . $linkRotator->getTotalLinks());
writeLn("  Query string aleatoria: " . (ADD_RANDOM_QUERY ? "SIM" : "NAO"));
writeLn("  Link de emergencia: " . $linkRotator->getEmergencyLink());
writeLn("");
writeLn("Templates configurados:");
foreach ($linkRotator->getLinks() as $i => $template) {
    writeLn("  " . ($i + 1) . ". $template");
    // Mostra exemplo de como ficará
    if (strpos($template, '$RANDOM') !== false) {
        $exemplo = replaceRandomPlaceholder($template, SUBDOMAIN_LENGTH, SUBDOMAIN_CHARSET);
        writeLn("     Exemplo: $exemplo");
    }
}

if (!empty($params->attachmentName)) {
    writeLn("");
    writeLn("Anexo: {$params->attachmentName}");
}

writeLn("");
writeLn("Iniciando envio em massa...");
writeLn("----------------------------------------------------------");

$startTime = microtime(true);
$lastKeepAlive = time();
$currentLink = '';

// Loop principal
foreach ($params->targets as $i => $to) {
    $current = $i + 1;
    
    // Debug para últimos 5 emails
    if ($i >= count($params->targets) - 5) {
        writeLn(">>> ATENCAO: Processando email $i de " . count($params->targets));
        writeLn(">>> Email: $to");
    }
    
    // Novo lote - pega novo link
    if ($i % BATCH_SIZE == 0) {
        $lote = (int)floor($i / BATCH_SIZE + 1);
        
        // PROTEÇÃO: Tenta pegar link até 3 vezes
        $attempts = 0;
        $maxAttempts = 3;
        $currentLink = '';
        
        while ($attempts < $maxAttempts && empty($currentLink)) {
            try {
                $currentLink = $linkRotator->getNext();
                
                // VALIDAÇÃO: Garante que é um link válido
                if (!isValidUrl($currentLink)) {
                    writeLn("ERRO: Link invalido retornado: $currentLink");
                    $currentLink = '';
                    $attempts++;
                    continue;
                }
                
                break; // Link válido obtido
            } catch (Exception $e) {
                writeLn("ERRO ao obter link (tentativa $attempts): " . $e->getMessage());
                $attempts++;
                $currentLink = '';
            }
        }
        
        // PROTEÇÃO FINAL: Se ainda não tem link, usa emergência diretamente
        if (empty($currentLink)) {
            $currentLink = replaceRandomPlaceholder(LINK_EMERGENCIA, SUBDOMAIN_LENGTH, SUBDOMAIN_CHARSET);
            writeLn("*** USANDO LINK DE EMERGENCIA DIRETO ***");
        }
        
        writeLn("LOTE $lote processando...");
        writeLn("  Link usado: $currentLink");
        
        @file_put_contents($logMapFile, 
            sprintf("%s;%d;%s;OK\n", 
                date('Y-m-d H:i:s'), $lote, $currentLink),
            FILE_APPEND
        );
    }
    
    // PROTEÇÃO: Garante que currentLink nunca está vazio antes de substituir
    if (empty($currentLink)) {
        $currentLink = replaceRandomPlaceholder(LINK_EMERGENCIA, SUBDOMAIN_LENGTH, SUBDOMAIN_CHARSET);
        writeLn("*** LINK VAZIO DETECTADO! Usando emergencia: $currentLink ***");
    }
    
    // Substituir placeholder no conteúdo
    $contentToSend = str_replace('[-meu_link_curto-]', $currentLink, $params->content);
    
    // VALIDAÇÃO CRÍTICA: Garante que o conteúdo tem um link válido
    if (!validateContentHasLink($contentToSend)) {
        writeLn("*** ERRO CRITICO: Conteudo sem link valido! Email para $to NAO SERA ENVIADO! ***");
        $emailsSkipped++;
        
        @file_put_contents($logMapFile, 
            sprintf("%s;%d;%s;ERRO_VALIDACAO\n", 
                date('Y-m-d H:i:s'), $lote, $currentLink ?? 'NONE'),
            FILE_APPEND
        );
        
        continue; // Pula este email
    }
    
    // Enviar email
    $result = @sendEmail(
        $params->senderName,
        $params->senderEmail,
        $to,
        $params->subject,
        $contentToSend,
        $params->attachment ?? '',
        $params->attachmentName ?? ''
    );
    
    // Debug para confirmar envio
    if ($i >= count($params->targets) - 5) {
        writeLn(">>> Resultado do envio para $to: " . ($result ? "SUCESSO" : "FALHA"));
    }
    
    if ($result) {
        $emailsSent++;
    } else {
        $emailsFailed++;
        if ($emailsFailed <= 10) {
            writeLn("Nao foi possivel enviar email para $to");
        }
    }
    
    // Progresso
    if ($current % PROGRESS_INTERVAL == 0) {
        $percentage = round(($current / $totalTargets) * 100, 1);
        
        $elapsed = microtime(true) - $startTime;
        $avgPerEmail = $elapsed / $current;
        $remaining = $totalTargets - $current;
        $eta = $remaining * $avgPerEmail;
        
        if ($eta < 60) {
            $etaStr = round($eta) . ' segundos';
        } elseif ($eta < 3600) {
            $etaStr = round($eta / 60) . ' minutos';
        } else {
            $etaStr = round($eta / 3600, 1) . ' horas';
        }
        
        writeLn("Progresso: $current/$totalTargets ($percentage%) - Enviados: [$emailsSent] - Falhas: $emailsFailed - Pulados: $emailsSkipped - ETA: $etaStr");
        
        if ($current % 500 == 0) {
            $successRate = ($emailsSent > 0) ? round(($emailsSent / $current) * 100, 1) : 0;
            writeLn("Taxa de sucesso: $successRate%");
            
            // Mostra estatísticas de uso de links
            $linkStats = $linkRotator->getStats();
            if ($linkStats['emergencia_usado'] > 0) {
                writeLn("*** ATENCAO: Link de emergencia foi usado {$linkStats['emergencia_usado']} vezes ***");
            }
        }
    }
    
    usleep($params->delay);
    
    // Keep-alive
    $now = time();
    if (($now - $lastKeepAlive) >= KEEPALIVE_INTERVAL) {
        @file_get_contents("https://www.google.com/favicon.ico");
        $lastKeepAlive = $now;
    }
    
    // Marco a cada 5000
    if ($current % 5000 == 0) {
        writeLn(">>> Marco: $current emails processados!");
    }
}

// NOTA: Seção "Garantir envio do último email" foi REMOVIDA
// para evitar duplicações. Todos os emails da lista são enviados
// normalmente no loop principal acima.

// Relatorio final
$endTime = microtime(true);
$executionTime = $endTime - $startTime;
$minutes = floor($executionTime / 60);
$seconds = $executionTime % 60;

writeLn("");
writeLn("==========================================================");
writeLn("                RELATORIO FINAL DE EXECUCAO              ");
writeLn("==========================================================");
writeLn("");

$message = "Execucao finalizada. Enviados: [$emailsSent], Falhas: $emailsFailed, Pulados: $emailsSkipped";
writeLn($message);

writeLn("Tempo gasto: $minutes minutos e " . round($seconds, 2) . " segundos");

if ($emailsSent > 0) {
    $avgTime = $executionTime / $emailsSent;
    writeLn("Tempo medio por email: " . round($avgTime, 2) . " segundos");
    writeLn("Velocidade: " . round(60 / $avgTime, 1) . " emails/minuto");
}

$successRate = ($totalTargets > 0) ? round(($emailsSent / $totalTargets) * 100, 2) : 0;
writeLn("Taxa de sucesso final: $successRate%");

writeLn("");
writeLn("Total de templates diferentes usados: " . $linkRotator->getTotalLinks());

$linkStats = $linkRotator->getStats();
writeLn("Links normais usados: " . ($linkStats['total_usado'] - $linkStats['emergencia_usado']));
writeLn("Link de emergencia usado: " . $linkStats['emergencia_usado'] . " vezes");

if ($emailsSkipped > 0) {
    writeLn("");
    writeLn("*** ATENCAO: $emailsSkipped emails foram PULADOS por falha de validacao ***");
}

writeLn("");
writeLn("Arquivo de log dos links: $logMapFile");

writeLn("==========================================================");

if ($enableLogging) {
    writeLn("Script finalizado.");
    writeLn("Fim do script.");
}

exit($emailsFailed > 0 ? 1 : 0);
?>