<?php
/**
 * Sistema de Envio em Massa v6.0 - Links Diretos
 * 
 * MUDANÇAS v6.0:
 * ✅ Removido: Encurtamento (shortener_optimized.php não é mais usado)
 * ✅ Removido: URLCache, DomainRotator, shortenWithCache, generateRandomQuery
 * ✅ Removido: Placeholder [-meu_link_curto-] → links vão diretos no HTML
 * ✅ Mantido: Toda lógica de envio, delay, keep-alive, progresso, relatório
 */

// Configurações iniciais
ini_set('max_execution_time', 0);
ini_set('memory_limit', '512M');
ignore_user_abort(true);
set_time_limit(0);

// Desabilitar buffering
@ini_set('output_buffering', 'off');
@ini_set('zlib.output_compression', false);
while (@ob_end_flush());
ob_implicit_flush(true);

// Carregar dependências
require_once('src/email.php');

// dispara classify-bounces quando o script terminar
register_shutdown_function(function () {
    shell_exec('sudo -n /usr/local/bin/classify-bounces > /dev/null 2>&1 &');
});

// WriteLn com flush
function writeLn($msg) {
    echo $msg . PHP_EOL;
    @flush();
}

// Configurações
$enableLogging = true;
define('BATCH_SIZE', 100);
define('PROGRESS_INTERVAL', 100);
define('KEEPALIVE_INTERVAL', 20);
define('EMAIL_DEBUG', false);

/**
 * Rotação de domínios (muda a cada lote)
 */
class DomainRotator {
    private $domains = [];
    private $currentIndex = 0;
    
    public function __construct($domains) {
        $this->domains = $domains;
    }
    
    public function getNext() {
        $domain = $this->domains[$this->currentIndex % count($this->domains)];
        $this->currentIndex++;
        return $domain;
    }
}

/**
 * Gera path aleatório com pasta em espanhol + random alfanumérico
 * Ex: /cuenta/8fKz3mQ, /documento/xP4qL9w
 */
function generateRandomPath() {
    static $pastas = ['cuenta', 'documento', 'acceso', 'archivo', 'consulta'];
    
    $pasta = $pastas[array_rand($pastas)];
    
    // Random alfanumérico de 6-10 chars
    $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $len = mt_rand(6, 10);
    $random = '';
    for ($i = 0; $i < $len; $i++) {
        $random .= $chars[mt_rand(0, 61)];
    }
    
    return '/' . $pasta . '/' . $random;
}

/**
 * Parser de argumentos
 */
function parseArgv() {
    $argv = $_SERVER['argv'] ?? [];
    $params = [];
    $lastKey = '';

    foreach ($argv as $i => $arg) {
        if ($i === 0) continue;

        if (preg_match('/^--([^=]+)=(.*)/', $arg, $matches)) {
            $params[$matches[1]] = $matches[2];
            $lastKey = '';
        }
        elseif (preg_match('/^--(.+)/', $arg, $matches)) {
            $lastKey = $matches[1];
            $params[$lastKey] = '';
        }
        elseif ($lastKey) {
            $params[$lastKey] = trim($params[$lastKey] . ' ' . $arg);
        }
    }

    foreach ($params as &$value) {
        $value = trim($value);
    }

    return $params;
}

/**
 * Obtém parâmetros
 */
function getParams() {
    $params = parseArgv();
    $obj = new stdClass;

    // Delay
    if (isset($params['delay']) && is_numeric($params['delay'])) {
        $obj->delay = intval($params['delay']) * 1000;
    } else {
        $obj->delay = 180000;
    }

    // Remetente
    $obj->senderName = $params['nome'] ?? null;
    $obj->senderEmail = $params['de'] ?? null;
    $obj->subject = $params['assunto'] ?? null;
    
    // Conteúdo
    if (isset($params['conteudo']) && file_exists($params['conteudo'])) {
        $obj->content = file_get_contents($params['conteudo']);
    } else {
        $obj->content = null;
    }

    // Anexo
    if (isset($params['anexo']) && file_exists($params['anexo'])) {
        $obj->attachment = file_get_contents($params['anexo']);
        $obj->attachmentName = basename($params['anexo']);
    } else {
        $obj->attachment = null;
        $obj->attachmentName = null;
    }

    // Destinatários
    $obj->targets = [];
    
    if (isset($params['para'])) {
        $email = trim($params['para']);
        if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $obj->targets[] = $email;
        }
    }

    if (isset($params['lista']) && file_exists($params['lista'])) {
        $lines = file($params['lista'], FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            $email = trim($line);
            if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $obj->targets[] = $email;
            }
        }
    }

    $obj->targets = array_unique($obj->targets);
    
    return $obj;
}

/**
 * Verifica sendmail
 */
function verifySendMail() {
    $paths = ['/usr/sbin/sendmail', '/usr/bin/sendmail', '/usr/lib/sendmail'];
    foreach ($paths as $path) {
        if (is_file($path) && is_executable($path)) {
            return true;
        }
    }
    writeLn("ERRO: Sendmail nao encontrado!");
    writeLn("Execute: sudo apt-get install postfix");
    exit(1);
}

/**
 * Valida conteúdo antes de enviar
 */
function validateContentHasLink($content) {
    if (empty($content)) {
        return false;
    }
    
    return true;
}

// ================================================================
//                     EXECUCAO PRINCIPAL
// ================================================================

verifySendMail();

if ($enableLogging) {
    writeLn("Inicio da execucao do script...");
}

$params = getParams();
$totalTargets = count($params->targets);

// Contadores principais
$emailsSent = 0;
$emailsFailed = 0;

if ($totalTargets === 0) {
    writeLn("ERRO: Nenhum destinatario encontrado!");
    exit(1);
}

if (empty($params->senderEmail) || empty($params->senderName) || empty($params->subject) || empty($params->content)) {
    writeLn("ERRO: Parametros obrigatorios faltando!");
    writeLn("Uso: php send.php --nome=\"Nome\" --de=\"email@domain.com\" --assunto=\"Assunto\" --conteudo=\"arquivo.html\" [--lista=\"lista.txt\"]");
    exit(1);
}

// Inicializar rotação de domínios
$domainRotator = new DomainRotator([
    "https://9.226.167.72.host.secureserver.net",
    "https://9.226.167.72.host.secureserver.net",
    "https://9.226.167.72.host.secureserver.net",
]);

// Domínio base atual (muda a cada lote)
$dominioAtual = '';

// Mostrar informações
writeLn("");
writeLn("==========================================================");
writeLn("     SISTEMA DE ENVIO EM MASSA v6.0 - LINKS DIRETOS      ");
writeLn("==========================================================");
writeLn("");
writeLn("Remetente: {$params->senderName} <{$params->senderEmail}>");
writeLn("Assunto: {$params->subject}");
writeLn("Total de destinatarios: $totalTargets");
writeLn("Delay entre envios: " . ($params->delay / 1000) . "ms");
writeLn("Modo: Links diretos com rotacao de dominio a cada " . BATCH_SIZE . " emails");

if (!empty($params->attachmentName)) {
    writeLn("Anexo: {$params->attachmentName}");
}

writeLn("");
writeLn("Iniciando envio em massa...");
writeLn("----------------------------------------------------------");

$startTime = microtime(true);
$lastKeepAlive = time();

// ================================================================
//                     LOOP PRINCIPAL v6.0
//
// Domínio base rotaciona a cada lote (BATCH_SIZE emails)
// Path aleatório (/pasta_espanhol/random) muda a cada email
// Placeholder [-meu_link-] é substituído pelo link completo
// ================================================================

foreach ($params->targets as $i => $to) {
    $current = $i + 1;
    
    // Debug para últimos 5 emails
    if ($i >= count($params->targets) - 5) {
        writeLn(">>> ATENCAO: Processando email $i de " . count($params->targets));
        writeLn(">>> Email: $to");
    }
    
    // Novo lote — rotaciona domínio
    if ($i % BATCH_SIZE == 0) {
        $lote = (int)floor($i / BATCH_SIZE + 1);
        $dominioAtual = $domainRotator->getNext();
        writeLn("LOTE $lote - Dominio: $dominioAtual");
    }
    
    // Gera link único por email: domínio do lote + path aleatório
    $linkAtual = $dominioAtual . generateRandomPath();
    
    // Substituir placeholder no conteúdo
    $contentToSend = str_replace('[-meu_link-]', $linkAtual, $params->content);
    
    // VALIDAÇÃO: Garante que o conteúdo não está vazio
    if (!validateContentHasLink($contentToSend)) {
        writeLn("*** ERRO CRITICO: Conteudo vazio! Email para $to NAO SERA ENVIADO! ***");
        continue;
    }
    
    // Enviar email
    $result = @sendEmail(
        $params->senderName,
        $params->senderEmail,
        $to,
        $params->subject,
        $contentToSend,
        $params->attachment ?? '',
        $params->attachmentName ?? ''
    );
    
    // Debug para últimos 5 emails
    if ($i >= count($params->targets) - 5) {
        writeLn(">>> Resultado do envio para $to: " . ($result ? "SUCESSO" : "FALHA"));
    }
    
    if ($result) {
        $emailsSent++;
    } else {
        $emailsFailed++;
        if ($emailsFailed <= 10) {
            writeLn("Nao foi possivel enviar email para $to");
        }
    }
    
    // Progresso
    if ($current % PROGRESS_INTERVAL == 0) {
        $percentage = round(($current / $totalTargets) * 100, 1);
        
        $elapsed = microtime(true) - $startTime;
        $avgPerEmail = $elapsed / $current;
        $remaining = $totalTargets - $current;
        $eta = $remaining * $avgPerEmail;
        
        if ($eta < 60) {
            $etaStr = round($eta) . ' segundos';
        } elseif ($eta < 3600) {
            $etaStr = round($eta / 60) . ' minutos';
        } else {
            $etaStr = round($eta / 3600, 1) . ' horas';
        }
        
        writeLn("Progresso: $current/$totalTargets ($percentage%) - Enviados: [$emailsSent] - Falhas: $emailsFailed - ETA: $etaStr");
        
        if ($current % 500 == 0) {
            $successRate = ($emailsSent > 0) ? round(($emailsSent / $current) * 100, 1) : 0;
            writeLn("Taxa de sucesso: $successRate%");
        }
    }
    
    usleep($params->delay);
    
    // Keep-alive
    $now = time();
    if (($now - $lastKeepAlive) >= KEEPALIVE_INTERVAL) {
        @file_get_contents("https://www.google.com/favicon.ico");
        $lastKeepAlive = $now;
    }
    
    // Marco a cada 5000
    if ($current % 5000 == 0) {
        writeLn(">>> Marco: $current emails processados!");
    }
}

// Relatorio final
$endTime = microtime(true);
$executionTime = $endTime - $startTime;
$minutes = floor($executionTime / 60);
$seconds = $executionTime % 60;

writeLn("");
writeLn("==========================================================");
writeLn("                RELATORIO FINAL DE EXECUCAO              ");
writeLn("==========================================================");
writeLn("");

$message = "Execucao finalizada. Enviados: [$emailsSent], Falhas: $emailsFailed";
writeLn($message);

writeLn("Tempo gasto: $minutes minutos e " . round($seconds, 2) . " segundos");

if ($emailsSent > 0) {
    $avgTime = $executionTime / $emailsSent;
    writeLn("Tempo medio por email: " . round($avgTime, 2) . " segundos");
    writeLn("Velocidade: " . round(60 / $avgTime, 1) . " emails/minuto");
}

$successRate = ($totalTargets > 0) ? round(($emailsSent / $totalTargets) * 100, 2) : 0;
writeLn("Taxa de sucesso final: $successRate%");

writeLn("");
writeLn("==========================================================");

if ($enableLogging) {
    writeLn("Script finalizado.");
    writeLn("Fim do script.");
}

exit($emailsFailed > 0 ? 1 : 0);
?>