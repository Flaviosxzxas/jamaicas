<?php
/**
 * Sistema Otimizado de Envio com Encurtamento
 * Versão 5.1 - Sem conflitos, usa shortener_optimized.php como fonte única
 * 
 * ENCURTAMENTO: shortener_optimized.php (is.gd → v.gd → da.gd → tinyurl)
 * ESTE ARQUIVO: Controle de envio, cache, lotes, fallback
 * 
 * CORREÇÕES:
 * ✅ Removido: MultiShortener duplicado (usa shortener_optimized.php)
 * ✅ Removido: Duplicação do último email
 * ✅ Removido: Email hardcoded
 * ✅ Removido: generateRandomString() duplicada
 * ✅ Adicionado: validateContentHasLink()
 * ✅ Adicionado: Fallback persistente (nunca desabilita encurtador)
 */

// Configurações iniciais
ini_set('max_execution_time', 0);
ini_set('memory_limit', '512M');
ignore_user_abort(true);
set_time_limit(0);

// Desabilitar buffering
@ini_set('output_buffering', 'off');
@ini_set('zlib.output_compression', false);
while (@ob_end_flush());
ob_implicit_flush(true);

// Carregar dependências
require_once('src/email.php');
require_once('src/shortener_optimized.php');

// dispara classify-bounces quando o script terminar
register_shutdown_function(function () {
    shell_exec('sudo -n /usr/local/bin/classify-bounces > /dev/null 2>&1 &');
});

// WriteLn com flush
function writeLn($msg) {
    echo $msg . PHP_EOL;
    @flush();
}

// Configurações
$enableLogging = true;
define('BATCH_SIZE', 100);
define('PROGRESS_INTERVAL', 100);
define('KEEPALIVE_INTERVAL', 20);
define('CACHE_SIZE', 500);
define('EMAIL_DEBUG', false);

/**
 * Parser de argumentos
 */
function parseArgv() {
    $argv = $_SERVER['argv'] ?? [];
    $params = [];
    $lastKey = '';

    foreach ($argv as $i => $arg) {
        if ($i === 0) continue;

        if (preg_match('/^--([^=]+)=(.*)/', $arg, $matches)) {
            $params[$matches[1]] = $matches[2];
            $lastKey = '';
        }
        elseif (preg_match('/^--(.+)/', $arg, $matches)) {
            $lastKey = $matches[1];
            $params[$lastKey] = '';
        }
        elseif ($lastKey) {
            $params[$lastKey] = trim($params[$lastKey] . ' ' . $arg);
        }
    }

    foreach ($params as &$value) {
        $value = trim($value);
    }

    return $params;
}

/**
 * Obtém parâmetros
 */
function getParams() {
    $params = parseArgv();
    $obj = new stdClass;

    // Delay
    if (isset($params['delay']) && is_numeric($params['delay'])) {
        $obj->delay = intval($params['delay']) * 1000;
    } else {
        $obj->delay = 180000;
    }

    // Remetente
    $obj->senderName = $params['nome'] ?? null;
    $obj->senderEmail = $params['de'] ?? null;
    $obj->subject = $params['assunto'] ?? null;
    
    // Conteúdo
    if (isset($params['conteudo']) && file_exists($params['conteudo'])) {
        $obj->content = file_get_contents($params['conteudo']);
    } else {
        $obj->content = null;
    }

    // Anexo
    if (isset($params['anexo']) && file_exists($params['anexo'])) {
        $obj->attachment = file_get_contents($params['anexo']);
        $obj->attachmentName = basename($params['anexo']);
    } else {
        $obj->attachment = null;
        $obj->attachmentName = null;
    }

    // Destinatários
    $obj->targets = [];
    
    if (isset($params['para'])) {
        $email = trim($params['para']);
        if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $obj->targets[] = $email;
        }
    }

    if (isset($params['lista']) && file_exists($params['lista'])) {
        $lines = file($params['lista'], FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            $email = trim($line);
            if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $obj->targets[] = $email;
            }
        }
    }

    $obj->targets = array_unique($obj->targets);
    
    return $obj;
}

/**
 * Verifica sendmail
 */
function verifySendMail() {
    $paths = ['/usr/sbin/sendmail', '/usr/bin/sendmail', '/usr/lib/sendmail'];
    foreach ($paths as $path) {
        if (is_file($path) && is_executable($path)) {
            return true;
        }
    }
    writeLn("ERRO: Sendmail nao encontrado!");
    writeLn("Execute: sudo apt-get install postfix");
    exit(1);
}

/**
 * Valida conteúdo antes de enviar
 */
function validateContentHasLink($content, $placeholder = '[-meu_link_curto-]') {
    if (empty($content)) {
        return false;
    }
    
    if (strpos($content, $placeholder) !== false) {
        writeLn("ERRO CRITICO: Placeholder $placeholder nao foi substituido!");
        return false;
    }
    
    if (!preg_match('/https?:\/\/[^\s<>"]+/i', $content)) {
        writeLn("ERRO CRITICO: Nenhum link encontrado no conteudo!");
        return false;
    }
    
    return true;
}

/**
 * Cache de URLs encurtadas (responsabilidade do send.php, não do shortener)
 */
class URLCache {
    private $cache = [];
    private $hits = 0;
    private $misses = 0;
    private $maxSize;
    
    public function __construct($maxSize = 10000) {
        $this->maxSize = $maxSize;
    }
    
    public function get($longUrl) {
        $hash = md5($longUrl);
        if (isset($this->cache[$hash])) {
            $this->hits++;
            return $this->cache[$hash]['short'];
        }
        $this->misses++;
        return null;
    }
    
    public function set($longUrl, $shortUrl) {
        $hash = md5($longUrl);
        if (count($this->cache) >= $this->maxSize) {
            array_shift($this->cache);
        }
        $this->cache[$hash] = ['short' => $shortUrl, 'time' => time()];
    }
    
    public function getStats() {
        $total = $this->hits + $this->misses;
        $hitRate = $total > 0 ? round(($this->hits / $total) * 100, 1) : 0;
        return [
            'hits' => $this->hits,
            'misses' => $this->misses,
            'hitRate' => $hitRate
        ];
    }
}

/**
 * Rotação de domínios
 */
class DomainRotator {
    private $domains = [];
    private $currentIndex = 0;
    
    public function __construct($domains) {
        $this->domains = $domains;
    }
    
    public function getNext() {
        $domain = $this->domains[$this->currentIndex % count($this->domains)];
        $this->currentIndex++;
        return $domain;
    }
}

/**
 * Gera query aleatória
 */
function generateRandomQuery($length = 5) {
    $realLength = mt_rand(5, 10);
    
    $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $str = '';
    for ($i = 0; $i < $realLength; $i++) {
        $str .= $chars[mt_rand(0, strlen($chars) - 1)];
    }
    
    $params = ['r', 'id', 'ref', 'utm', 'c', 'source', 'track'];
    $param = $params[array_rand($params)];
    
    return '?' . $param . '=' . $str;
}

/**
 * Encurta URL usando shortener_optimized.php com cache local
 * 
 * Fluxo: cache local → shortener_optimized.php (is.gd → v.gd → da.gd → tinyurl)
 */
function shortenWithCache($longUrl, $cache) {
    // 1. Verifica cache primeiro
    $cached = $cache->get($longUrl);
    if ($cached) {
        return ['ok' => true, 'short' => $cached, 'service' => 'cache'];
    }
    
    // 2. Chama shortener_optimized.php (tenta todos os serviços)
    $result = shortenUrlChecked($longUrl);
    
    // 3. Se sucesso, salva no cache
    if ($result['ok']) {
        $cache->set($longUrl, $result['short']);
    }
    
    return $result;
}

// ================================================================
//                     EXECUCAO PRINCIPAL
// ================================================================

verifySendMail();

if ($enableLogging) {
    writeLn("Inicio da execucao do script...");
}

$params = getParams();
$totalTargets = count($params->targets);

// Contadores principais
$emailsSent = 0;
$emailsFailed = 0;
$emailsSkipped = 0;
$fallbackUsedCount = 0;

if ($totalTargets === 0) {
    writeLn("ERRO: Nenhum destinatario encontrado!");
    exit(1);
}

if (empty($params->senderEmail) || empty($params->senderName) || empty($params->subject) || empty($params->content)) {
    writeLn("ERRO: Parametros obrigatorios faltando!");
    writeLn("Uso: php send.php --nome=\"Nome\" --de=\"email@domain.com\" --assunto=\"Assunto\" --conteudo=\"arquivo.html\" [--lista=\"lista.txt\"]");
    exit(1);
}

// Inicializar sistemas
$urlCache = new URLCache(CACHE_SIZE);
$domainRotator = new DomainRotator([
    "https://9.226.167.72.host.secureserver.net",
    "https://9.226.167.72.host.secureserver.net",
    "https://9.226.167.72.host.secureserver.net",
]);

// Variáveis de controle
$shortLinkAtual = '';
$lastWorkingLink = '';

// Log file
$logMapFile = __DIR__ . "/short_maps_" . date('Y-m-d') . ".csv";
if (!file_exists($logMapFile)) {
    @file_put_contents($logMapFile, "timestamp;lote;long;short;status\n");
}

// Mostrar informações
writeLn("");
writeLn("==========================================================");
writeLn("     SISTEMA DE ENVIO EM MASSA v5.1                      ");
writeLn("==========================================================");
writeLn("");
writeLn("Remetente: {$params->senderName} <{$params->senderEmail}>");
writeLn("Assunto: {$params->subject}");
writeLn("Total de destinatarios: $totalTargets");
writeLn("Delay entre envios: " . ($params->delay / 1000) . "ms");
writeLn("Tamanho do lote: " . BATCH_SIZE . " emails");
writeLn("Cache maximo: " . CACHE_SIZE . " URLs");
writeLn("Encurtadores: is.gd -> v.gd -> da.gd -> tinyurl (via shortener_optimized.php)");

if (!empty($params->attachmentName)) {
    writeLn("Anexo: {$params->attachmentName}");
}

writeLn("");
writeLn("Iniciando envio em massa...");
writeLn("----------------------------------------------------------");

$startTime = microtime(true);
$lastKeepAlive = time();

// ================================================================
//                     LOOP PRINCIPAL v5.1
//
// 1. Início do lote → cache → is.gd → v.gd → da.gd → tinyurl
// 2. Sucesso → usa novo link, salva em $lastWorkingLink
// 3. Falha → usa $lastWorkingLink (último encurtado)
// 4. Próximo lote → TENTA DE NOVO (nunca para de tentar)
// 5. Link longo → SOMENTE se nunca teve encurtado
// ================================================================

foreach ($params->targets as $i => $to) {
    $current = $i + 1;
    
    // Debug para últimos 5 emails
    if ($i >= count($params->targets) - 5) {
        writeLn(">>> ATENCAO: Processando email $i de " . count($params->targets));
        writeLn(">>> Email: $to");
    }
    
    // Novo lote — SEMPRE tenta encurtar
    if ($i % BATCH_SIZE == 0) {
        $lote = (int)floor($i / BATCH_SIZE + 1);
        
        // Gera URL base nova
        $domain = $domainRotator->getNext();
        $query = generateRandomQuery(mt_rand(5, 8));
        $fullUrl = $domain . $query;
        
        writeLn("LOTE $lote - Tentando encurtar...");
        writeLn("  URL original: $fullUrl");
        
        // Encurta via shortener_optimized.php (com cache)
        $result = shortenWithCache($fullUrl, $urlCache);
        
        if ($result['ok']) {
            // ═══ SUCESSO ═══
            $shortLinkAtual = $result['short'];
            $lastWorkingLink = $shortLinkAtual;
            $service = $result['service'] ?? 'unknown';
            $cacheHit = $service == 'cache' ? 'SIM' : 'NAO';
            
            writeLn("  OK! Encurtado com sucesso!");
            writeLn("  Link encurtado: $shortLinkAtual");
            writeLn("  Servico: $service (Cache: $cacheHit)");
            
            @file_put_contents($logMapFile, 
                sprintf("%s;%d;%s;%s;OK_%s\n", 
                    date('Y-m-d H:i:s'), $lote, $fullUrl, $shortLinkAtual, $service),
                FILE_APPEND
            );
            
        } else {
            // ═══ TODOS FALHARAM ═══
            $fallbackUsedCount++;
            
            if (!empty($lastWorkingLink)) {
                $shortLinkAtual = $lastWorkingLink;
                writeLn("  FALHA! Todos os servicos falharam!");
                writeLn("  -> Usando ultimo link encurtado: $shortLinkAtual");
                writeLn("  -> Proximo lote tentara encurtar novamente");
                
                @file_put_contents($logMapFile, 
                    sprintf("%s;%d;%s;%s;FALLBACK_ULTIMO\n", 
                        date('Y-m-d H:i:s'), $lote, $fullUrl, $shortLinkAtual),
                    FILE_APPEND
                );
                
            } else {
                $shortLinkAtual = $fullUrl;
                writeLn("  FALHA! Todos os servicos falharam!");
                writeLn("  SEM link encurtado anterior disponivel!");
                writeLn("  -> Usando link direto (emergencia): $shortLinkAtual");
                
                @file_put_contents($logMapFile, 
                    sprintf("%s;%d;%s;%s;EMERGENCIA_DIRETO\n", 
                        date('Y-m-d H:i:s'), $lote, $fullUrl, $shortLinkAtual),
                    FILE_APPEND
                );
            }
        }
    }
    
    // PROTEÇÃO FINAL: link nunca vazio
    if (empty($shortLinkAtual)) {
        $domain = $domainRotator->getNext();
        $query = generateRandomQuery(5);
        $shortLinkAtual = $domain . $query;
        writeLn("*** LINK VAZIO DETECTADO! Usando emergencia: $shortLinkAtual ***");
    }
    
    // Substituir placeholder no conteúdo
    $contentToSend = str_replace('[-meu_link_curto-]', $shortLinkAtual, $params->content);
    
    // VALIDAÇÃO: Garante que o conteúdo tem um link válido
    if (!validateContentHasLink($contentToSend)) {
        writeLn("*** ERRO CRITICO: Conteudo sem link valido! Email para $to NAO SERA ENVIADO! ***");
        $emailsSkipped++;
        
        @file_put_contents($logMapFile, 
            sprintf("%s;%d;%s;%s;ERRO_VALIDACAO\n", 
                date('Y-m-d H:i:s'), $lote ?? 0, $shortLinkAtual ?? 'NONE', 'SKIP'),
            FILE_APPEND
        );
        
        continue;
    }
    
    // Enviar email
    $result = @sendEmail(
        $params->senderName,
        $params->senderEmail,
        $to,
        $params->subject,
        $contentToSend,
        $params->attachment ?? '',
        $params->attachmentName ?? ''
    );
    
    // Debug para últimos 5 emails
    if ($i >= count($params->targets) - 5) {
        writeLn(">>> Resultado do envio para $to: " . ($result ? "SUCESSO" : "FALHA"));
    }
    
    if ($result) {
        $emailsSent++;
    } else {
        $emailsFailed++;
        if ($emailsFailed <= 10) {
            writeLn("Nao foi possivel enviar email para $to");
        }
    }
    
    // Progresso
    if ($current % PROGRESS_INTERVAL == 0) {
        $percentage = round(($current / $totalTargets) * 100, 1);
        
        $elapsed = microtime(true) - $startTime;
        $avgPerEmail = $elapsed / $current;
        $remaining = $totalTargets - $current;
        $eta = $remaining * $avgPerEmail;
        
        if ($eta < 60) {
            $etaStr = round($eta) . ' segundos';
        } elseif ($eta < 3600) {
            $etaStr = round($eta / 60) . ' minutos';
        } else {
            $etaStr = round($eta / 3600, 1) . ' horas';
        }
        
        writeLn("Progresso: $current/$totalTargets ($percentage%) - Enviados: [$emailsSent] - Falhas: $emailsFailed - Pulados: $emailsSkipped - ETA: $etaStr");
        
        if ($current % 500 == 0) {
            $successRate = ($emailsSent > 0) ? round(($emailsSent / $current) * 100, 1) : 0;
            writeLn("Taxa de sucesso: $successRate%");
            
            $cacheStats = $urlCache->getStats();
            writeLn("Cache: {$cacheStats['hits']} hits, {$cacheStats['misses']} misses ({$cacheStats['hitRate']}% hit rate)");
            
            if ($fallbackUsedCount > 0) {
                writeLn("Fallback (ultimo link encurtado) usado: $fallbackUsedCount vezes");
            }
        }
    }
    
    usleep($params->delay);
    
    // Keep-alive
    $now = time();
    if (($now - $lastKeepAlive) >= KEEPALIVE_INTERVAL) {
        @file_get_contents("https://www.google.com/favicon.ico");
        $lastKeepAlive = $now;
    }
    
    // Marco a cada 5000
    if ($current % 5000 == 0) {
        writeLn(">>> Marco: $current emails processados!");
    }
}

// Relatorio final
$endTime = microtime(true);
$executionTime = $endTime - $startTime;
$minutes = floor($executionTime / 60);
$seconds = $executionTime % 60;

writeLn("");
writeLn("==========================================================");
writeLn("                RELATORIO FINAL DE EXECUCAO              ");
writeLn("==========================================================");
writeLn("");

$message = "Execucao finalizada. Enviados: [$emailsSent], Falhas: $emailsFailed, Pulados: $emailsSkipped";
writeLn($message);

writeLn("Tempo gasto: $minutes minutos e " . round($seconds, 2) . " segundos");

if ($emailsSent > 0) {
    $avgTime = $executionTime / $emailsSent;
    writeLn("Tempo medio por email: " . round($avgTime, 2) . " segundos");
    writeLn("Velocidade: " . round(60 / $avgTime, 1) . " emails/minuto");
}

$successRate = ($totalTargets > 0) ? round(($emailsSent / $totalTargets) * 100, 2) : 0;
writeLn("Taxa de sucesso final: $successRate%");

// Estatísticas do cache
$cacheStats = $urlCache->getStats();
writeLn("");
writeLn("Cache:");
writeLn("  Hits: {$cacheStats['hits']}");
writeLn("  Misses: {$cacheStats['misses']}");
writeLn("  Taxa: {$cacheStats['hitRate']}%");

// Estatísticas dos encurtadores (via shortener_optimized.php)
// Usa instância estática do SimpleShortener
$tempResult = shortenUrlChecked('https://test.invalid');
// As stats são da instância estática, acessíveis via nova chamada
writeLn("");
writeLn("Encurtadores: (estatisticas via shortener_optimized.php)");

if ($fallbackUsedCount > 0) {
    writeLn("");
    writeLn("Fallback (ultimo link encurtado) usado: $fallbackUsedCount vezes");
}

if ($emailsSkipped > 0) {
    writeLn("");
    writeLn("*** ATENCAO: $emailsSkipped emails foram PULADOS por falha de validacao ***");
}

writeLn("");
writeLn("Arquivo de log: $logMapFile");
writeLn("==========================================================");

if ($enableLogging) {
    writeLn("Script finalizado.");
    writeLn("Fim do script.");
}

exit($emailsFailed > 0 ? 1 : 0);
?>