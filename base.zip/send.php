<?php
/**
 * Sistema Otimizado de Envio com Encurtamento - VERSÃO CORRIGIDA
 * Versão 3.4 - Com proteção total contra falhas
 */

// Configurações iniciais
ini_set('max_execution_time', 0);
ini_set('memory_limit', '512M');
ignore_user_abort(true);
set_time_limit(0);

// Desabilitar buffering
@ini_set('output_buffering', 'off');
@ini_set('zlib.output_compression', false);
while (@ob_end_flush());
ob_implicit_flush(true);

// Carregar dependências
require_once('src/email.php');
require_once('src/shortener_optimized.php');

// WriteLn com flush
function writeLn($msg) {
    echo $msg . PHP_EOL;
    @flush();
}

// Configurações
$enableLogging = true;
define('BATCH_SIZE', 100);
define('PROGRESS_INTERVAL', 100);
define('KEEPALIVE_INTERVAL', 60);
define('CACHE_SIZE', 500);
define('MAX_FAILS_BEFORE_ROTATION', 3);
define('EMAIL_DEBUG', false);  // Desabilita debug do emailb.php

/**
 * Parser de argumentos
 */
function parseArgv() {
    $argv = $_SERVER['argv'] ?? [];
    $params = [];
    $lastKey = '';

    foreach ($argv as $i => $arg) {
        if ($i === 0) continue;

        if (preg_match('/^--([^=]+)=(.*)/', $arg, $matches)) {
            $params[$matches[1]] = $matches[2];
            $lastKey = '';
        }
        elseif (preg_match('/^--(.+)/', $arg, $matches)) {
            $lastKey = $matches[1];
            $params[$lastKey] = '';
        }
        elseif ($lastKey) {
            $params[$lastKey] = trim($params[$lastKey] . ' ' . $arg);
        }
    }

    foreach ($params as &$value) {
        $value = trim($value);
    }

    return $params;
}

/**
 * Obtém parâmetros
 */
function getParams() {
    $params = parseArgv();
    $obj = new stdClass;

    // Delay
    if (isset($params['delay']) && is_numeric($params['delay'])) {
        $obj->delay = intval($params['delay']) * 1000;
    } else {
        $obj->delay = 180000;
    }

    // Remetente
    $obj->senderName = $params['nome'] ?? null;
    $obj->senderEmail = $params['de'] ?? null;
    $obj->subject = $params['assunto'] ?? null;
    
    // Conteúdo
    if (isset($params['conteudo']) && file_exists($params['conteudo'])) {
        $obj->content = file_get_contents($params['conteudo']);
    } else {
        $obj->content = null;
    }

    // Anexo
    if (isset($params['anexo']) && file_exists($params['anexo'])) {
        $obj->attachment = file_get_contents($params['anexo']);
        $obj->attachmentName = basename($params['anexo']);
    } else {
        $obj->attachment = null;
        $obj->attachmentName = null;
    }

    // Destinatários
    $obj->targets = [];
    
    if (isset($params['para'])) {
        $email = trim($params['para']);
        if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $obj->targets[] = $email;
        }
    }

    if (isset($params['lista']) && file_exists($params['lista'])) {
        $lines = file($params['lista'], FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            $email = trim($line);
            if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $obj->targets[] = $email;
            }
        }
    }

    $obj->targets = array_unique($obj->targets);

    return $obj;
}

/**
 * Verifica sendmail
 */
function verifySendMail() {
    $paths = ['/usr/sbin/sendmail', '/usr/bin/sendmail', '/usr/lib/sendmail'];
    foreach ($paths as $path) {
        if (is_file($path) && is_executable($path)) {
            return true;
        }
    }
    writeLn("ERRO: Sendmail nao encontrado!");
    writeLn("Execute: sudo apt-get install postfix");
    exit(1);
}

/**
 * Gera string aleatória
 */
function generateRandomString($length = 8) {
    $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $str = '';
    for ($i = 0; $i < $length; $i++) {
        $str .= $chars[mt_rand(0, strlen($chars) - 1)];
    }
    return $str;
}

/**
 * Cache de URLs
 */
class URLCache {
    private $cache = [];
    private $hits = 0;
    private $misses = 0;
    private $maxSize;
    
    public function __construct($maxSize = 10000) {
        $this->maxSize = $maxSize;
    }
    
    public function get($longUrl) {
        $hash = md5($longUrl);
        if (isset($this->cache[$hash])) {
            $this->hits++;
            return $this->cache[$hash]['short'];
        }
        $this->misses++;
        return null;
    }
    
    public function set($longUrl, $shortUrl) {
        $hash = md5($longUrl);
        if (count($this->cache) >= $this->maxSize) {
            array_shift($this->cache);
        }
        $this->cache[$hash] = ['short' => $shortUrl, 'time' => time()];
    }
    
    public function getStats() {
        $total = $this->hits + $this->misses;
        $hitRate = $total > 0 ? round(($this->hits / $total) * 100, 1) : 0;
        return [
            'hits' => $this->hits,
            'misses' => $this->misses,
            'hitRate' => $hitRate
        ];
    }
}

/**
 * Rotação simples de domínios - SEM SUBDOMÍNIOS INEXISTENTES
 */
class DomainRotator {
    private $domains = [];
    private $currentIndex = 0;
    
    public function __construct($domains) {
        $this->domains = $domains;
    }
    
    public function getNext() {
        // Rotação simples entre os domínios existentes
        $domain = $this->domains[$this->currentIndex % count($this->domains)];
        $this->currentIndex++;
        return $domain;
    }
}

/**
 * Sistema multi-serviço
 */
class MultiShortener {
    private $stats = [
        'is.gd' => ['success' => 0, 'fail' => 0],
        'v.gd' => ['success' => 0, 'fail' => 0],
        'tinyurl' => ['success' => 0, 'fail' => 0]
    ];
    
    public function shorten($url, $cache = null) {
        if ($cache) {
            $cached = $cache->get($url);
            if ($cached) return ['ok' => true, 'short' => $cached, 'service' => 'cache'];
        }
        
        // Tenta is.gd
        $result = shortenUrlChecked($url);
        if ($result['ok']) {
            $this->stats['is.gd']['success']++;
            if ($cache) $cache->set($url, $result['short']);
            return $result;
        }
        
        $this->stats['is.gd']['fail']++;
        return ['ok' => false, 'reason' => 'all_failed'];
    }
    
    public function getStats() {
        return $this->stats;
    }
}

/**
 * Gera query aleatória
 */
function generateRandomQuery($length = 5) {
    // Varia o tamanho do parâmetro também
    $realLength = mt_rand(5, 10);  // Entre 5 e 10 caracteres
    
    $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $str = '';
    for ($i = 0; $i < $realLength; $i++) {
        $str .= $chars[mt_rand(0, strlen($chars) - 1)];
    }
    
    // Varia o nome do parâmetro
    $params = ['r', 'id', 'ref', 'utm', 'c', 'source', 'track'];
    $param = $params[array_rand($params)];
    
    return '?' . $param . '=' . $str;
}

// ================================================================
//                     EXECUCAO PRINCIPAL
// ================================================================

verifySendMail();

if ($enableLogging) {
    writeLn("Inicio da execucao do script...");
}

$params = getParams();
$totalTargets = count($params->targets);

// Contadores principais
$emailsSent = 0;
$emailsFailed = 0;

if ($totalTargets === 0) {
    writeLn("ERRO: Nenhum destinatario encontrado!");
    exit(1);
}

// Inicializar sistemas
$urlCache = new URLCache(CACHE_SIZE);
$domainRotator = new DomainRotator([
    "https://www.puertasycerrajeria.com",
    "https://www.ongonagency.com",
    "https://www.belezzavital.com",
]);
$shortener = new MultiShortener();

// Variáveis de controle
$shortLinkAtual = '';

// PROTEÇÃO: Controle de falhas do encurtador
$failureCount = 0;
$maxConsecutiveFailures = 5;
$useShortener = true;
$lastWorkingLink = '';

// Log file
$logMapFile = __DIR__ . "/short_maps_" . date('Y-m-d') . ".csv";
if (!file_exists($logMapFile)) {
    @file_put_contents($logMapFile, "timestamp;lote;long;short;status\n");
}

// Mostrar informações
writeLn("Total de alvos: $totalTargets");
writeLn("");
writeLn("==========================================================");
writeLn("     SISTEMA DE ENVIO EM MASSA v3.0 - OTIMIZADO         ");
writeLn("==========================================================");
writeLn("");
writeLn("Total de destinatarios: $totalTargets");
writeLn("Delay entre envios: " . ($params->delay / 1000) . "ms");
writeLn("Tamanho do lote: " . BATCH_SIZE . " emails");
writeLn("Cache maximo: " . CACHE_SIZE . " URLs");

if (!empty($params->attachmentName)) {
    writeLn("Anexo: {$params->attachmentName}");
}

writeLn("");
writeLn("Iniciando envio em massa...");
writeLn("----------------------------------------------------------");

$startTime = microtime(true);
$lastKeepAlive = time();

// Loop principal
foreach ($params->targets as $i => $to) {
    $current = $i + 1;
    
    // Debug para últimos 5 emails
    if ($i >= count($params->targets) - 5) {
        writeLn(">>> ATENCAO: Processando email $i de " . count($params->targets));
        writeLn(">>> Email: $to");
    }
    
    // Novo lote
    if ($i % BATCH_SIZE == 0) {
        $lote = (int)floor($i / BATCH_SIZE + 1);
        
        $domain = $domainRotator->getNext();
        $query = generateRandomQuery(mt_rand(5, 8));
        $fullUrl = $domain . $query;
        
        // PROTEÇÃO: Salva link anterior como backup
        $linkBackup = !empty($shortLinkAtual) ? $shortLinkAtual : $fullUrl;
        
        // Se o encurtador está desabilitado, usa link direto
        if (!$useShortener) {
            $shortLinkAtual = $fullUrl;
            writeLn("LOTE $lote - Encurtador desabilitado, usando link direto");
            writeLn("  Link direto: $fullUrl");
            
            @file_put_contents($logMapFile, 
                sprintf("%s;%d;%s;%s;DIRETO\n", 
                    date('Y-m-d H:i:s'), $lote, $fullUrl, $fullUrl),
                FILE_APPEND
            );
        } else {
            // Tenta encurtar
            $result = $shortener->shorten($fullUrl, $urlCache);
            
            if ($result['ok']) {
                $shortLinkAtual = $result['short'];
                $lastWorkingLink = $shortLinkAtual; // Salva como último funcionando
                $service = $result['service'] ?? 'unknown';
                $cacheHit = $service == 'cache' ? 'SIM' : 'NAO';
                $failureCount = 0; // Reset contador de falhas
                
                writeLn("LOTE $lote processando...");
                writeLn("  Link original: $fullUrl");
                writeLn("  Link encurtado: $shortLinkAtual");
                writeLn("  Servico usado: $service (Cache: $cacheHit)");
                
                @file_put_contents($logMapFile, 
                    sprintf("%s;%d;%s;%s;OK\n", 
                        date('Y-m-d H:i:s'), $lote, $fullUrl, $shortLinkAtual),
                    FILE_APPEND
                );
            } else {
                // PROTEÇÃO: Usa backup em caso de falha
                $failureCount++;
                $shortLinkAtual = $linkBackup;
                
                writeLn("LOTE $lote - Encurtador falhou! (Falha $failureCount/$maxConsecutiveFailures)");
                writeLn("  Usando link de backup: $shortLinkAtual");
                
                // Desabilita encurtador após muitas falhas
                if ($failureCount >= $maxConsecutiveFailures) {
                    $useShortener = false;
                    writeLn("*** ENCURTADOR DESABILITADO APÓS $failureCount FALHAS CONSECUTIVAS ***");
                }
                
                @file_put_contents($logMapFile, 
                    sprintf("%s;%d;%s;%s;BACKUP\n", 
                        date('Y-m-d H:i:s'), $lote, $fullUrl, $shortLinkAtual),
                    FILE_APPEND
                );
            }
        }
    }
    
    // PROTEÇÃO FINAL: Garante que sempre tem um link
    if (empty($shortLinkAtual)) {
        $shortLinkAtual = $domainRotator->getNext() . generateRandomQuery(5);
        writeLn("  Link de emergencia gerado: $shortLinkAtual");
    }
    
    $contentToSend = str_replace('[-meu_link_curto-]', $shortLinkAtual, $params->content);
    
    // Enviar email
    $result = @sendEmail(
        $params->senderName,
        $params->senderEmail,
        $to,
        $params->subject,
        $contentToSend,
        $params->attachment ?? '',
        $params->attachmentName ?? ''
    );
    
    // Debug para confirmar envio
    if ($i >= count($params->targets) - 5) {
        writeLn(">>> Resultado do envio para $to: " . ($result ? "SUCESSO" : "FALHA"));
    }
    
    if ($result) {
        $emailsSent++;
    } else {
        $emailsFailed++;
        if ($emailsFailed <= 10) {
            writeLn("Nao foi possivel enviar email para $to");
        }
    }
    
    // Progresso
    if ($current % PROGRESS_INTERVAL == 0) {
        $percentage = round(($current / $totalTargets) * 100, 1);
        
        $elapsed = microtime(true) - $startTime;
        $avgPerEmail = $elapsed / $current;
        $remaining = $totalTargets - $current;
        $eta = $remaining * $avgPerEmail;
        
        if ($eta < 60) {
            $etaStr = round($eta) . ' segundos';
        } elseif ($eta < 3600) {
            $etaStr = round($eta / 60) . ' minutos';
        } else {
            $etaStr = round($eta / 3600, 1) . ' horas';
        }
        
        // FORMATO COM COLCHETES (funciona no teste)
        writeLn("Progresso: $current/$totalTargets ($percentage%) - Enviados: [$emailsSent] - Falhas: $emailsFailed - ETA: $etaStr");
        
        if ($current % 500 == 0) {
            $successRate = ($emailsSent > 0) ? round(($emailsSent / $current) * 100, 1) : 0;
            writeLn("Taxa de sucesso: $successRate%");
            
            $cacheStats = $urlCache->getStats();
            writeLn("Cache: {$cacheStats['hits']} hits, {$cacheStats['misses']} misses ({$cacheStats['hitRate']}% hit rate)");
            
            // Mostra status do encurtador
            if (!$useShortener) {
                writeLn(">>> AVISO: Encurtador desabilitado - usando links diretos");
            }
        }
    }
    
    usleep($params->delay);
    
    // Keep-alive
    $now = time();
    if (($now - $lastKeepAlive) >= KEEPALIVE_INTERVAL) {
        @file_get_contents("https://www.google.com/favicon.ico");
        $lastKeepAlive = $now;
    }
    
    // Marco a cada 5000
    if ($current % 5000 == 0) {
        writeLn(">>> Marco: $current emails processados!");
    }
}

// Garantir envio do último email
if (!empty($params->targets)) {
    $ultimoEmail = end($params->targets);
    writeLn("");
    writeLn("=== GARANTIA DE ENVIO DO ULTIMO EMAIL ===");
    writeLn("Garantindo envio do ultimo email: $ultimoEmail");
    
    // Usa um link fresco para o último email
    $finalDomain = $domainRotator->getNext();
    $finalQuery = generateRandomQuery(8);
    $finalUrl = $finalDomain . $finalQuery;
    
    $contentFinal = str_replace('[-meu_link_curto-]', $finalUrl, $params->content);
    
    $result = @sendEmail(
        $params->senderName,
        $params->senderEmail,
        $ultimoEmail,
        $params->subject . " (FINAL)",
        $contentFinal,
        $params->attachment ?? '',
        $params->attachmentName ?? ''
    );
    
    writeLn("Ultimo email " . ($result ? "enviado com sucesso" : "falhou"));
    writeLn("Link usado: $finalUrl");
    writeLn("=========================================");
}

// Relatorio final
$endTime = microtime(true);
$executionTime = $endTime - $startTime;
$minutes = floor($executionTime / 60);
$seconds = $executionTime % 60;

writeLn("");
writeLn("==========================================================");
writeLn("                RELATORIO FINAL DE EXECUCAO              ");
writeLn("==========================================================");
writeLn("");

// FORMATO COM COLCHETES (funciona no teste)
$message = "Execucao finalizada. Enviados: [$emailsSent], Falhas: $emailsFailed";
writeLn($message);

writeLn("Tempo gasto: $minutes minutos e " . round($seconds, 2) . " segundos");

if ($emailsSent > 0) {
    $avgTime = $executionTime / $emailsSent;
    writeLn("Tempo medio por email: " . round($avgTime, 2) . " segundos");
    writeLn("Velocidade: " . round(60 / $avgTime, 1) . " emails/minuto");
}

$successRate = ($totalTargets > 0) ? round(($emailsSent / $totalTargets) * 100, 2) : 0;
writeLn("Taxa de sucesso final: $successRate%");

// Mostra se o encurtador foi desabilitado
if (!$useShortener) {
    writeLn("");
    writeLn("AVISO: Encurtador foi desabilitado durante a execucao!");
}

$cacheStats = $urlCache->getStats();
writeLn("");
writeLn("Estatisticas do Cache:");
writeLn("  Hits: {$cacheStats['hits']}");
writeLn("  Misses: {$cacheStats['misses']}");
writeLn("  Taxa de acerto: {$cacheStats['hitRate']}%");

$serviceStats = $shortener->getStats();
writeLn("");
writeLn("Estatisticas dos Servicos:");
foreach ($serviceStats as $name => $stats) {
    $total = $stats['success'] + $stats['fail'];
    if ($total > 0) {
        $rate = round(($stats['success'] / $total) * 100, 1);
        writeLn("  $name: {$stats['success']} sucessos, {$stats['fail']} falhas ($rate%)");
    }
}

writeLn("==========================================================");

if ($enableLogging) {
    writeLn("Script finalizado.");
    writeLn("Fim do script.");
}

exit($emailsFailed > 0 ? 1 : 0);
?>