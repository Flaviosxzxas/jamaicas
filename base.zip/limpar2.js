const { exec } = require('child_process');

// Função para executar um comando shell e retornar uma promessa
function shellExec(command) {
    return new Promise((resolve, reject) => {
        exec(command, (error, stdout, stderr) => {
            if (error) {
                reject(error);
                return;
            }
            resolve(stdout.trim());
        });
    });
}

async function cleanDeferredQueueAndRestartPostfix() {
    try {
        // Limpar a fila de e-mails deferred do Postfix
        console.log("Limpando a fila de e-mails deferred do Postfix...");
        await shellExec('sudo postsuper -d ALL deferred');
        console.log("Fila de e-mails deferred limpa com sucesso!");

        // Reiniciar Postfix
//       console.log("Reiniciando o Postfix...");
//       await shellExec('sudo systemctl restart postfix');
//       console.log("Postfix reiniciado com sucesso!");

    } catch (error) {
        console.error("Erro ao executar a ação:", error.message);
    }
}

cleanDeferredQueueAndRestartPostfix();
