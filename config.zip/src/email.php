<?php
declare(strict_types=1);

/**
 * email.php - VERSÃO v6.2 - HEADER UNIVERSAL + ENCODING ADAPTATIVO
 * 
 * ESTRATÉGIA: Headers mínimos + proteção de IP/domínio
 * 
 * MUDANÇAS v6.2 (inspiradas por análise PHPMailer):
 *   ✓ Encoding adaptativo: 7bit (ASCII), 8bit, ou QP conforme conteúdo
 *   ✓ Word-wrap UTF-8-safe no text/plain (não quebra multi-byte)
 *   ✓ HTML line wrap ≤ 998 chars (RFC 2822 §2.1.1 hard limit)
 *   ✓ Validação Message-ID contra RFC 5322 §3.6.4
 *   ✓ Sanitização shell-safe do -f (CVE-2016-10033 style)
 *   ✓ DKIM via Rspamd milter (não duplica na aplicação)
 * 
 * HEADERS PRESENTES:
 *   ✓ From              (obrigatório RFC 5322)
 *   ✓ Date              (obrigatório RFC 5322)
 *   ✓ Message-ID        (obrigatório RFC 5322)
 *   ✓ MIME-Version       (obrigatório para HTML)
 *   ✓ Content-Type       (obrigatório para MIME)
 *   ✓ List-Unsubscribe   (válvula de escape - evita "marcar como spam")
 *   ✓ List-Unsubscribe-Post (One-Click - complemento obrigatório)
 *   ✓ X-Abuse            (compliance - mostra boa fé)
 * 
 * HEADERS REMOVIDOS:
 *   ✗ Precedence: bulk       (grita "sou bulk mail")
 *   ✗ X-Priority             (desnecessário, filtros penalizam)
 *   ✗ X-Campaign-ID          (flag de campanha automatizada)
 *   ✗ X-EventGuid            (flag de sistema de envio)
 *   ✗ Content-Language        (emails pessoais não têm isso)
 *   ✗ Accept-Language         (emails pessoais não têm isso)
 *   ✗ Content-Disposition     (desnecessário em multipart/alternative)
 */

require_once __DIR__ . '/term.php';

/* ------------------------- Defaults/guards de config ------------------------- */
if (!defined('USE_VERP'))           define('USE_VERP', true);
if (!defined('VERP_PREFIX'))        define('VERP_PREFIX', 'bounce');
if (!defined('VERP_SEP'))           define('VERP_SEP', '+');
if (!defined('UNSUB_SECRET'))       define('UNSUB_SECRET', 'Gx9pT3aQ1mRxW7bY5kW2nH8cV4sL0');
if (!defined('UNSUB_VALID_SECS'))   define('UNSUB_VALID_SECS', 60 * 60 * 24 * 30);
if (!defined('ADD_AUTO_SUBMITTED')) define('ADD_AUTO_SUBMITTED', false);

if (!defined('SERVER_DOMAIN')) {
    $serverDomain = getenv('SERVER_DOMAIN') ?: gethostname();
    if ($serverDomain && strpos($serverDomain, '.') !== false) {
        define('SERVER_DOMAIN', $serverDomain);
    } else {
        $myhostname = trim(shell_exec('postconf -h myhostname 2>/dev/null') ?: '');
        define('SERVER_DOMAIN', $myhostname ?: 'localhost.localdomain');
    }
}

if (!function_exists('debugLn')) {
    function debugLn(string $s): void {
        if (PHP_SAPI === 'cli') {
            fwrite(STDOUT, $s . "\n");
        }
    }
}

/* ============== FUNÇÕES UTILITÁRIAS (SEM MUDANÇAS) ============== */

function validateAndFixDomain(string $email): array {
    $parts = explode('@', $email);
    if (count($parts) !== 2) {
        return ['valid' => false, 'domain' => SERVER_DOMAIN, 'email' => 'noreply@' . SERVER_DOMAIN];
    }
    
    list($localPart, $domain) = $parts;
    $domain = strtolower(trim($domain));
    
    return ['valid' => true, 'domain' => $domain, 'email' => $email];
}

function validateAndFixHTML(string $html): string {
    if (!mb_check_encoding($html, 'UTF-8')) {
        $html = mb_convert_encoding($html, 'UTF-8', 'auto');
    }
    
    $html = preg_replace('/<title([^>\s])/i', '<title $1', $html);
    
    $hasHtmlOpen = preg_match('/<html[^>]*>/i', $html);
    $hasHtmlClose = preg_match('/<\/html>/i', $html);
    $hasBodyOpen = preg_match('/<body[^>]*>/i', $html);
    $hasBodyClose = preg_match('/<\/body>/i', $html);
    
    if ($hasHtmlOpen && !$hasHtmlClose) {
        if ($hasBodyOpen && !$hasBodyClose) {
            $html .= '</body>';
        }
        $html .= '</html>';
    }
    
    $html = preg_replace('/<\s*$/', '', $html);
    $html = preg_replace('/<\/\s*$/', '', $html);
    
    $openP = preg_match_all('/<p[^>]*>/i', $html);
    $closeP = preg_match_all('/<\/p>/i', $html);
    if ($openP > $closeP) {
        for ($i = 0; $i < ($openP - $closeP); $i++) {
            $html .= '</p>';
        }
    }
    
    $openEm = preg_match_all('/<em[^>]*>/i', $html);
    $closeEm = preg_match_all('/<\/em>/i', $html);
    if ($openEm > $closeEm) {
        for ($i = 0; $i < ($openEm - $closeEm); $i++) {
            $html .= '</em>';
        }
    }
    
    return $html;
}

function syncHtmlTitle(string $html, string $subject): string {
    $cleanSubject = preg_replace('/\s*[\(\#]\d+[\)]*\s*$/', '', $subject);
    $cleanSubject = htmlspecialchars($cleanSubject, ENT_QUOTES, 'UTF-8');
    
    $contentBefore = strlen(strip_tags($html));
    if ($contentBefore < 10) {
        return $html;
    }
    
    if (preg_match('/<title[^>]*>.*?<\/title>/is', $html)) {
        $result = preg_replace(
            '/<title[^>]*>.*?<\/title>/is',
            '<title>' . $cleanSubject . '</title>',
            $html
        );
        if ($result === null) return $html;
        $html = $result;
    } 
    elseif (preg_match('/<head[^>]*>/i', $html)) {
        $result = preg_replace(
            '/(<head[^>]*>)/i',
            '$1<title>' . $cleanSubject . '</title>',
            $html,
            1
        );
        if ($result === null) return $html;
        $html = $result;
    }
    elseif (preg_match('/<html[^>]*>/i', $html)) {
        $result = preg_replace(
            '/(<html[^>]*>)/i',
            '$1<head><meta charset="UTF-8"><title>' . $cleanSubject . '</title></head>',
            $html,
            1
        );
        if ($result === null) return $html;
        $html = $result;
    }
    elseif (!preg_match('/<html/i', $html)) {
        $html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>' . 
                $cleanSubject . 
                '</title></head><body>' . $html . '</body></html>';
    }
    
    $contentAfter = strlen(strip_tags($html));
    if ($contentAfter < $contentBefore * 0.8) {
        debugLn('[ERROR] syncHtmlTitle: CONTEÚDO FOI PERDIDO! Revertendo...');
        return validateAndFixHTML($html);
    }
    
    return $html;
}

function isValidHTML(string $html): bool {
    $stripped = preg_replace('/\s+/', '', strip_tags($html));
    
    if (empty($stripped)) {
        debugLn('[ERROR] HTML não tem conteúdo textual');
        return false;
    }
    
    if (strlen($stripped) < 10) {
        debugLn('[ERROR] HTML muito curto: ' . strlen($stripped) . ' chars');
        return false;
    }
    
    return true;
}

function htmlToText(string $html): string {
    if (empty($html)) return '';
    
    $text = preg_replace('~<(script|style)[^>]*>.*?</\1>~is', '', $html);
    if ($text === null) $text = $html;
    
    $text = preg_replace('~<!--.*?-->~s', '', $text);
    if ($text === null) $text = $html;

    $text = preg_replace_callback(
        '~<a\s+[^>]*href=["\']?([^"\'>\s]+)["\']?[^>]*>(.*?)</a>~is',
        function($m){
            $linkText = trim(strip_tags($m[2]));
            return $linkText !== '' ? $linkText.' ['.$m[1].']' : $m[1];
        },
        $text
    );
    if ($text === null) $text = $html;

    $text = preg_replace('~<\s*br\s*/?>~i', "\n", $text);
    if ($text === null) $text = $html;
    
    $text = preg_replace('~</\s*(p|div|section|article|header|footer|h[1-6]|tr)\s*>~i', "\n\n", $text);
    if ($text === null) $text = $html;
    
    $text = preg_replace('~<\s*(ul|ol)\b[^>]*>~i', "\n", $text);
    if ($text === null) $text = $html;
    
    $text = preg_replace('~<\s*li\b[^>]*>~i', "- ", $text);
    if ($text === null) $text = $html;
    
    $text = preg_replace('~</\s*li\s*>~i', "\n", $text);
    if ($text === null) $text = $html;

    $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $text = strip_tags($text);
    
    if ($text === null || $text === false || !is_string($text)) {
        $text = '';
    }

    $result = preg_replace("/[ \t]+/u", ' ', $text);
    if ($result === null) $result = $text;
    
    $result = preg_replace("/^\h+/mu", '', $result);
    if ($result === null) $result = $text;
    
    $result = preg_replace("/\h+$/mu", '', $result);
    if ($result === null) $result = $text;
    
    $result = preg_replace("/(\r\n|\r|\n){3,}/", "\n\n", $result);
    if ($result === null) $result = $text;
    
    $result = trim($result);

    $lines = [];
    foreach (preg_split("/\r?\n/", $result) as $line) {
        if (preg_match('~https?://\S{40,}~', $line)) {
            $lines[] = $line;
        } else {
            $lines[] = wordwrap($line, 78, "\r\n", true);
        }
    }
    
    return implode("\r\n", $lines);
}

/**
 * v6.2 - Word-wrap UTF-8-safe para text/plain
 * Respeita limite de 78 chars (RFC 2822 §2.1.1) sem quebrar multi-byte
 */
function wordWrapUtf8(string $text, int $width = 78, string $break = "\r\n"): string {
    $lines = [];
    foreach (preg_split("/\r?\n/", $text) as $line) {
        // Linhas com URLs longos: não quebrar (evita cortar link)
        if (preg_match('~https?://\S{40,}~', $line)) {
            $lines[] = $line;
            continue;
        }
        // mb_strwidth respeita largura visual de caracteres multi-byte
        if (mb_strwidth($line, 'UTF-8') <= $width) {
            $lines[] = $line;
            continue;
        }
        $words = explode(' ', $line);
        $current = '';
        foreach ($words as $word) {
            $testLine = ($current === '') ? $word : $current . ' ' . $word;
            if (mb_strwidth($testLine, 'UTF-8') > $width && $current !== '') {
                $lines[] = $current;
                $current = $word;
            } else {
                $current = $testLine;
            }
        }
        if ($current !== '') {
            $lines[] = $current;
        }
    }
    return implode($break, $lines);
}

/**
 * v6.2 - DEPRECATED / DESATIVADA PARA text/html
 *
 * NÃO usar para HTML de email.
 *
 * Motivo:
 * Esta função antiga inseria quebras reais "\r\n" no HTML bruto para tentar
 * respeitar o limite de 998 octetos por linha. Isso podia quebrar href="",
 * src="", tokens, JWT, assinaturas, parâmetros UTM e links de tracking.
 *
 * Estratégia atual:
 * - text/html é sempre enviado como quoted-printable.
 * - O quoted-printable faz soft-break com "=" no fim da linha.
 * - A quebra feita pelo quoted-printable não altera o HTML decodificado.
 *
 * Mantida apenas para compatibilidade com código antigo.
 * Se algum trecho legado chamar wrapHtmlLines(), ela NÃO quebra mais o HTML.
 */
function wrapHtmlLines(string $html, int $maxLen = 998): string {
    unset($maxLen);
    return $html;
}

/**
 * Spintax — processa {opção1|opção2|opção3} no texto
 * Aceita nesting: {Hola {amigo|colega}|Buenos días}
 */
function spintax(string $text): string {
    $pattern = '/\{([^{}]+)\}/';
    while (preg_match($pattern, $text)) {
        $text = preg_replace_callback($pattern, function($match) {
            $options = explode('|', $match[1]);
            return trim($options[array_rand($options)]);
        }, $text);
    }
    return $text;
}

function encodeHeaderRFC2047(string $s): string {
    // ASCII puro → sem encoding (mimetiza Gmail/Outlook)
    if (!preg_match('/[^\x20-\x7E]/', $s)) {
        return $s;
    }

    // Q-encoding header-safe (RFC 2047 §4.2)
    // Encoda apenas bytes não-ASCII + caracteres reservados em headers
    $encoded = preg_replace_callback(
        '/[^\x21-\x3C\x3E\x40-\x5E\x60-\x7E]/',
        function($m) {
            return '=' . strtoupper(bin2hex($m[0]));
        },
        $s
    );

    // Espaço vira underscore (regra Q-encoding em headers)
    $encoded = str_replace(' ', '_', $encoded);

    // Folding RFC 2047: encoded-word não pode passar de 75 octetos
    $maxContent = 75 - strlen('=?UTF-8?Q??=');

    if (strlen($encoded) <= $maxContent) {
        return '=?UTF-8?Q?' . $encoded . '?=';
    }

    // Subject longo → quebra em múltiplos encoded-words separados por CRLF + space
    $chunks = [];
    $current = '';

    // Tokeniza preservando sequências =XX para não quebrar no meio
    preg_match_all('/=[0-9A-F]{2}|./', $encoded, $tokens);

    foreach ($tokens[0] as $token) {
        if (strlen($current) + strlen($token) > $maxContent) {
            $chunks[] = '=?UTF-8?Q?' . $current . '?=';
            $current = $token;
        } else {
            $current .= $token;
        }
    }
    if ($current !== '') {
        $chunks[] = '=?UTF-8?Q?' . $current . '?=';
    }

    return implode("\r\n ", $chunks);
}

function buildUnsubToken(string $email): array {
    $ts  = time();
    $msg = $email . '|' . $ts;
    $sig = base64_encode(hash_hmac('sha256', $msg, (string)UNSUB_SECRET, true));
    return [$ts, rtrim(strtr($sig, '+/', '-_'), '=')];
}

function verifyUnsubToken(string $email, int $ts, string $sig): bool {
    if ((time() - $ts) > (int)UNSUB_VALID_SECS) return false;
    $msg = $email . '|' . $ts;
    $chk = rtrim(strtr(base64_encode(hash_hmac('sha256', $msg, (string)UNSUB_SECRET, true)), '+/', '-_'), '=');
    return hash_equals($chk, $sig);
}

/* shortener_html_safe removido na v6.0 - links vão diretos no HTML */

/* ═══════════════════════════════════════════════════════════
 * FUNÇÃO PRINCIPAL - v5.1
 * 
 * Headers finais (8 total):
 * 
 * From: ✓              → Obrigatório
 * Date: ✓              → Obrigatório
 * Message-ID: ✓        → Obrigatório
 * MIME-Version: ✓       → Obrigatório
 * Content-Type: ✓       → Obrigatório
 * List-Unsubscribe: ✓   → Protege IP (válvula de escape)
 * List-Unsubscribe-Post: ✓ → Complemento One-Click
 * X-Abuse: ✓            → Compliance (mostra boa fé)
 * ═══════════════════════════════════════════════════════════ */

function sendEmail(
    string $sender,
    string $senderEmail,
    string $to,
    string $subject,
    string $content,
    $attachment = '',
    string $attachmentName = ''
) {
	/*
	$refNumber1 = generateRefNumber();
	*/
    /* ============= VALIDAÇÃO DE DOMÍNIO ============= */
    
    if (strpos($senderEmail, '@') === false) {
        $senderEmail = 'noreply@' . ltrim($senderEmail, '@');
    }
    
    if (!filter_var($senderEmail, FILTER_VALIDATE_EMAIL)) {
        $senderEmail = 'noreply@' . SERVER_DOMAIN;
    }
    
    $domainCheck = validateAndFixDomain($senderEmail);
    if (!$domainCheck['valid']) {
        $senderEmail = $domainCheck['email'];
    }
    
    $domain = $domainCheck['domain'];
    
    if (empty($domain) || strpos($domain, '.') === false) {
        debugLn('[ERROR] Domínio inválido: ' . $domain);
        return false;
    }
	
	/* ============= VALIDAÇÃO DO DESTINATÁRIO ============= */
    
    $to = trim($to);
    
    if (
        !filter_var($to, FILTER_VALIDATE_EMAIL) ||
        preg_match('/[\r\n]/', $to)
    ) {
        debugLn('[ERROR] Destinatário inválido: ' . $to);
        return false;
    }

    /* ==================== Variáveis auxiliares ==================== */
    
    $attachmentName   = $attachmentName ?: (generateRandomNumber1(3, 16) . '.pdf');
    $currentDateTime  = date('Y-m-d H:i:s');
    $messageID        = generateMessageID($domain);

    /* ─── v6.2 - Validação Message-ID RFC 5322 §3.6.4 ───
     * Formato obrigatório: <local@domain>
     * Se generateMessageID() retornar algo fora do padrão, gera um seguro.
     * Message-ID malformado causa rejeição em MTAs estritos (Microsoft, Yahoo). */
    if (!preg_match('/^<[^\s@>]+@[^\s@>]+>$/', $messageID)) {
        $messageID = '<' . bin2hex(random_bytes(16)) . '@' . $domain . '>';
    }

    /* ========= BOUNCE ADDRESS ========= */
    
    list($fromLocal, ) = explode('@', $senderEmail);
    
    $verpTag    = bin2hex(hash('crc32b', $to, true));
    $useVerp    = defined('USE_VERP') ? (bool)USE_VERP : false;
    $verpSep    = defined('VERP_SEP') ? (string)VERP_SEP : '+';

    $bounceAddress = $useVerp
        ? ($fromLocal . $verpSep . $verpTag . '@' . $domain)
        : ($fromLocal . '@' . $domain);

    /* ─── v6.2 - Sanitização shell-safe do -f (inspirado PHPMailer::isShellSafe) ───
     * Previne injeção de comandos via caracteres especiais no endereço.
     * Se o endereço tiver algo além de alfanumérico, @, _, -, . e + → não passa -f */
    $isSafe = (bool) preg_match('/^[a-zA-Z0-9@_.+\-]+$/', $bounceAddress);
    $additionalParams = $isSafe ? ("-f" . $bounceAddress) : '';

    /* ---------------------- Unsubscribe seguro -------------------------- */
    [$ts, $sig] = buildUnsubToken($to);
	/*
	$unsubUrl   = "https://www.google.com/#{$refNumber1}/?e=" . rawurlencode($to) . "&ts={$ts}&sig={$sig}";
    */
    $unsubUrl = "https://unsubscribe.{$domain}/unsubscribe.php?e=" .
                rawurlencode($to) .
                "&ts={$ts}&sig={$sig}";
    
    $unsubUrlHtml = htmlspecialchars($unsubUrl, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');

    /* ------------- Substituições no HTML ------------------------- */
    /* ------------- SPINTAX no HTML ------------------------- */
    $content = spintax($content);
    $content = preg_replace('/%(random_[A-Za-z0-9_]+)%%/', '%$1%', $content) ?? $content;
    $content = str_replace('%ref_number%', generateRandomRef(), $content);
    
    $map1 = [
        '%subject%'                 => htmlspecialchars($subject, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'),
        '%current_date_time%'       => $currentDateTime,
        '%recipient_email%'         => htmlspecialchars($to, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'),
        '%recipient_email_url%'     => rawurlencode($to),
        '%domain%'                  => htmlspecialchars($domain, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'),
        '[-mylink-]'                => "?d=%digits6%&amp;r=%digits3%&amp;t=",
        '[-mylinkx1-]'              => "?id=%digits3%&amp;t=",
        '[-mylinkx2-]'              => "?id=on_demand/websaccess/mie/FlexibleForm/FlexibleForm.aspx?action=run&amp;layout=_flexibleform&amp;id=%digits10%=%digits6%&amp;uid=%digits7%&amp;user=%digits8%&amp;language=es&amp;skin=skin%digits3%&amp;t=",
		'[-mylinkx3-]'              => "%digits6%/" . encodeEmailForUrl($to) . "/%digits3%?t=",
		'%unsubscribe_link_mailto%' => $unsubUrlHtml,
        '%unsubscribe_secure_link%' => $unsubUrlHtml,
        '%sender_name%'             => htmlspecialchars($sender, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'),
    ];
    $content = strtr($content, $map1);

    $map2 = [
        '%digitsString%'        => generateRandomString(12),
        '%digits0%'             => base64_encode(generatemonospace2(3, 12)),
        '%digits1%'             => generateRefNumber(),
        '%digits2%'             => generateRandomNumber2(2, 2),
        '%digits3%'             => generateRandomNumber2(3, 3),
        '%digits4%'             => generateRandomNumber2(4, 4),
        '%digits5%'             => generateRandomNumber2(5, 5),
        '%digits6%'             => generateRandomNumber2(3, 12),
        '%digits7%'             => generateRandomLetras2(4, 15),
        '%digits8%'             => generateRandomLetras3(1, 1),
        '%digits9%'             => generateRandomLetras3(4, 4),
        '%digits10%'            => generateRandomLetras3(4, 23),
        '%digits11%'            => generateRandomLetras3(10, 23),
        '%digits12%'            => generateRandomLetras3(10, 23),
        '%digits13%'            => generateRandomLetras3(10, 23),
        '%digits14%'            => generateRandomLetras3(10, 23),
        '%digits15%'            => generateRandomLetras3(10, 23),
        '%digits16%'            => generateRandomLetras3(4, 23),
        '%digits17%'            => generatemonospace2(3, 3),
        '%digits18%'            => generatemonospace2(4, 5),
        '%digits19%'            => generatemonospace2(20, 25),
    ];
    $content = strtr($content, $map2);

    /* ------------- PROCESSAMENTO DO HTML ------------------------- */
    
    $content = validateAndFixHTML($content);
    $htmlContent = $content;
    $htmlContent = syncHtmlTitle($htmlContent, $subject);

    /*
     * v6.2 - Proteção extra para links:
     * Remove quebras reais dentro de href="", caso o HTML já venha quebrado
     * antes do encoding.
     *
     * Isso evita casos como:
     * href="https://dominio.com/click?token=ABC
     * DEF"
     *
     * virar um link quebrado no cliente de email.
     */
    $htmlContent = preg_replace_callback(
        '/\bhref\s*=\s*(["\'])(.*?)\1/is',
        static function (array $m): string {
            $quote = $m[1];
            $url   = $m[2];

            // Remove somente quebras de linha reais dentro do href.
            $url = preg_replace('/[ \t]*\r\n[ \t]*|[ \t]*\r[ \t]*|[ \t]*\n[ \t]*/', '', $url) ?? $url;

            return 'href=' . $quote . $url . $quote;
        },
        $htmlContent
    ) ?? $htmlContent;
    
    if (!isValidHTML($htmlContent)) {
        debugLn(substr($htmlContent, 0, 500));
        return false;
    }

    $textContent = htmlToText($htmlContent);
    
    if (empty(trim($textContent))) {
        $textContent = strip_tags($htmlContent);
    }

    /*
     * Normaliza quebras para padrão de email: CRLF.
     */
    $htmlContent = preg_replace("/\r\n|\r|\n/", "\r\n", $htmlContent) ?? $htmlContent;
    $textContent = preg_replace("/\r\n|\r|\n/", "\r\n", $textContent) ?? $textContent;

    /*
     * v6.2 - Word-wrap UTF-8 safe no text/plain.
     */
    $textContent = wordWrapUtf8($textContent, 78, "\r\n");

    /*
     * v6.2 - IMPORTANTE:
     *
     * Removido:
     * $htmlContent = wrapHtmlLines($htmlContent, 998);
     *
     * Motivo:
     * wrapHtmlLines() pode inserir quebra real \r\n dentro de href="",
     * token, JWT, assinatura, URL longa, parâmetro UTM ou link de tracking.
     *
     * Agora o HTML sempre será enviado como quoted-printable.
     * O quoted-printable faz soft-break com "=" no final da linha,
     * sem alterar o conteúdo real do link depois de decodificado.
     */

    /*
     * v6.2 - text/html SEMPRE quoted-printable.
     */
    $encodedHtml  = quoted_printable_encode($htmlContent);
    $htmlEncoding = 'quoted-printable';
    $htmlCharset  = 'UTF-8';

    /*
     * v6.2 - text/plain continua adaptativo.
     *
     * ASCII puro e linhas curtas:
     *   7bit / US-ASCII
     *
     * Texto com acentos, UTF-8 ou linha longa:
     *   quoted-printable / UTF-8
     */
    $hasLineOverOctets = static function (string $body, int $limit): bool {
        $lines = preg_split("/\r\n|\r|\n/", $body);

        if ($lines === false) {
            return strlen($body) > $limit;
        }

        foreach ($lines as $line) {
            if (strlen($line) > $limit) {
                return true;
            }
        }

        return false;
    };

    $has8bitText     = (bool) preg_match('/[\x80-\xFF]/', $textContent);
    $hasLongLineText = $hasLineOverOctets($textContent, 998);

    if (!$has8bitText && !$hasLongLineText) {
        $encodedText  = $textContent;
        $textEncoding = '7bit';
        $textCharset  = 'US-ASCII';
    } else {
        $encodedText  = quoted_printable_encode($textContent);
        $textEncoding = 'quoted-printable';
        $textCharset  = 'UTF-8';
    }

    /* ══════════════════════════════════════════════════════════════════
     * HEADERS v6.2 - MODELO UNIVERSAL + HTML QUOTED-PRINTABLE
     * 
     * Lógica:
     * - Headers obrigatórios RFC 5322 + MIME
     * - List-Unsubscribe funcional
     * - List-Unsubscribe-Post para One-Click
     * - Feedback-ID realmente incluído no header
     * - X-Abuse para compliance
     * ══════════════════════════════════════════════════════════════════ */
    
    $fromHeader = sprintf('%s <%s>', encodeHeaderRFC2047($sender), $senderEmail);
    $subjectEnc = encodeHeaderRFC2047($subject);
    
    /*
     * Feedback-ID:
     * Ajuda no diagnóstico de reputação por campanha.
     */
    $feedbackCampaign = 'camp' . date('Ym');
    $feedbackCustomer = preg_replace('/[^a-z0-9]/', '', strtolower($fromLocal));
    $feedbackType     = 'trans';
    $feedbackSender   = preg_replace('/[^a-z0-9.]/', '', strtolower($domain));
    $feedbackId       = "{$feedbackCampaign}:{$feedbackCustomer}:{$feedbackType}:{$feedbackSender}";

    /*
     * Importante:
     * No modelo original estava:
     *
     * mailto:{$to}
     *
     * Isso apontava o unsubscribe para o próprio destinatário.
     * Aqui foi corrigido para uma caixa sua de unsubscribe.
     */
    $abuseUrl = "https://{$domain}/abuse.php?mid=" . rawurlencode($messageID);
    
    $baseHeaders = [
        // ── Obrigatórios / essenciais RFC 5322 + MIME ──
        "From: {$fromHeader}",
        "Date: " . date(DATE_RFC2822),
        "Message-ID: {$messageID}",
        "MIME-Version: 1.0",

        // ── Descadastro / compliance ──
        "List-Unsubscribe: <{$unsubUrl}>",
        "List-Unsubscribe-Post: List-Unsubscribe=One-Click",

        // ── Diagnóstico / abuso ──
		/*
        "Feedback-ID: {$feedbackId}",
        "X-Abuse: {$abuseUrl}",
		*/
    ];

    /* --------------------------- Corpo / MIME --------------------------- */
    
    $hasAttachment = false;
    $attachmentContent = '';
    
    if (!empty($attachment)) {
        if (is_string($attachment)) {
            if (@is_file($attachment)) {
                $attachmentContent = file_get_contents($attachment);
                $hasAttachment = true;
            } else {
                $attachmentContent = $attachment;
                $hasAttachment = true;
            }
        }
    }

    if (!$hasAttachment) {
        $altBoundary = hash('sha256', microtime() . random_bytes(8));

        $headers = array_merge($baseHeaders, [
            "Content-Type: multipart/alternative; boundary=\"{$altBoundary}\""
        ]);

        $parts = [
            "--{$altBoundary}",
            "Content-Type: text/plain; charset=\"{$textCharset}\"",
            "Content-Transfer-Encoding: {$textEncoding}",
            '',
            $encodedText,
            '',
            "--{$altBoundary}",
            "Content-Type: text/html; charset=\"{$htmlCharset}\"",
            "Content-Transfer-Encoding: {$htmlEncoding}",
            '',
            $encodedHtml,
            '',
            "--{$altBoundary}--",
        ];
        
        $msg = implode("\r\n", $parts);

    } else {
        $mixedBoundary = hash('sha256', microtime() . random_bytes(8));
        $altBoundary   = hash('sha256', microtime() . random_bytes(8));

        $headers = array_merge($baseHeaders, [
            "Content-Type: multipart/mixed; boundary=\"{$mixedBoundary}\""
        ]);

        $parts = [];

        $parts[] = "--{$mixedBoundary}";
        $parts[] = "Content-Type: multipart/alternative; boundary=\"{$altBoundary}\"";
        $parts[] = '';

        $parts[] = "--{$altBoundary}";
        $parts[] = "Content-Type: text/plain; charset=\"{$textCharset}\"";
        $parts[] = "Content-Transfer-Encoding: {$textEncoding}";
        $parts[] = '';
        $parts[] = $encodedText;
        $parts[] = '';

        $parts[] = "--{$altBoundary}";
        $parts[] = "Content-Type: text/html; charset=\"{$htmlCharset}\"";
        $parts[] = "Content-Transfer-Encoding: {$htmlEncoding}";
        $parts[] = '';
        $parts[] = $encodedHtml;
        $parts[] = '';

        $parts[] = "--{$altBoundary}--";
        $parts[] = '';

        $attachmentEncoded = chunk_split(base64_encode($attachmentContent));
        $safeFilename      = basename($attachmentName);

        $parts[] = "--{$mixedBoundary}";
        $parts[] = "Content-Type: application/pdf; name=\"{$safeFilename}\"";
        $parts[] = "Content-Transfer-Encoding: base64";
        $parts[] = "Content-Disposition: attachment; filename=\"{$safeFilename}\"";
        $parts[] = '';
        $parts[] = $attachmentEncoded;
        $parts[] = '';

        $parts[] = "--{$mixedBoundary}--";

        $msg = implode("\r\n", $parts);
    }

    $headersStr = implode("\r\n", $headers);
    
    return mail($to, $subjectEnc, $msg, $headersStr, $additionalParams);
}

/**
 * Função de teste
 */
function testEmailSending(string $testTo = 'test@example.com'): bool {
    debugLn("\n=== TESTE v6.2 - HEADER UNIVERSAL + HTML QUOTED-PRINTABLE ===");
    
    $html = <<<'HTML'
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta charset="UTF-8">
<title>Currículum</title>
</head>
<body>
<p style="font-family: Courier New,Courier,monospace;"><em>
Hola, adjunto mi información profesional.</em></p>

<p style="font-family: Courier New,Courier,monospace;"><em>
<a href="https://example.com/doc.pdf">datos_profesionales.doc</a>
</em></p>

<p style="font-family: Courier New,Courier,monospace;"><em>
Saludos cordiales.<
HTML;
    
    $result = sendEmail(
        'Sistema Teste',
        'noreply@' . SERVER_DOMAIN,
        $testTo,
        'Currículum (FINAL)',
        $html
    );
    
    debugLn($result ? "\n✓ Email enviado com sucesso!" : "\n✗ Falha no envio!");
    return $result;
}
?>